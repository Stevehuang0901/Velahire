"""Tests for agent classes: ProfileAgent, ScoutAgent, WriterAgent."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


@pytest.mark.asyncio
class TestProfileAgent:
    """Tests for the ProfileAgent that builds candidate profiles."""

    @patch("app.agents.profile_agent.ProfileAgent")
    async def test_build_profile_from_resume(
        self, MockProfileAgent, mock_resume_data: dict
    ):
        agent = MockProfileAgent.return_value
        agent.build_profile = AsyncMock(
            return_value={
                "headline": "Senior Software Engineer",
                "summary": "Experienced engineer with 4 years of backend development.",
                "skills": mock_resume_data["skills"],
                "experience_years": 4.0,
                "desired_titles": ["Senior Software Engineer", "Staff Engineer"],
            }
        )

        profile = await agent.build_profile(mock_resume_data)

        assert profile["headline"] == "Senior Software Engineer"
        assert "skills" in profile
        assert len(profile["skills"]) > 0
        agent.build_profile.assert_awaited_once_with(mock_resume_data)

    @patch("app.agents.profile_agent.ProfileAgent")
    async def test_extract_skills(self, MockProfileAgent, mock_resume_data: dict):
        agent = MockProfileAgent.return_value
        agent.extract_skills = AsyncMock(
            return_value=mock_resume_data["skills"]
        )

        skills = await agent.extract_skills(mock_resume_data["raw_text"])

        assert isinstance(skills, list)
        assert "Python" in skills
        assert "FastAPI" in skills

    @patch("app.agents.profile_agent.ProfileAgent")
    async def test_profile_handles_incomplete_resume(self, MockProfileAgent):
        agent = MockProfileAgent.return_value
        agent.build_profile = AsyncMock(
            return_value={
                "headline": "",
                "summary": "Limited information available.",
                "skills": [],
                "experience_years": 0,
                "desired_titles": [],
            }
        )

        incomplete_data = {"raw_text": "John Doe", "parsed_data": {}}
        profile = await agent.build_profile(incomplete_data)

        assert profile["experience_years"] == 0
        assert profile["skills"] == []


@pytest.mark.asyncio
class TestScoutAgent:
    """Tests for the ScoutAgent that finds and matches jobs."""

    @patch("app.agents.scout_agent.ScoutAgent")
    async def test_find_matching_jobs(
        self, MockScoutAgent, mock_job_data: dict
    ):
        agent = MockScoutAgent.return_value
        agent.find_jobs = AsyncMock(
            return_value=[
                {
                    "job": mock_job_data,
                    "score": 0.87,
                    "reasoning": "Strong skill match in Python and PostgreSQL.",
                }
            ]
        )

        profile = {"skills": ["Python", "PostgreSQL"], "desired_titles": ["Backend Engineer"]}
        matches = await agent.find_jobs(profile, limit=10)

        assert len(matches) == 1
        assert matches[0]["score"] > 0.8
        assert "reasoning" in matches[0]

    @patch("app.agents.scout_agent.ScoutAgent")
    async def test_score_job_match(self, MockScoutAgent, mock_job_data: dict):
        agent = MockScoutAgent.return_value
        agent.score_match = AsyncMock(
            return_value={
                "overall_score": 0.85,
                "skill_match_pct": 0.90,
                "experience_match_pct": 0.80,
                "location_match": True,
                "salary_match": True,
                "reasoning": "Excellent fit based on skills and experience.",
            }
        )

        resume = {"skills": ["Python", "Docker"], "experience_years": 5}
        score = await agent.score_match(resume, mock_job_data)

        assert score["overall_score"] == 0.85
        assert score["skill_match_pct"] == 0.90
        assert score["location_match"] is True

    @patch("app.agents.scout_agent.ScoutAgent")
    async def test_no_matches_found(self, MockScoutAgent):
        agent = MockScoutAgent.return_value
        agent.find_jobs = AsyncMock(return_value=[])

        profile = {"skills": ["COBOL"], "desired_titles": ["COBOL Developer"]}
        matches = await agent.find_jobs(profile, limit=10)

        assert matches == []

    @patch("app.agents.scout_agent.ScoutAgent")
    async def test_filter_by_platform(self, MockScoutAgent, mock_job_data: dict):
        agent = MockScoutAgent.return_value
        agent.find_jobs = AsyncMock(
            return_value=[{"job": mock_job_data, "score": 0.9, "reasoning": "Match"}]
        )

        profile = {"skills": ["Python"]}
        matches = await agent.find_jobs(
            profile, limit=10, platforms=["greenhouse"]
        )

        assert len(matches) == 1
        assert matches[0]["job"]["platform"] == "greenhouse"


@pytest.mark.asyncio
class TestWriterAgent:
    """Tests for the WriterAgent that tailors resumes and writes cover letters."""

    @patch("app.agents.writer_agent.WriterAgent")
    async def test_tailor_resume(
        self,
        MockWriterAgent,
        mock_resume_data: dict,
        mock_job_data: dict,
    ):
        agent = MockWriterAgent.return_value
        agent.tailor_resume = AsyncMock(
            return_value={
                "tailored_text": "Tailored resume content emphasizing Python and API development...",
                "changes_summary": "Highlighted Python/FastAPI experience, added keywords from JD.",
                "ats_score_before": 65.0,
                "ats_score_after": 89.0,
            }
        )

        result = await agent.tailor_resume(mock_resume_data, mock_job_data)

        assert "tailored_text" in result
        assert result["ats_score_after"] > result["ats_score_before"]
        agent.tailor_resume.assert_awaited_once()

    @patch("app.agents.writer_agent.WriterAgent")
    async def test_generate_cover_letter(
        self,
        MockWriterAgent,
        mock_resume_data: dict,
        mock_job_data: dict,
    ):
        agent = MockWriterAgent.return_value
        agent.generate_cover_letter = AsyncMock(
            return_value={
                "tailored_text": (
                    "Dear Hiring Manager,\n\n"
                    "I am writing to express my interest in the Senior Backend Engineer "
                    "position at InnovateTech..."
                ),
                "content_type": "cover_letter",
            }
        )

        result = await agent.generate_cover_letter(mock_resume_data, mock_job_data)

        assert "tailored_text" in result
        assert "InnovateTech" in result["tailored_text"]

    @patch("app.agents.writer_agent.WriterAgent")
    async def test_tailor_preserves_facts(
        self,
        MockWriterAgent,
        mock_resume_data: dict,
        mock_job_data: dict,
    ):
        """Tailoring should not fabricate experience or skills."""
        agent = MockWriterAgent.return_value
        agent.tailor_resume = AsyncMock(
            return_value={
                "tailored_text": "Experienced Python developer with 4 years...",
                "changes_summary": "Reworded for ATS optimization, no new claims added.",
                "ats_score_before": 70.0,
                "ats_score_after": 88.0,
                "fabrication_check": True,  # Indicates fact-checking passed
            }
        )

        result = await agent.tailor_resume(mock_resume_data, mock_job_data)

        assert result.get("fabrication_check") is True

    @patch("app.agents.writer_agent.WriterAgent")
    async def test_generate_linkedin_message(
        self,
        MockWriterAgent,
        mock_resume_data: dict,
        mock_job_data: dict,
    ):
        agent = MockWriterAgent.return_value
        agent.generate_outreach = AsyncMock(
            return_value={
                "tailored_text": (
                    "Hi [Recruiter],\n\n"
                    "I noticed the Senior Backend Engineer opening at InnovateTech "
                    "and wanted to reach out..."
                ),
                "content_type": "linkedin_message",
            }
        )

        result = await agent.generate_outreach(
            mock_resume_data, mock_job_data, channel="linkedin"
        )

        assert result["content_type"] == "linkedin_message"
        assert len(result["tailored_text"]) < 2000  # LinkedIn message limit
