"""Tests for resume endpoints.

Covers resume upload, listing, quality assessment, and career analysis.
"""

import io

import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_resume_list_unauthorized(client: AsyncClient):
    """GET resume list without auth should return 401/403."""
    response = await client.get("/api/v1/resume/list")
    assert response.status_code in (401, 403)


@pytest.mark.asyncio
async def test_resume_upload_unauthorized(client: AsyncClient):
    """POST resume upload without auth should return 401/403."""
    files = {"file": ("resume.pdf", b"fake pdf content", "application/pdf")}
    response = await client.post("/api/v1/resume/upload", files=files)
    assert response.status_code in (401, 403)


@pytest.mark.asyncio
async def test_resume_quality_unauthorized(client: AsyncClient):
    """GET resume quality without auth should return 401/403."""
    response = await client.get("/api/v1/resume/quality")
    assert response.status_code in (401, 403)


@pytest.mark.asyncio
async def test_resume_career_path_unauthorized(client: AsyncClient):
    """GET career path without auth should return 401/403."""
    response = await client.get("/api/v1/resume/career-path")
    assert response.status_code in (401, 403)


@pytest.mark.asyncio
async def test_resume_upload_invalid_file_type(client: AsyncClient, auth_headers: dict):
    """Upload with unsupported file type should return 400/415/422."""
    files = {"file": ("resume.exe", b"not a resume", "application/x-executable")}
    response = await client.post(
        "/api/v1/resume/upload", files=files, headers=auth_headers,
    )
    # Depending on validation placement, could be 400, 415, or 422
    assert response.status_code in (400, 415, 422)


@pytest.mark.asyncio
async def test_resume_upload_empty_file(client: AsyncClient, auth_headers: dict):
    """Upload with empty file should return 400/422."""
    files = {"file": ("resume.pdf", b"", "application/pdf")}
    response = await client.post(
        "/api/v1/resume/upload", files=files, headers=auth_headers,
    )
    assert response.status_code in (400, 422)


class TestResumeValidation:
    """Unit tests for resume file validation logic."""

    def test_validate_pdf(self):
        from app.utils.validators import validate_resume_file

        valid, msg = validate_resume_file("application/pdf", 1024)
        assert valid is True
        assert msg == "Valid"

    def test_validate_docx(self):
        from app.utils.validators import validate_resume_file

        valid, msg = validate_resume_file(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            2048,
        )
        assert valid is True

    def test_reject_invalid_type(self):
        from app.utils.validators import validate_resume_file

        valid, msg = validate_resume_file("application/x-executable", 1024)
        assert valid is False
        assert "Unsupported" in msg

    def test_reject_oversized_file(self):
        from app.utils.validators import validate_resume_file

        valid, msg = validate_resume_file("application/pdf", 20 * 1024 * 1024)
        assert valid is False
        assert "too large" in msg.lower() or "Maximum" in msg

    def test_reject_empty_file(self):
        from app.utils.validators import validate_resume_file

        valid, msg = validate_resume_file("application/pdf", 0)
        assert valid is False
        assert "empty" in msg.lower()
