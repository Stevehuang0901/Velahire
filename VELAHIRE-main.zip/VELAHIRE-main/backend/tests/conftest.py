"""Pytest fixtures and configuration for VelaHire backend tests.

Provides async test infrastructure, database session management,
HTTP test client, mock user data, and authentication helpers.
"""

import asyncio
from typing import AsyncGenerator, Generator
from uuid import uuid4

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.core.config import settings
from app.core.database import Base, get_db
from app.core.security import create_access_token, hash_password
from app.main import app
from app.models.user import PlanTier, User

# ---------------------------------------------------------------------------
# Test database engine
# ---------------------------------------------------------------------------

TEST_DATABASE_URL = settings.DATABASE_URL

test_engine = create_async_engine(
    TEST_DATABASE_URL,
    pool_size=5,
    max_overflow=0,
    echo=False,
)

TestSessionFactory = async_sessionmaker(
    bind=test_engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


# ---------------------------------------------------------------------------
# Pytest configuration
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def event_loop() -> Generator[asyncio.AbstractEventLoop, None, None]:
    """Create an event loop for the test session."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    """Provide a transactional database session that rolls back after each test."""
    async with TestSessionFactory() as session:
        try:
            yield session
        finally:
            await session.rollback()
            await session.close()


@pytest_asyncio.fixture
async def client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """Provide an async HTTP test client with DB session override."""

    async def _override_get_db() -> AsyncGenerator[AsyncSession, None]:
        yield db_session

    app.dependency_overrides[get_db] = _override_get_db

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac

    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def test_user(db_session: AsyncSession) -> User:
    """Create and return a test user in the database."""
    user = User(
        id=uuid4(),
        email=f"test-{uuid4().hex[:8]}@example.com",
        hashed_password=hash_password("TestPass123!"),
        full_name="Test User",
        plan=PlanTier.PRO,
        is_active=True,
    )
    db_session.add(user)
    await db_session.flush()
    await db_session.refresh(user)
    return user


@pytest_asyncio.fixture
async def auth_client(
    client: AsyncClient, test_user: User
) -> AsyncClient:
    """Provide an authenticated HTTP test client."""
    token = create_access_token(test_user.id)
    client.headers["Authorization"] = f"Bearer {token}"
    return client


# ---------------------------------------------------------------------------
# Mock data fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_user() -> dict:
    """Return mock user data for tests that don't need a DB user."""
    return {
        "id": str(uuid4()),
        "email": "test@example.com",
        "full_name": "Test User",
        "plan": "pro",
    }


@pytest.fixture
def mock_resume_data() -> dict:
    """Return mock parsed resume data."""
    return {
        "contact": {
            "full_name": "Jane Doe",
            "email": "jane@example.com",
            "phone": "+1-555-123-4567",
            "location": "San Francisco, CA",
            "linkedin": "https://linkedin.com/in/janedoe",
        },
        "summary": "Senior Software Engineer with 8 years of experience in "
        "full-stack development, specialising in Python and cloud architecture.",
        "experience": [
            {
                "title": "Senior Software Engineer",
                "company": "Tech Corp",
                "location": "San Francisco, CA",
                "start_date": "2020-01",
                "end_date": "Present",
                "description": "Led backend development team of 5 engineers.",
                "achievements": [
                    "Reduced API latency by 40% through query optimisation",
                    "Architected microservices migration serving 2M+ users",
                    "Mentored 3 junior engineers to mid-level promotions",
                ],
            },
            {
                "title": "Software Engineer",
                "company": "StartupXYZ",
                "location": "New York, NY",
                "start_date": "2016-06",
                "end_date": "2019-12",
                "description": "Full-stack development with Python and React.",
                "achievements": [
                    "Built real-time analytics dashboard processing 1M events/day",
                    "Implemented CI/CD pipeline reducing deploy time from 2h to 15min",
                ],
            },
        ],
        "education": [
            {
                "degree": "BS Computer Science",
                "institution": "MIT",
                "graduation_date": "2016",
                "gpa": "3.8",
            }
        ],
        "skills": {
            "technical": ["Python", "FastAPI", "React", "PostgreSQL", "AWS", "Docker", "Kubernetes"],
            "soft": ["Leadership", "Communication", "Problem-solving"],
            "tools": ["Git", "Jira", "Terraform"],
            "languages": ["English", "Spanish"],
        },
        "certifications": [
            {
                "name": "AWS Solutions Architect",
                "issuer": "Amazon Web Services",
                "date": "2022-03",
            }
        ],
    }


@pytest.fixture
def mock_job() -> dict:
    """Return mock job listing data."""
    return {
        "id": str(uuid4()),
        "title": "Senior Backend Engineer",
        "company": "StartupXYZ",
        "location": "San Francisco, CA",
        "description": (
            "We are looking for a senior backend engineer with strong Python "
            "and FastAPI experience to join our growing engineering team. "
            "You will design and build scalable APIs serving millions of users."
        ),
        "requirements": [
            "5+ years of backend development experience",
            "Strong Python and SQL skills",
            "Experience with cloud infrastructure (AWS preferred)",
            "Familiarity with microservices architecture",
        ],
        "salary_min": 150000,
        "salary_max": 200000,
        "is_remote": True,
        "url": "https://boards.greenhouse.io/startupxyz/jobs/123456",
    }


@pytest.fixture
def auth_headers(mock_user: dict) -> dict:
    """Return authorization headers for mock user."""
    token = create_access_token(mock_user["id"])
    return {"Authorization": f"Bearer {token}"}
