"""Tests for job-related endpoints.

Covers job search, matching, market analysis, and match scoring.
"""

import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_jobs_match_unauthorized(client: AsyncClient):
    """GET job matches without auth should return 401/403."""
    response = await client.get("/api/v1/jobs/match")
    assert response.status_code in (401, 403)


@pytest.mark.asyncio
async def test_jobs_search_unauthorized(client: AsyncClient):
    """GET job search without auth should return 401/403."""
    response = await client.get(
        "/api/v1/jobs/search", params={"keyword": "python"}
    )
    assert response.status_code in (401, 403)


@pytest.mark.asyncio
async def test_jobs_market_analysis_unauthorized(client: AsyncClient):
    """GET market analysis without auth should return 401/403."""
    response = await client.get(
        "/api/v1/jobs/market-analysis",
        params={"industry": "technology", "role": "software engineer"},
    )
    assert response.status_code in (401, 403)


class TestScoutAgentUnit:
    """Unit tests for ScoutAgent matching logic."""

    def test_criteria_from_profile(self):
        """Test search criteria extraction from profile."""
        from app.agents.scout_agent import ScoutAgent

        profile = {
            "contact": {"location": "San Francisco, CA"},
            "experience": [
                {"title": "Senior Engineer", "company": "TechCo"}
            ],
            "skills": {
                "technical": ["Python", "FastAPI", "PostgreSQL"],
            },
        }
        criteria = ScoutAgent._criteria_from_profile(profile)

        assert criteria["title"] == "Senior Engineer"
        assert criteria["location"] == "San Francisco, CA"
        assert "Python" in criteria["keywords"]
        assert len(criteria["platforms"]) > 0

    def test_criteria_from_empty_profile(self):
        """Test criteria extraction from an empty profile."""
        from app.agents.scout_agent import ScoutAgent

        criteria = ScoutAgent._criteria_from_profile({})
        assert "title" in criteria
        assert "platforms" in criteria

    def test_deduplication_key(self):
        """Test that job deduplication is case-insensitive."""
        # This tests the logic used in search_jobs for dedup
        seen: set[str] = set()
        job_a = {"title": "Software Engineer", "company": "Google"}
        job_b = {"title": "software engineer", "company": "google"}

        key_a = f"{job_a['title'].lower().strip()}|{job_a['company'].lower().strip()}"
        key_b = f"{job_b['title'].lower().strip()}|{job_b['company'].lower().strip()}"

        seen.add(key_a)
        assert key_b in seen  # Should be considered a duplicate


class TestInputValidation:
    """Unit tests for input validation utilities."""

    def test_valid_email(self):
        from app.utils.validators import validate_email

        assert validate_email("user@example.com") is True
        assert validate_email("user.name+tag@domain.co.uk") is True

    def test_invalid_email(self):
        from app.utils.validators import validate_email

        assert validate_email("") is False
        assert validate_email("not-an-email") is False
        assert validate_email("@domain.com") is False
        assert validate_email("user@") is False

    def test_valid_url(self):
        from app.utils.validators import validate_url

        assert validate_url("https://example.com") is True
        assert validate_url("http://localhost:3000") is True

    def test_invalid_url(self):
        from app.utils.validators import validate_url

        assert validate_url("") is False
        assert validate_url("ftp://example.com") is False
        assert validate_url("not a url") is False

    def test_sanitize_input(self):
        from app.utils.validators import sanitize_input

        assert "<script>" not in sanitize_input("<script>alert('xss')</script>Hello")
        assert sanitize_input("  normal text  ") == "normal text"
        assert sanitize_input("") == ""

    def test_validate_uuid(self):
        from app.utils.validators import validate_uuid

        assert validate_uuid("550e8400-e29b-41d4-a716-446655440000") is True
        assert validate_uuid("not-a-uuid") is False
        assert validate_uuid("") is False

    def test_validate_salary_range(self):
        from app.utils.validators import validate_salary_range

        valid, _ = validate_salary_range(100000, 200000)
        assert valid is True

        valid, msg = validate_salary_range(200000, 100000)
        assert valid is False
        assert "exceed" in msg.lower()

        valid, _ = validate_salary_range(None, None)
        assert valid is True
