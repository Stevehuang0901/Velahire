"""Initial schema for VelaHire.

Revision ID: 001_initial
Revises: None
Create Date: 2026-03-14
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY

# revision identifiers, used by Alembic.
revision: str = "001_initial"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # --- Enums ---
    user_plan_enum = sa.Enum(
        "free", "basic", "premium", "enterprise",
        name="user_plan",
    )
    user_plan_enum.create(op.get_bind(), checkfirst=True)

    application_status_enum = sa.Enum(
        "draft", "submitted", "under_review", "interview",
        "offer", "rejected", "withdrawn",
        name="application_status",
    )
    application_status_enum.create(op.get_bind(), checkfirst=True)

    match_status_enum = sa.Enum(
        "pending", "approved", "rejected", "applied",
        name="match_status",
    )
    match_status_enum.create(op.get_bind(), checkfirst=True)

    email_event_enum = sa.Enum(
        "sent", "delivered", "opened", "clicked", "bounced", "failed",
        name="email_event",
    )
    email_event_enum.create(op.get_bind(), checkfirst=True)

    content_type_enum = sa.Enum(
        "resume", "cover_letter", "email", "linkedin_message",
        name="content_type",
    )
    content_type_enum.create(op.get_bind(), checkfirst=True)

    # --- users ---
    op.create_table(
        "users",
        sa.Column("id", UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("email", sa.String(320), nullable=False, unique=True),
        sa.Column("hashed_password", sa.String(256), nullable=False),
        sa.Column("full_name", sa.String(256), nullable=False),
        sa.Column("phone", sa.String(32), nullable=True),
        sa.Column("plan", user_plan_enum, nullable=False, server_default="free"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("is_verified", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("oauth_provider", sa.String(32), nullable=True),
        sa.Column("oauth_tokens_encrypted", sa.Text(), nullable=True),
        sa.Column("preferences", JSONB, nullable=True),
        sa.Column("daily_applications_count", sa.Integer(), nullable=False, server_default=sa.text("0")),
        sa.Column("last_application_reset", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_users_email", "users", ["email"], unique=True)
    op.create_index("ix_users_plan", "users", ["plan"])

    # --- resumes ---
    op.create_table(
        "resumes",
        sa.Column("id", UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("filename", sa.String(512), nullable=False),
        sa.Column("s3_key", sa.String(1024), nullable=True),
        sa.Column("file_type", sa.String(16), nullable=False),
        sa.Column("file_size_bytes", sa.Integer(), nullable=False),
        sa.Column("raw_text", sa.Text(), nullable=True),
        sa.Column("parsed_data", JSONB, nullable=True),
        sa.Column("skills", ARRAY(sa.String), nullable=True),
        sa.Column("experience_years", sa.Float(), nullable=True),
        sa.Column("education", JSONB, nullable=True),
        sa.Column("embedding_id", sa.String(256), nullable=True),
        sa.Column("is_primary", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_resumes_user_id", "resumes", ["user_id"])

    # --- profiles ---
    op.create_table(
        "profiles",
        sa.Column("id", UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True),
        sa.Column("headline", sa.String(512), nullable=True),
        sa.Column("summary", sa.Text(), nullable=True),
        sa.Column("desired_titles", ARRAY(sa.String), nullable=True),
        sa.Column("desired_locations", ARRAY(sa.String), nullable=True),
        sa.Column("remote_preference", sa.String(32), nullable=True),
        sa.Column("min_salary", sa.Integer(), nullable=True),
        sa.Column("max_salary", sa.Integer(), nullable=True),
        sa.Column("industries", ARRAY(sa.String), nullable=True),
        sa.Column("work_authorization", sa.String(64), nullable=True),
        sa.Column("linkedin_url", sa.String(512), nullable=True),
        sa.Column("portfolio_url", sa.String(512), nullable=True),
        sa.Column("github_url", sa.String(512), nullable=True),
        sa.Column("additional_info", JSONB, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_profiles_user_id", "profiles", ["user_id"], unique=True)

    # --- jobs ---
    op.create_table(
        "jobs",
        sa.Column("id", UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("external_id", sa.String(512), nullable=True),
        sa.Column("platform", sa.String(64), nullable=False),
        sa.Column("url", sa.String(2048), nullable=False),
        sa.Column("title", sa.String(512), nullable=False),
        sa.Column("company", sa.String(512), nullable=False),
        sa.Column("location", sa.String(512), nullable=True),
        sa.Column("is_remote", sa.Boolean(), nullable=True),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("requirements", JSONB, nullable=True),
        sa.Column("salary_min", sa.Integer(), nullable=True),
        sa.Column("salary_max", sa.Integer(), nullable=True),
        sa.Column("salary_currency", sa.String(8), nullable=True, server_default="USD"),
        sa.Column("job_type", sa.String(32), nullable=True),
        sa.Column("experience_level", sa.String(32), nullable=True),
        sa.Column("skills_required", ARRAY(sa.String), nullable=True),
        sa.Column("benefits", JSONB, nullable=True),
        sa.Column("posted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("embedding_id", sa.String(256), nullable=True),
        sa.Column("raw_html", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_jobs_platform", "jobs", ["platform"])
    op.create_index("ix_jobs_company", "jobs", ["company"])
    op.create_index("ix_jobs_external_id", "jobs", ["external_id"])
    op.create_index("ix_jobs_title", "jobs", ["title"])
    op.create_index("ix_jobs_posted_at", "jobs", ["posted_at"])

    # --- matches ---
    op.create_table(
        "matches",
        sa.Column("id", UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("job_id", UUID(as_uuid=True), sa.ForeignKey("jobs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("resume_id", UUID(as_uuid=True), sa.ForeignKey("resumes.id", ondelete="SET NULL"), nullable=True),
        sa.Column("score", sa.Float(), nullable=False),
        sa.Column("skill_match_pct", sa.Float(), nullable=True),
        sa.Column("experience_match_pct", sa.Float(), nullable=True),
        sa.Column("location_match", sa.Boolean(), nullable=True),
        sa.Column("salary_match", sa.Boolean(), nullable=True),
        sa.Column("reasoning", sa.Text(), nullable=True),
        sa.Column("status", match_status_enum, nullable=False, server_default="pending"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_matches_user_id", "matches", ["user_id"])
    op.create_index("ix_matches_job_id", "matches", ["job_id"])
    op.create_index("ix_matches_score", "matches", ["score"])
    op.create_unique_constraint("uq_matches_user_job", "matches", ["user_id", "job_id"])

    # --- tailored_content ---
    op.create_table(
        "tailored_content",
        sa.Column("id", UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("job_id", UUID(as_uuid=True), sa.ForeignKey("jobs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("resume_id", UUID(as_uuid=True), sa.ForeignKey("resumes.id", ondelete="SET NULL"), nullable=True),
        sa.Column("content_type", content_type_enum, nullable=False),
        sa.Column("original_text", sa.Text(), nullable=True),
        sa.Column("tailored_text", sa.Text(), nullable=False),
        sa.Column("changes_summary", sa.Text(), nullable=True),
        sa.Column("ats_score_before", sa.Float(), nullable=True),
        sa.Column("ats_score_after", sa.Float(), nullable=True),
        sa.Column("metadata", JSONB, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_tailored_content_user_id", "tailored_content", ["user_id"])
    op.create_index("ix_tailored_content_job_id", "tailored_content", ["job_id"])

    # --- applications ---
    op.create_table(
        "applications",
        sa.Column("id", UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("job_id", UUID(as_uuid=True), sa.ForeignKey("jobs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("match_id", UUID(as_uuid=True), sa.ForeignKey("matches.id", ondelete="SET NULL"), nullable=True),
        sa.Column("resume_id", UUID(as_uuid=True), sa.ForeignKey("resumes.id", ondelete="SET NULL"), nullable=True),
        sa.Column("tailored_content_id", UUID(as_uuid=True), sa.ForeignKey("tailored_content.id", ondelete="SET NULL"), nullable=True),
        sa.Column("status", application_status_enum, nullable=False, server_default="draft"),
        sa.Column("platform", sa.String(64), nullable=False),
        sa.Column("applied_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("form_data", JSONB, nullable=True),
        sa.Column("confirmation_id", sa.String(256), nullable=True),
        sa.Column("screenshot_s3_key", sa.String(1024), nullable=True),
        sa.Column("error_log", sa.Text(), nullable=True),
        sa.Column("retry_count", sa.Integer(), nullable=False, server_default=sa.text("0")),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_applications_user_id", "applications", ["user_id"])
    op.create_index("ix_applications_job_id", "applications", ["job_id"])
    op.create_index("ix_applications_status", "applications", ["status"])
    op.create_unique_constraint("uq_applications_user_job", "applications", ["user_id", "job_id"])

    # --- email_tracking ---
    op.create_table(
        "email_tracking",
        sa.Column("id", UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("application_id", UUID(as_uuid=True), sa.ForeignKey("applications.id", ondelete="CASCADE"), nullable=True),
        sa.Column("recipient_email", sa.String(320), nullable=False),
        sa.Column("subject", sa.String(512), nullable=False),
        sa.Column("body_html", sa.Text(), nullable=True),
        sa.Column("body_text", sa.Text(), nullable=True),
        sa.Column("event", email_event_enum, nullable=False, server_default="sent"),
        sa.Column("provider_message_id", sa.String(512), nullable=True),
        sa.Column("opened_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("clicked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("bounced_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("metadata", JSONB, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_email_tracking_user_id", "email_tracking", ["user_id"])
    op.create_index("ix_email_tracking_application_id", "email_tracking", ["application_id"])
    op.create_index("ix_email_tracking_event", "email_tracking", ["event"])


def downgrade() -> None:
    op.drop_table("email_tracking")
    op.drop_table("applications")
    op.drop_table("tailored_content")
    op.drop_table("matches")
    op.drop_table("jobs")
    op.drop_table("profiles")
    op.drop_table("resumes")
    op.drop_table("users")

    op.execute("DROP TYPE IF EXISTS email_event")
    op.execute("DROP TYPE IF EXISTS content_type")
    op.execute("DROP TYPE IF EXISTS match_status")
    op.execute("DROP TYPE IF EXISTS application_status")
    op.execute("DROP TYPE IF EXISTS user_plan")
