"""Anti-detection utilities for browser automation."""
import random
import asyncio

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
]


async def random_delay(min_s: float = 0.5, max_s: float = 3.0):
    """Sleep for a random duration to simulate human behavior."""
    await asyncio.sleep(random.uniform(min_s, max_s))


def rotate_user_agent() -> str:
    """Get a random user agent string."""
    return random.choice(USER_AGENTS)


def generate_browser_fingerprint() -> dict:
    """Generate a randomized browser fingerprint."""
    return {
        "user_agent": rotate_user_agent(),
        "viewport": random.choice([(1920, 1080), (1366, 768), (1440, 900), (1536, 864)]),
        "timezone": random.choice(["America/New_York", "America/Chicago", "America/Los_Angeles"]),
        "locale": "en-US",
        "color_depth": 24,
    }


async def simulate_human_typing(page, selector: str, text: str):
    """Type text with random delays between keystrokes."""
    element = page.locator(selector)
    for char in text:
        await element.press(char)
        await asyncio.sleep(random.uniform(0.03, 0.15))


async def simulate_mouse_movement(page):
    """Simulate random mouse movements."""
    for _ in range(random.randint(2, 5)):
        x = random.randint(100, 1200)
        y = random.randint(100, 700)
        await page.mouse.move(x, y)
        await asyncio.sleep(random.uniform(0.1, 0.3))
