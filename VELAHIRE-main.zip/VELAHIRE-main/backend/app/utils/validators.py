"""Input validation utilities for the VelaHire application.

Provides validation functions for emails, URLs, file uploads, passwords,
phone numbers, and general text sanitisation.
"""

import re
from typing import Optional
from urllib.parse import urlparse

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ALLOWED_RESUME_TYPES: set[str] = {
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/msword",
    "text/plain",
}

ALLOWED_RESUME_EXTENSIONS: set[str] = {".pdf", ".docx", ".doc", ".txt"}

MAX_RESUME_SIZE: int = 10 * 1024 * 1024  # 10 MB

PASSWORD_MIN_LENGTH: int = 8
PASSWORD_MAX_LENGTH: int = 128

EMAIL_PATTERN = re.compile(
    r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"
)

PHONE_PATTERN = re.compile(
    r"^\+?1?\d{9,15}$"
)

# Common SQL / XSS injection patterns to strip
_DANGEROUS_PATTERNS = re.compile(
    r"(<script[\s>]|<\/script>|javascript:|on\w+\s*=|union\s+select|"
    r"drop\s+table|insert\s+into|delete\s+from|--\s|/\*|\*/)",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Validation functions
# ---------------------------------------------------------------------------


def validate_email(email: str) -> bool:
    """Validate an email address format.

    Args:
        email: The email string to validate.

    Returns:
        True if the email format is valid, False otherwise.
    """
    if not email or len(email) > 320:
        return False
    return bool(EMAIL_PATTERN.match(email))


def validate_password(password: str) -> tuple[bool, str]:
    """Validate a password against security requirements.

    Requirements:
    - 8-128 characters
    - At least one uppercase letter
    - At least one lowercase letter
    - At least one digit
    - At least one special character

    Args:
        password: The password string to validate.

    Returns:
        Tuple of (is_valid, message).
    """
    if len(password) < PASSWORD_MIN_LENGTH:
        return False, f"Password must be at least {PASSWORD_MIN_LENGTH} characters"
    if len(password) > PASSWORD_MAX_LENGTH:
        return False, f"Password must be at most {PASSWORD_MAX_LENGTH} characters"
    if not re.search(r"[A-Z]", password):
        return False, "Password must contain at least one uppercase letter"
    if not re.search(r"[a-z]", password):
        return False, "Password must contain at least one lowercase letter"
    if not re.search(r"\d", password):
        return False, "Password must contain at least one digit"
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>_\-+=\[\]\\/'`~;]", password):
        return False, "Password must contain at least one special character"
    return True, "Valid"


def validate_resume_file(
    content_type: str,
    file_size: int,
    filename: Optional[str] = None,
) -> tuple[bool, str]:
    """Validate a resume file by type and size.

    Args:
        content_type: MIME type of the file.
        file_size: File size in bytes.
        filename: Optional filename to check extension.

    Returns:
        Tuple of (is_valid, message).
    """
    if content_type not in ALLOWED_RESUME_TYPES:
        return False, (
            f"Unsupported file type: {content_type}. "
            f"Allowed: PDF, DOCX, DOC, TXT"
        )

    if filename:
        ext = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext and ext not in ALLOWED_RESUME_EXTENSIONS:
            return False, f"Unsupported file extension: {ext}"

    if file_size <= 0:
        return False, "File is empty"

    if file_size > MAX_RESUME_SIZE:
        max_mb = MAX_RESUME_SIZE // (1024 * 1024)
        file_mb = round(file_size / (1024 * 1024), 1)
        return False, f"File too large ({file_mb} MB). Maximum: {max_mb} MB"

    return True, "Valid"


def validate_url(url: str) -> bool:
    """Validate a URL format.

    Args:
        url: The URL string to validate.

    Returns:
        True if the URL is valid and uses http or https.
    """
    if not url or len(url) > 2048:
        return False
    try:
        result = urlparse(url)
        return all([result.scheme in ("http", "https"), result.netloc])
    except Exception:
        return False


def validate_phone(phone: str) -> bool:
    """Validate a phone number format (international).

    Args:
        phone: The phone number string to validate.

    Returns:
        True if the phone number format is valid.
    """
    if not phone:
        return False
    cleaned = re.sub(r"[\s\-\(\)\.]", "", phone)
    return bool(PHONE_PATTERN.match(cleaned))


def sanitize_input(text: str, max_length: int = 10000) -> str:
    """Sanitise user input to prevent injection attacks.

    Strips HTML tags, dangerous patterns, and enforces length limits.

    Args:
        text: The input text to sanitise.
        max_length: Maximum allowed length after sanitisation.

    Returns:
        Sanitised text string.
    """
    if not text:
        return ""

    # Strip HTML tags
    text = re.sub(r"<[^>]+>", "", text)

    # Remove dangerous patterns
    text = _DANGEROUS_PATTERNS.sub("", text)

    # Escape remaining angle brackets
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    # Enforce length limit
    text = text.strip()[:max_length]

    return text


def validate_uuid(value: str) -> bool:
    """Validate a UUID v4 string.

    Args:
        value: The string to validate as UUID.

    Returns:
        True if the string is a valid UUID.
    """
    uuid_pattern = re.compile(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
        re.IGNORECASE,
    )
    return bool(uuid_pattern.match(value))


def validate_salary_range(
    min_salary: Optional[int], max_salary: Optional[int]
) -> tuple[bool, str]:
    """Validate a salary range.

    Args:
        min_salary: Minimum salary (can be None).
        max_salary: Maximum salary (can be None).

    Returns:
        Tuple of (is_valid, message).
    """
    if min_salary is not None and min_salary < 0:
        return False, "Minimum salary cannot be negative"
    if max_salary is not None and max_salary < 0:
        return False, "Maximum salary cannot be negative"
    if min_salary is not None and max_salary is not None:
        if min_salary > max_salary:
            return False, "Minimum salary cannot exceed maximum salary"
    return True, "Valid"
