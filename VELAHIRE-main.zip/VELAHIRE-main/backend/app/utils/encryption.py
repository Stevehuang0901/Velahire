"""AES-256 encryption utilities for sensitive data."""
import json
import base64
from cryptography.fernet import Fernet

from app.core.config import settings


def _get_fernet() -> Fernet:
    key = settings.ENCRYPTION_KEY
    if not key:
        key = Fernet.generate_key().decode()
    if isinstance(key, str):
        key = key.encode()
    try:
        return Fernet(key)
    except Exception:
        key = base64.urlsafe_b64encode(key.ljust(32)[:32])
        return Fernet(key)


def encrypt_data(data: str) -> str:
    """Encrypt a string using AES-256 (Fernet)."""
    f = _get_fernet()
    return f.encrypt(data.encode()).decode()


def decrypt_data(encrypted: str) -> str:
    """Decrypt a Fernet-encrypted string."""
    f = _get_fernet()
    return f.decrypt(encrypted.encode()).decode()


def encrypt_oauth_tokens(tokens: dict) -> str:
    """Encrypt OAuth tokens for storage."""
    return encrypt_data(json.dumps(tokens))


def decrypt_oauth_tokens(encrypted: str) -> dict:
    """Decrypt stored OAuth tokens."""
    return json.loads(decrypt_data(encrypted))
