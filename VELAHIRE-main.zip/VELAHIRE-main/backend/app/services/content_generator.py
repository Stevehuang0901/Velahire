"""AI content generation service for cover letters, resume tailoring, and more."""

import json
import logging
from typing import Any, Optional

from anthropic import AsyncAnthropic
from openai import AsyncOpenAI
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings

logger = logging.getLogger(__name__)


class ContentGenerator:
    """Generates tailored job application content using both OpenAI and Anthropic LLMs."""

    def __init__(self) -> None:
        self.openai_client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        self.anthropic_client = AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)

    # ------------------------------------------------------------------
    # High-level orchestrator
    # ------------------------------------------------------------------

    async def generate_all(
        self,
        user_id: str,
        job: Any,
        style_tone: str = "professional",
        include_cover_letter: bool = True,
        include_background_statement: bool = False,
        open_questions: Optional[list[str]] = None,
        db: Optional[AsyncSession] = None,
    ) -> dict:
        """Generate all tailored application content for a user-job pair.

        Fetches the user's profile from the database, then delegates to
        individual generation methods.

        Returns a dict with keys: tailored_cv, cover_letter,
        background_statement, open_question_answers.
        """
        # Fetch profile data
        profile: dict = {}
        if db is not None:
            from app.models.profile import Profile
            from app.models.resume import Resume

            # Get latest resume
            result = await db.execute(
                select(Resume)
                .where(Resume.user_id == user_id)
                .order_by(Resume.is_primary.desc(), Resume.created_at.desc())
                .limit(1)
            )
            resume = result.scalar_one_or_none()
            if resume and resume.parsed_json:
                profile = resume.parsed_json

            # Enrich with profile data
            prof_result = await db.execute(
                select(Profile).where(Profile.user_id == user_id)
            )
            prof = prof_result.scalar_one_or_none()
            if prof:
                profile["skills"] = profile.get("skills", {})
                if prof.skills:
                    profile["skills"]["hard_skills"] = prof.skills
                if prof.summary:
                    profile["summary"] = prof.summary

        job_data = {
            "title": getattr(job, "title", ""),
            "company": getattr(job, "company", ""),
            "jd_text": getattr(job, "jd_text", ""),
            "required_skills": getattr(job, "required_skills", []),
            "location": getattr(job, "location", ""),
        }

        result: dict[str, Any] = {}

        # Tailor CV
        result["tailored_cv"] = await self.tailor_resume(profile, job_data)

        # Cover letter
        if include_cover_letter:
            result["cover_letter"] = await self.generate_cover_letter(
                profile, job_data, style=style_tone
            )

        # Background statement
        if include_background_statement:
            result["background_statement"] = await self.generate_background_statement(
                profile, job_data
            )

        # Open questions
        if open_questions:
            result["open_question_answers"] = await self.answer_open_questions(
                open_questions, profile, job_data
            )

        return result

    # ------------------------------------------------------------------
    # Individual generators
    # ------------------------------------------------------------------

    async def generate_cover_letter(
        self, profile: dict, job: dict, style: str = "professional"
    ) -> str:
        """Generate a personalized cover letter for a specific job.

        Uses OpenAI to produce a compelling, natural-sounding cover letter
        that connects the candidate's background to the job requirements.
        """
        skills_list = profile.get("skills", {})
        hard_skills = skills_list.get("hard_skills", []) if isinstance(skills_list, dict) else []

        prompt = f"""Write a compelling cover letter for the following candidate and job position.

CANDIDATE PROFILE:
- Name: {profile.get('full_name', 'Candidate')}
- Summary: {profile.get('summary', '')}
- Key Skills: {', '.join(hard_skills[:10])}
- Recent Experience: {json.dumps(profile.get('experience', [])[:2], indent=2)}

JOB DETAILS:
- Title: {job.get('title', '')}
- Company: {job.get('company', '')}
- Location: {job.get('location', '')}
- Description: {str(job.get('jd_text', ''))[:2000]}

STYLE: {style}

Requirements:
1. Address why the candidate is a strong fit for THIS specific role
2. Reference specific skills/experiences that match the JD
3. Show genuine interest in the company
4. Keep it concise (3-4 paragraphs)
5. Sound natural and human, not robotic
6. Do not fabricate experiences or skills not in the profile"""

        response = await self.openai_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=1000,
        )
        return response.choices[0].message.content or ""

    async def tailor_resume(self, profile: dict, job: dict) -> dict:
        """Tailor resume content to match a specific job description.

        Adjusts wording to incorporate job-description keywords while
        keeping all information truthful. Returns optimized resume fields.
        """
        prompt = f"""Optimize this resume data for the target job. Adjust wording to better match
the job description keywords while keeping all information truthful.

RESUME DATA:
{json.dumps(profile, indent=2)}

TARGET JOB:
- Title: {job.get('title', '')}
- Company: {job.get('company', '')}
- Key Requirements: {str(job.get('jd_text', ''))[:1500]}

Return a JSON object with the optimized resume fields:
- summary: optimized professional summary
- experience: list of experience entries with optimized descriptions
- skills: reorganized skills highlighting relevant ones first
- keywords_added: list of JD keywords incorporated

Return ONLY valid JSON."""

        response = await self.openai_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)

    async def generate_background_statement(self, profile: dict, job: dict) -> str:
        """Generate a 'Why I am a fit' background statement using Anthropic.

        Produces 2-3 paragraphs connecting the candidate's experience to
        the role requirements.
        """
        skills_list = profile.get("skills", {})
        hard_skills = skills_list.get("hard_skills", []) if isinstance(skills_list, dict) else []

        prompt = f"""Write a concise background statement explaining why this candidate
is an excellent fit for this specific position.

Candidate: {profile.get('summary', '')}
Key Skills: {', '.join(hard_skills[:8])}
Target Role: {job.get('title', '')} at {job.get('company', '')}
Job Requirements: {str(job.get('jd_text', ''))[:1000]}

Write 2-3 paragraphs that connect the candidate's experience to the role requirements.
Be specific, genuine, and compelling."""

        response = await self.anthropic_client.messages.create(
            model=settings.ANTHROPIC_MODEL,
            max_tokens=800,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text

    async def answer_open_questions(
        self, questions: list[str], profile: dict, job: dict
    ) -> list[dict]:
        """Generate thoughtful answers for open-ended application questions.

        Each answer is 100-200 words, specific, and grounded in the
        candidate's actual experience.
        """
        skills_list = profile.get("skills", {})
        hard_skills = skills_list.get("hard_skills", []) if isinstance(skills_list, dict) else []

        answers = []
        for question in questions:
            prompt = f"""Answer this job application question based on the candidate's profile.

Question: {question}

Candidate Profile:
- Summary: {profile.get('summary', '')}
- Skills: {', '.join(hard_skills[:8])}
- Experience: {json.dumps(profile.get('experience', [])[:2])}

Job: {job.get('title', '')} at {job.get('company', '')}

Write a thoughtful, specific answer (100-200 words). Sound natural and genuine.
Do not fabricate experiences."""

            response = await self.openai_client.chat.completions.create(
                model=settings.OPENAI_MODEL,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.6,
                max_tokens=400,
            )
            answers.append({
                "question": question,
                "answer": response.choices[0].message.content or "",
            })
        return answers

    async def clone_writing_style(self, sample_text: str, content: str) -> str:
        """Rewrite content to match the writing style of a sample text.

        Useful for ensuring generated content sounds like the candidate's
        own voice.
        """
        prompt = f"""Analyze the writing style of the SAMPLE TEXT, then rewrite the CONTENT
to match that style. Preserve all factual information.

SAMPLE TEXT (for style reference):
{sample_text[:1000]}

CONTENT TO REWRITE:
{content}

Rewrite the content in the same tone, vocabulary level, and sentence structure
as the sample. Return only the rewritten text."""

        response = await self.anthropic_client.messages.create(
            model=settings.ANTHROPIC_MODEL,
            max_tokens=1500,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text
