"""Job matching service -- ATS scoring, semantic matching, and job ranking."""

import json
import logging
import math
from typing import Any, Optional

from openai import AsyncOpenAI
from qdrant_client import AsyncQdrantClient
from qdrant_client.models import Distance, PointStruct, VectorParams
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import settings

logger = logging.getLogger(__name__)


class JobMatcher:
    """Matches candidate profiles against job descriptions using LLM analysis
    and vector similarity search."""

    def __init__(self) -> None:
        self.llm_client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        self.qdrant_client = AsyncQdrantClient(url=settings.QDRANT_URL)
        self.embedding_model = settings.OPENAI_EMBEDDING_MODEL
        self.collection_name = settings.QDRANT_COLLECTION

    # ------------------------------------------------------------------
    # ATS / keyword scoring
    # ------------------------------------------------------------------

    async def calculate_ats_score(
        self, profile_data: dict, job_data: dict
    ) -> dict[str, Any]:
        """Compute a detailed ATS-style match score between a candidate profile
        and a job description using LLM analysis.

        Returns a dict with granular scoring dimensions plus keyword diagnostics.
        """
        prompt = f"""You are an expert ATS (Applicant Tracking System) analyser.

Compare the following candidate profile against the job description and produce
a detailed compatibility report.

=== CANDIDATE PROFILE ===
{json.dumps(profile_data, indent=2)}

=== JOB DESCRIPTION ===
{json.dumps(job_data, indent=2)}

Return a JSON object with exactly these keys:
- skill_match: float 0-100 (percentage of required skills the candidate has)
- experience_match: float 0-100 (how well experience level and domain match)
- education_match: float 0-100 (how well education meets requirements)
- keyword_overlap: float 0-100 (keyword density match between resume and JD)
- overall_score: float 0-100 (weighted composite score)
- matched_keywords: [list of keywords/skills found in both profile and JD]
- missing_keywords: [list of important JD keywords absent from the profile]
- score_breakdown: {{
    "skill_weight": float (weight used, e.g. 0.35),
    "experience_weight": float,
    "education_weight": float,
    "keyword_weight": float
  }}
- recommendations: [list of actionable suggestions to improve the match]

Return ONLY valid JSON, no markdown."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
            response_format={"type": "json_object"},
        )
        result = json.loads(response.choices[0].message.content)
        logger.info(
            "ATS score calculated: overall=%.1f", result.get("overall_score", 0)
        )
        return result

    def keyword_match(self, profile_skills: list[str], job_skills: list[str]) -> dict[str, Any]:
        """Fast keyword matching without LLM -- compares skill lists directly.

        Returns matched_skills, missing_skills, and overlap percentage.
        """
        profile_set = {s.lower().strip() for s in profile_skills}
        job_set = {s.lower().strip() for s in job_skills}
        matched = profile_set & job_set
        missing = job_set - profile_set

        overlap = (len(matched) / len(job_set) * 100) if job_set else 0

        return {
            "matched_skills": sorted(matched),
            "missing_skills": sorted(missing),
            "overlap_percentage": round(overlap, 1),
        }

    def compute_composite_score(
        self,
        ats_score: float,
        semantic_score: float,
        keyword_score: float,
        weights: Optional[dict[str, float]] = None,
    ) -> float:
        """Compute a weighted composite match score from individual dimensions.

        Default weights: ATS 0.4, semantic 0.35, keyword 0.25.
        """
        w = weights or {"ats": 0.4, "semantic": 0.35, "keyword": 0.25}
        return round(
            ats_score * w.get("ats", 0.4)
            + semantic_score * w.get("semantic", 0.35)
            + keyword_score * w.get("keyword", 0.25),
            2,
        )

    # ------------------------------------------------------------------
    # Vector / semantic matching
    # ------------------------------------------------------------------

    async def generate_embedding(self, text: str) -> list[float]:
        """Generate a vector embedding for the supplied text using OpenAI."""
        text = text.replace("\n", " ").strip()
        if not text:
            raise ValueError("Cannot generate embedding for empty text.")

        response = await self.llm_client.embeddings.create(
            model=self.embedding_model,
            input=text,
        )
        return response.data[0].embedding

    async def semantic_match(
        self, profile_embedding: list[float], job_embeddings: list[list[float]]
    ) -> float:
        """Compute the best cosine similarity between a profile embedding and a
        list of job embeddings. Returns a float between -1.0 and 1.0."""
        if not job_embeddings:
            return 0.0

        best_score = -1.0
        for job_emb in job_embeddings:
            score = self._cosine_similarity(profile_embedding, job_emb)
            if score > best_score:
                best_score = score
        return best_score

    @staticmethod
    def _cosine_similarity(vec_a: list[float], vec_b: list[float]) -> float:
        """Pure-Python cosine similarity between two vectors."""
        dot = sum(a * b for a, b in zip(vec_a, vec_b))
        norm_a = math.sqrt(sum(a * a for a in vec_a))
        norm_b = math.sqrt(sum(b * b for b in vec_b))
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)

    # ------------------------------------------------------------------
    # Ranking & recommendations
    # ------------------------------------------------------------------

    async def rank_jobs(
        self,
        profile: dict,
        jobs: list[dict],
        preferences: dict,
    ) -> list[dict]:
        """Rank a list of jobs for a given profile, respecting user preferences.

        Returns the jobs list sorted by composite score (descending), each
        augmented with match_score, ats_breakdown, and rank.
        """
        prompt = f"""You are an intelligent job-ranking engine.

Given the candidate profile, their preferences, and a list of job postings,
rank the jobs from best to worst fit.

=== CANDIDATE PROFILE ===
{json.dumps(profile, indent=2)}

=== USER PREFERENCES ===
{json.dumps(preferences, indent=2)}

=== JOB LISTINGS ===
{json.dumps(jobs, indent=2)}

For each job produce a JSON object with:
- job_id: (use the "id" field from the job, or the index if missing)
- match_score: float 0-100
- ats_score: float 0-100
- preference_score: float 0-100 (how well it meets stated preferences)
- composite_score: float 0-100 (weighted combination)
- rationale: string (1-2 sentence explanation)

Return a JSON object with key "ranked_jobs" containing the list sorted by
composite_score descending.

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.15,
            response_format={"type": "json_object"},
        )
        result = json.loads(response.choices[0].message.content)
        ranked = result.get("ranked_jobs", [])

        for idx, job in enumerate(ranked, start=1):
            job["rank"] = idx

        logger.info("Ranked %d jobs for profile", len(ranked))
        return ranked

    async def get_recommendations(
        self, user_id: str, db: AsyncSession, limit: int = 10
    ) -> list[dict]:
        """Get AI-powered job recommendations for a user.

        Fetches the user's top matches from the database, ordered by
        ATS score. In a full implementation this would incorporate
        semantic search against the Qdrant vector store and collaborative
        filtering signals.
        """
        from app.models.match import Match

        result = await db.execute(
            select(Match)
            .options(selectinload(Match.job))
            .where(Match.user_id == user_id)
            .order_by(Match.ats_score.desc().nullslast())
            .limit(limit)
        )
        matches = result.scalars().all()

        recommendations = []
        for m in matches:
            kw = m.keyword_matches or {}
            recommendations.append({
                "job": m.job,
                "match_id": m.id,
                "ats_score": m.ats_score or 0,
                "skill_matches": kw.get("matched_skills", []),
                "missing_skills": kw.get("missing_skills", []),
                "keyword_analysis": kw,
                "status": str(m.status),
            })
        return recommendations

    # ------------------------------------------------------------------
    # Market analysis
    # ------------------------------------------------------------------

    async def analyze_market(self, industry: str, role: str) -> dict[str, Any]:
        """Return a market analysis snapshot for a given industry and role.

        Includes job volume estimates, salary ranges, trending skills, top
        employers, and competition level.
        """
        prompt = f"""You are a labour-market research analyst.

Provide a comprehensive market analysis for the following:
- Industry: {industry}
- Role: {role}

Return a JSON object with:
- job_count: int (estimated number of open positions in this role globally)
- avg_salary: {{
    "currency": "USD",
    "min": int,
    "max": int,
    "median": int
  }}
- top_companies: [list of top 10 companies hiring for this role]
- trending_skills: [list of top 10 in-demand skills for this role right now]
- competition_level: string ("low", "moderate", "high", or "very_high")
- growth_outlook: string (1-2 sentence outlook for the next 12 months)
- remote_availability: float 0-100 (percentage of postings offering remote)
- top_locations: [list of top 5 geographic hubs for this role]

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            response_format={"type": "json_object"},
        )
        result = json.loads(response.choices[0].message.content)
        logger.info(
            "Market analysis for %s / %s: competition=%s",
            industry,
            role,
            result.get("competition_level"),
        )
        return result

    async def market_analysis(self, role: str, location: Optional[str] = None) -> dict[str, Any]:
        """High-level market analysis returning MarketAnalysisResponse-compatible data."""
        analysis = await self.analyze_market(industry="general", role=role)
        return {
            "role": role,
            "demand_trend": analysis.get("competition_level", "moderate"),
            "avg_salary": analysis.get("avg_salary", {}).get("median", 0),
            "top_skills": analysis.get("trending_skills", []),
            "top_companies": analysis.get("top_companies", []),
            "geographic_hotspots": analysis.get("top_locations", []),
            "outlook": analysis.get("growth_outlook", ""),
        }
