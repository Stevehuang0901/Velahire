"""Interview preparation and mock interview service."""

import json
import logging
import uuid
from typing import Any, Optional

from openai import AsyncOpenAI

from app.core.config import settings

logger = logging.getLogger(__name__)


class InterviewService:
    """Generates interview preparation materials, conducts mock interviews,
    and provides AI-powered feedback on candidate answers."""

    def __init__(self) -> None:
        self.llm_client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

    async def generate_prep_materials(
        self,
        job_title: str,
        company: str,
        jd_text: str = "",
        focus_areas: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """Generate comprehensive interview preparation materials.

        Returns a dict matching InterviewPrepResponse: company_info,
        role_analysis, common_questions, star_examples, company_news,
        competitors.
        """
        focus = f"\nFocus particularly on: {', '.join(focus_areas)}" if focus_areas else ""

        prompt = f"""Generate comprehensive interview preparation materials.

Company: {company}
Role: {job_title}
Job Description: {jd_text[:2000]}
{focus}

Return a JSON object with:
- company_info: {{ "name": string, "overview": string, "culture": string, "values": [list], "recent_developments": string }}
- role_analysis: {{ "key_responsibilities": [list], "required_skills": [list], "nice_to_haves": [list], "growth_potential": string }}
- common_questions: [list of {{ "category": string, "question": string, "tips": string, "sample_answer": string }}] (at least 8 questions mixing behavioral/technical/situational)
- star_examples: [list of {{ "competency": string, "situation": string, "task": string, "action": string, "result": string }}] (at least 3)
- company_news: [list of {{ "headline": string, "summary": string, "relevance": string }}] (3-5 items)
- competitors: [list of {{ "name": string, "comparison": string }}] (3-5 competitors)

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.4,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)

    async def generate_questions(
        self, job_title: str, company: str, jd_text: str = ""
    ) -> dict[str, Any]:
        """Generate categorized interview questions for a specific job.

        Returns behavioral_questions, technical_questions, and
        situational_questions lists.
        """
        prompt = f"""Generate likely interview questions for this role.

Role: {job_title} at {company}
Job Description: {jd_text[:1500]}

Return a JSON object with:
- behavioral_questions: [list of 5 questions with tips]
- technical_questions: [list of 5 questions with key_points]
- situational_questions: [list of 3 questions with recommended_approach]

Each item should be a dict with "question" and appropriate guidance field.
Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.4,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)

    async def mock_interview_session(
        self,
        job_title: str,
        company: str,
        interview_type: str = "behavioral",
        num_questions: int = 5,
    ) -> dict[str, Any]:
        """Create a new mock interview session with generated questions.

        Returns a dict matching MockInterviewResponse: questions list and
        session_id.
        """
        session_id = str(uuid.uuid4())

        prompt = f"""Generate {num_questions} {interview_type} interview questions for a
{job_title} role at {company}.

Return a JSON object with key "questions" containing a list of objects:
- question: the interview question
- category: {interview_type}
- difficulty: "easy" | "medium" | "hard"
- time_limit_minutes: int (suggested)

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            response_format={"type": "json_object"},
        )
        data = json.loads(response.choices[0].message.content)

        return {
            "questions": data.get("questions", []),
            "session_id": session_id,
        }

    async def evaluate_answers(
        self, session_id: str, answers: list[dict[str, str]]
    ) -> dict[str, Any]:
        """Evaluate a set of mock interview answers and provide feedback.

        Returns a dict matching InterviewFeedbackResponse: overall_score,
        per_question_feedback, strengths, improvements, recommendation.
        """
        prompt = f"""You are an expert interview coach. Evaluate these interview answers.

Answers:
{json.dumps(answers, indent=2)}

For each answer, evaluate on: relevance (0-100), structure (0-100), specificity (0-100), communication (0-100).

Return a JSON object with:
- overall_score: float 0-100 (weighted average across all answers)
- per_question_feedback: [list of {{
    "question": string,
    "score": float 0-100,
    "feedback": string,
    "improved_answer": string
  }}]
- strengths: [list of 3-5 strengths observed]
- improvements: [list of 3-5 areas to improve]
- recommendation: string (1-2 sentence overall recommendation)

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)

    async def get_company_research(self, company_name: str) -> dict[str, Any]:
        """Generate a company research summary for interview preparation.

        Returns overview, culture, recent news, competitors, and
        typical interview process details.
        """
        prompt = f"""Provide a research summary for interview preparation at {company_name}.

Return a JSON object with:
- name: string
- overview: string (2-3 sentences about the company)
- culture: string (work culture description)
- values: [list of company values]
- recent_news: [list of {{ "headline": string, "summary": string }}]
- competitors: [list of competitor names]
- interview_process: string (typical interview stages)
- tips: [list of interview tips specific to this company]

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)
