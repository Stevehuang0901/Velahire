"""Resume parsing service -- extracts structured data from PDF/DOCX/text resumes."""

import io
import json
import logging
from typing import Any, Optional

from docx import Document
from openai import AsyncOpenAI
from PyPDF2 import PdfReader

from app.core.config import settings

logger = logging.getLogger(__name__)


class ResumeParser:
    """Parses resumes into structured JSON and provides ATS scoring,
    optimization, and career-path analysis via LLM."""

    def __init__(self) -> None:
        self.llm_client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def parse(self, file_content: bytes, file_type: str) -> dict:
        """Parse a resume file (PDF, DOCX, or plain text) and return structured data.

        Args:
            file_content: Raw bytes of the uploaded file.
            file_type: MIME type of the file.

        Returns:
            A dictionary with keys: full_name, email, phone, location, summary,
            skills, experience, education, projects.
        """
        if file_type == "application/pdf":
            text = self._extract_pdf_text(file_content)
        elif file_type in (
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/msword",
        ):
            text = self._extract_docx_text(file_content)
        else:
            text = file_content.decode("utf-8", errors="ignore")

        return await self._llm_parse(text)

    async def score_resume(
        self, parsed_data: dict, target_role: Optional[str] = None
    ) -> dict:
        """Score a parsed resume for ATS friendliness.

        Returns a dict with overall_score, formatting_score, keyword_density_score,
        quantification_score, layout_score, suggestions, and industry_comparison.
        """
        prompt = f"""Analyze this parsed resume data and score it for ATS friendliness.

Resume data: {json.dumps(parsed_data)}
{"Target role: " + target_role if target_role else ""}

Score each category from 0 to 100 and provide specific suggestions.
Return a JSON object with:
- overall_score: float (0-100)
- formatting_score: float (0-100)
- keyword_density_score: float (0-100)
- quantification_score: float (0-100, how well achievements are quantified)
- layout_score: float (0-100)
- suggestions: [list of specific improvement suggestions]
- strengths: [list of resume strengths]
- industry_comparison: {{ "level": "above_average" | "average" | "below_average", "notes": string }}

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)

    async def optimize_resume(
        self,
        parsed_json: dict,
        target_job_title: Optional[str] = None,
        target_keywords: Optional[list[str]] = None,
        style: str = "professional",
    ) -> dict:
        """Optimize a resume for a target role or set of keywords using AI.

        Returns the optimized parsed_json with improved content.
        """
        prompt = f"""Optimize this resume to improve its ATS score and appeal.

Current resume data:
{json.dumps(parsed_json, indent=2)}

{"Target job title: " + target_job_title if target_job_title else ""}
{"Target keywords: " + ", ".join(target_keywords) if target_keywords else ""}
Style: {style}

Instructions:
1. Rewrite the professional summary to better target the role.
2. Optimize experience descriptions with action verbs and quantified results.
3. Reorder skills to highlight the most relevant ones first.
4. Incorporate target keywords naturally where truthful.
5. Do NOT fabricate any experiences or skills.

Return the full optimized resume data as a JSON object with the same structure as the input.
Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)

    async def career_path_analysis(self, parsed_json: dict) -> dict:
        """Analyze a resume and suggest career paths, skill gaps, and certifications.

        Returns a dict with current_role, suggested_paths, skill_gaps,
        recommended_certifications, and timeline_estimate.
        """
        prompt = f"""Analyze this resume and provide a career path analysis.

Resume data:
{json.dumps(parsed_json, indent=2)}

Return a JSON object with:
- current_role: string (inferred current role/level)
- suggested_paths: [list of {{ "role": string, "description": string, "fit_score": float 0-100 }}]
- skill_gaps: [list of skills the candidate should acquire]
- recommended_certifications: [list of certifications to pursue]
- timeline_estimate: string (estimated timeline for career progression)

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.4,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _extract_pdf_text(self, content: bytes) -> str:
        """Extract text from a PDF file."""
        reader = PdfReader(io.BytesIO(content))
        text = ""
        for page in reader.pages:
            text += page.extract_text() or ""
        return text

    def _extract_docx_text(self, content: bytes) -> str:
        """Extract text from a DOCX file."""
        doc = Document(io.BytesIO(content))
        return "\n".join(para.text for para in doc.paragraphs)

    async def _llm_parse(self, text: str) -> dict:
        """Use an LLM to extract structured information from raw resume text."""
        prompt = f"""Analyze this resume and extract structured information in JSON format.

Resume text:
{text}

Return a JSON object with these keys:
- full_name: string
- email: string
- phone: string
- location: string
- summary: string (professional summary)
- skills: {{
    "hard_skills": [list of technical/hard skills],
    "soft_skills": [list of soft skills],
    "languages": [list of spoken languages],
    "certifications": [list of certifications]
  }}
- experience: [list of {{
    "title": string,
    "company": string,
    "location": string,
    "start_date": string,
    "end_date": string or "Present",
    "description": string,
    "achievements": [list of key achievements]
  }}]
- education: [list of {{
    "degree": string,
    "institution": string,
    "graduation_date": string,
    "gpa": string or null,
    "major": string
  }}]
- projects: [list of {{
    "name": string,
    "description": string,
    "technologies": [list]
  }}]

Return ONLY valid JSON, no markdown formatting."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)
