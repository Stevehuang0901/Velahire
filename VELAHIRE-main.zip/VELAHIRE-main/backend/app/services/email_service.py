"""Email integration service -- OAuth connections, OTP extraction, classification, and reply drafting."""

import json
import logging
import re
from typing import Any, Optional

from openai import AsyncOpenAI

from app.core.config import settings

logger = logging.getLogger(__name__)

OTP_PATTERNS = [
    r"(?:code|Code|CODE)[:\s]*(\d{4,8})",
    r"(?:OTP|otp)[:\s]*(\d{4,8})",
    r"(?:verification|Verification)[:\s]*(\d{4,8})",
    r"(?:passcode|Passcode)[:\s]*(\d{4,8})",
    r"\b(\d{6})\b",  # fallback: standalone 6-digit number
]


class EmailService:
    """Handles email OAuth connections, inbound email monitoring, OTP
    extraction, classification, and AI-generated reply drafts."""

    def __init__(self) -> None:
        self.llm_client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

    # ------------------------------------------------------------------
    # OAuth connections
    # ------------------------------------------------------------------

    async def connect_gmail_oauth(self, oauth_token: str) -> bool:
        """Connect a Gmail account using an OAuth2 access token.

        In production this would use the Gmail API via google-auth to
        verify the token and set up push notifications for new emails.
        """
        logger.info("Connecting Gmail account via OAuth")
        # TODO: Validate token with Google, store refresh token
        return True

    async def connect_outlook_oauth(self, oauth_token: str) -> bool:
        """Connect an Outlook/Microsoft account using an OAuth2 access token.

        In production this would use the Microsoft Graph API to verify
        the token and register a subscription for mail notifications.
        """
        logger.info("Connecting Outlook account via OAuth")
        # TODO: Validate token with Microsoft, store refresh token
        return True

    # ------------------------------------------------------------------
    # Email monitoring
    # ------------------------------------------------------------------

    async def listen_for_emails(self, user_id: str) -> None:
        """Start monitoring for inbound emails related to job applications.

        In production this would set up a webhook or polling loop against
        the Gmail / Outlook API to detect new messages matching known
        application senders.
        """
        logger.info("Starting email listener for user %s", user_id)
        # TODO: Implement real-time email monitoring via push notifications
        pass

    # ------------------------------------------------------------------
    # OTP extraction
    # ------------------------------------------------------------------

    async def extract_otp(self, email_content: str) -> Optional[str]:
        """Extract an OTP / verification code from email body text.

        Tries a series of regex patterns from most specific to least.
        Returns the first match or None.
        """
        for pattern in OTP_PATTERNS:
            match = re.search(pattern, email_content)
            if match:
                return match.group(1)
        return None

    # ------------------------------------------------------------------
    # Classification
    # ------------------------------------------------------------------

    async def classify_email(self, subject: str, body: str) -> dict[str, Any]:
        """Classify an inbound email using AI.

        Returns a dict with type (interview_invite, rejection, follow_up,
        offer, otp, info_request, other), confidence, summary,
        action_required flag, and suggested_action.
        """
        prompt = f"""Classify this email from a recruiter/employer.

Subject: {subject}
Body (first 500 chars): {body[:500]}

Return JSON with:
- type: one of "interview_invite", "rejection", "follow_up", "offer", "otp", "info_request", "other"
- confidence: float 0-1
- summary: brief one-line summary
- action_required: boolean
- suggested_action: string or null

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)

    # ------------------------------------------------------------------
    # Reply drafting
    # ------------------------------------------------------------------

    async def generate_reply_draft(
        self,
        email_content: str,
        classification: str,
        profile: dict,
    ) -> str:
        """Generate a professional draft reply based on the email classification.

        For interview invites: express enthusiasm and confirm availability.
        For info requests: provide requested information professionally.
        For follow-ups: maintain engagement while seeking clarity.
        """
        prompt = f"""Draft a professional reply to this email.

Original email: {email_content[:500]}
Email type: {classification}
Candidate name: {profile.get('full_name', 'Candidate')}

Write a brief, professional reply appropriate for the email type.
For interview invites: express enthusiasm and confirm availability.
For info requests: provide the requested information professionally.
For follow-ups: express continued interest and ask for next steps.
Keep it concise and natural."""

        response = await self.llm_client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=300,
        )
        return response.choices[0].message.content or ""
