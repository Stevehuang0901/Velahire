"""Salary intelligence service - salary ranges, comparisons, and market trends."""

import json
import logging
from typing import Any, Optional

from openai import AsyncOpenAI

from app.core.config import settings

logger = logging.getLogger(__name__)


class SalaryService:
    """Provides salary intelligence using AI analysis of market data.

    Offers salary range estimates, company compensation profiles,
    and market trend analysis for job seekers.
    """

    def __init__(self) -> None:
        self.llm_client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

    async def get_salary_insight(
        self,
        job_title: str,
        company: str,
        location: Optional[str] = None,
        industry: Optional[str] = None,
    ) -> dict[str, Any]:
        """Get comprehensive salary data for a specific job at a company.

        Args:
            job_title: The position title.
            company: The hiring company name.
            location: Optional geographic location.
            industry: Optional industry sector.

        Returns:
            Salary insight including range, percentiles, and negotiation tips.
        """
        prompt = f"""Provide salary intelligence for:

Job Title: {job_title}
Company: {company}
Location: {location or "United States"}
Industry: {industry or "Not specified"}

Return a JSON object with:
- "job_title": str
- "company": str
- "salary_range_min": float (annual USD)
- "salary_range_max": float (annual USD)
- "salary_median": float (annual USD)
- "currency": "USD"
- "percentile_25": float
- "percentile_75": float
- "data_source": str
- "negotiation_tips": [list of 3-5 tips]

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            response_format={"type": "json_object"},
        )
        result = json.loads(response.choices[0].message.content)
        logger.info("Salary insight for %s at %s: median=%s", job_title, company, result.get("salary_median"))
        return result

    async def get_salary_range(
        self,
        job_title: str,
        company: Optional[str] = None,
        location: Optional[str] = None,
    ) -> dict[str, Any]:
        """Get salary range data for a role. Simplified wrapper for comparisons.

        Args:
            job_title: The position title.
            company: Optional company name.
            location: Optional location.

        Returns:
            Dict with salary_range_min, salary_range_max, salary_median, currency.
        """
        return await self.get_salary_insight(
            job_title=job_title,
            company=company or "Industry Average",
            location=location,
        )

    async def get_company_info(self, company_name: str) -> dict[str, Any]:
        """Get compensation-relevant company information.

        Args:
            company_name: The company to research.

        Returns:
            Company profile with size, culture, and compensation philosophy.
        """
        prompt = f"""Provide compensation-relevant info about {company_name}.

Return a JSON object with:
- "company_name": str
- "industry": str
- "employee_count": str
- "compensation_philosophy": str
- "glassdoor_rating": float or null
- "benefits_highlights": [str]
- "culture_notes": [str]

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)

    async def get_market_trends(
        self,
        role: str,
        location: Optional[str] = None,
    ) -> dict[str, Any]:
        """Get salary market trends for a role over time.

        Args:
            role: The job role to analyze.
            location: Optional location filter.

        Returns:
            Trend data with historical progression and projections.
        """
        prompt = f"""Provide salary market trends for "{role}".
Location: {location or "United States"}

Return a JSON object with:
- "role": str
- "location": str or null
- "trend_data": [list of {{"period": str, "median_salary": float, "yoy_change_pct": float}}]
- "summary": str (2-3 sentence analysis)

Return ONLY valid JSON."""

        response = await self.llm_client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            response_format={"type": "json_object"},
        )
        result = json.loads(response.choices[0].message.content)
        logger.info("Market trends for %s retrieved", role)
        return result

    async def compare_salaries(
        self,
        job_titles: list[str],
        locations: Optional[list[str]] = None,
    ) -> list[dict[str, Any]]:
        """Compare salaries across multiple roles and optionally locations.

        Args:
            job_titles: List of job titles to compare.
            locations: Optional list of locations for regional comparison.

        Returns:
            List of comparison dicts with salary data for each role.
        """
        comparisons: list[dict[str, Any]] = []
        for title in job_titles:
            if locations:
                for loc in locations:
                    data = await self.get_salary_range(job_title=title, location=loc)
                    comparisons.append({
                        "job_title": title,
                        "location": loc,
                        "salary_range_min": data.get("salary_range_min", 0),
                        "salary_range_max": data.get("salary_range_max", 0),
                        "salary_median": data.get("salary_median", 0),
                        "currency": data.get("currency", "USD"),
                    })
            else:
                data = await self.get_salary_range(job_title=title)
                comparisons.append({
                    "job_title": title,
                    "location": "National Average",
                    "salary_range_min": data.get("salary_range_min", 0),
                    "salary_range_max": data.get("salary_range_max", 0),
                    "salary_median": data.get("salary_median", 0),
                    "currency": data.get("currency", "USD"),
                })
        return comparisons
