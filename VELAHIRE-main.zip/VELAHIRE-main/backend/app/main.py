"""VelaHire API -- AI Career Co-Pilot Platform.

Entry point for the FastAPI application.  Configures middleware, registers
all API routers, and exposes health-check endpoints.
"""

import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import applications, auth, dashboard, interview, jobs, resume, salary
from app.core.config import settings
from app.core.database import init_db

logger = logging.getLogger("velahire")


# ---------------------------------------------------------------------------
# Lifespan: startup / shutdown
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Handle application startup and shutdown events."""
    # Startup
    logger.info("Starting VelaHire API (%s)", settings.ENVIRONMENT)
    await init_db()

    # Optionally initialise Sentry
    if settings.SENTRY_DSN:
        try:
            import sentry_sdk
            from sentry_sdk.integrations.fastapi import FastApiIntegration

            sentry_sdk.init(
                dsn=settings.SENTRY_DSN,
                environment=settings.ENVIRONMENT,
                integrations=[FastApiIntegration()],
                traces_sample_rate=0.1,
            )
            logger.info("Sentry initialised")
        except Exception:
            logger.warning("Sentry initialisation failed", exc_info=True)

    yield

    # Shutdown
    logger.info("Shutting down VelaHire API")


# ---------------------------------------------------------------------------
# Application instance
# ---------------------------------------------------------------------------

app = FastAPI(
    title=settings.APP_NAME,
    description="AI-Powered Job Application Automation Platform",
    version=settings.APP_VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS
allowed_origins = [
    origin.strip()
    for origin in settings.ALLOWED_ORIGINS.split(",")
    if origin.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Router registration
# ---------------------------------------------------------------------------

app.include_router(auth.router, prefix="/api/v1")
app.include_router(resume.router, prefix="/api/v1")
app.include_router(jobs.router, prefix="/api/v1")
app.include_router(applications.router, prefix="/api/v1")
app.include_router(dashboard.router, prefix="/api/v1")
app.include_router(interview.router, prefix="/api/v1")
app.include_router(salary.router, prefix="/api/v1")

# ---------------------------------------------------------------------------
# Health & root endpoints
# ---------------------------------------------------------------------------


@app.get("/health", tags=["System"])
async def health_check() -> dict:
    """Liveness / readiness probe for container orchestrators."""
    return {
        "status": "healthy",
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
    }


@app.get("/", tags=["System"])
async def root() -> dict:
    """Root endpoint returning basic API information."""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs": "/docs",
    }
