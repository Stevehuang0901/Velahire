"""Pydantic schemas for resume-related endpoints."""

from datetime import datetime
from typing import Any, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class ResumeUploadResponse(BaseModel):
    """Returned after a successful resume upload and parsing."""

    id: UUID
    filename: str
    version_name: Optional[str] = None
    ats_score: Optional[float] = None
    parsed_json: Optional[dict[str, Any]] = None
    created_at: datetime

    model_config = {"from_attributes": True}


class ResumeScoreResponse(BaseModel):
    """ATS score breakdown for a resume."""

    score: float = Field(..., ge=0, le=100)
    formatting_score: float = Field(..., ge=0, le=100)
    keyword_density: float = Field(..., ge=0, le=100)
    quantification_score: float = Field(..., ge=0, le=100)
    layout_score: float = Field(..., ge=0, le=100)
    suggestions: list[str]
    industry_comparison: dict[str, Any]


class ResumeListResponse(BaseModel):
    """Paginated list of resumes."""

    resumes: list[ResumeUploadResponse]
    total: int


class ResumeOptimizeRequest(BaseModel):
    """Request body for AI-driven resume optimization."""

    target_job_title: Optional[str] = None
    target_keywords: Optional[list[str]] = None
    style: str = Field(default="professional", description="Tone/style preference")


class CareerPathResponse(BaseModel):
    """AI-generated career path analysis."""

    current_role: str
    suggested_paths: list[dict[str, Any]]
    skill_gaps: list[str]
    recommended_certifications: list[str]
    timeline_estimate: str
