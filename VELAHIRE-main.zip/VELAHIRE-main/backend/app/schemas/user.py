"""Pydantic schemas for user-related endpoints."""

from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, EmailStr


class UserCreate(BaseModel):
    """Schema for user registration."""

    email: EmailStr
    password: str
    full_name: str


class UserLogin(BaseModel):
    """Schema for user login."""

    email: EmailStr
    password: str


class UserResponse(BaseModel):
    """Schema returned to the client after auth or profile fetch."""

    id: UUID
    email: str
    full_name: str
    plan: str
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class UserUpdate(BaseModel):
    """Schema for updating user profile fields."""

    full_name: Optional[str] = None
    preferences: Optional[dict] = None


class TokenResponse(BaseModel):
    """Schema for JWT token response."""

    access_token: str
    token_type: str = "bearer"
    user: UserResponse


class OAuthRequest(BaseModel):
    """Schema for OAuth authorization code exchange."""

    code: str
    redirect_uri: str


class RefreshTokenRequest(BaseModel):
    """Schema for token refresh."""

    refresh_token: str
