"""Pydantic schemas for job-related endpoints."""

from datetime import datetime
from typing import Any, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class JobResponse(BaseModel):
    """Full job listing details."""

    id: UUID
    source: str
    external_id: Optional[str] = None
    url: Optional[str] = None
    title: str
    company: str
    location: Optional[str] = None
    job_type: Optional[str] = None
    salary_min: Optional[float] = None
    salary_max: Optional[float] = None
    salary_currency: Optional[str] = None
    jd_text: Optional[str] = None
    jd_parsed: Optional[dict[str, Any]] = None
    required_skills: Optional[list[str]] = None
    posted_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    is_remote: bool
    visa_sponsorship: Optional[bool] = None
    company_size: Optional[str] = None
    industry: Optional[str] = None
    created_at: datetime

    model_config = {"from_attributes": True}


class JobMatchResponse(BaseModel):
    """A job matched to the user's profile with scoring details."""

    job: JobResponse
    match_id: UUID
    ats_score: float = Field(..., ge=0, le=100)
    skill_matches: list[str]
    missing_skills: list[str]
    keyword_analysis: dict[str, Any]
    status: str


class JobSearchParams(BaseModel):
    """Query parameters for manual job search."""

    keyword: Optional[str] = None
    location: Optional[str] = None
    remote: Optional[bool] = None
    salary_min: Optional[float] = None
    salary_max: Optional[float] = None
    company_size: Optional[str] = None
    industry: Optional[str] = None
    page: int = Field(default=1, ge=1)
    limit: int = Field(default=20, ge=1, le=100)


class JobListResponse(BaseModel):
    """Paginated list of jobs."""

    jobs: list[JobResponse]
    total: int
    page: int


class JobTailorRequest(BaseModel):
    """Request to generate tailored application content for a job."""

    style_tone: str = Field(default="professional", description="Desired writing style")
    include_cover_letter: bool = True
    include_background_statement: bool = False
    open_questions: Optional[list[str]] = None


class MarketAnalysisResponse(BaseModel):
    """Market analysis for a given role / industry."""

    role: str
    demand_trend: str
    avg_salary: float
    top_skills: list[str]
    top_companies: list[str]
    geographic_hotspots: list[str]
    outlook: str
