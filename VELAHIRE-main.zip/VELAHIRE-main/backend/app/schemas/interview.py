"""Pydantic schemas for interview and salary-related endpoints."""

from typing import Any, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class InterviewPrepRequest(BaseModel):
    """Request for interview preparation materials."""

    match_id: UUID
    focus_areas: Optional[list[str]] = None


class InterviewPrepResponse(BaseModel):
    """AI-generated interview preparation package."""

    company_info: dict[str, Any]
    role_analysis: dict[str, Any]
    common_questions: list[dict[str, Any]]
    star_examples: list[dict[str, Any]]
    company_news: list[dict[str, Any]]
    competitors: list[dict[str, Any]]


class MockInterviewRequest(BaseModel):
    """Request for a mock interview session."""

    job_title: str
    company: str
    interview_type: str = "behavioral"
    num_questions: int = Field(default=5, ge=1, le=20)


class MockInterviewResponse(BaseModel):
    """Mock interview session with questions and model answers."""

    questions: list[dict[str, str]]
    session_id: str


class InterviewFeedbackRequest(BaseModel):
    """User's answers for AI feedback."""

    session_id: str
    answers: list[dict[str, str]]


class InterviewFeedbackResponse(BaseModel):
    """AI feedback on user's interview answers."""

    overall_score: float = Field(..., ge=0, le=100)
    per_question_feedback: list[dict[str, Any]]
    strengths: list[str]
    improvements: list[str]
    recommendation: str


class SalaryInsightResponse(BaseModel):
    """Salary intelligence for a given job."""

    job_title: str
    company: str
    salary_range_min: float
    salary_range_max: float
    salary_median: float
    currency: str
    percentile_25: float
    percentile_75: float
    data_source: str
    negotiation_tips: list[str]


class SalaryCompareRequest(BaseModel):
    """Compare salaries across roles or locations."""

    job_titles: list[str]
    locations: Optional[list[str]] = None


class SalaryCompareResponse(BaseModel):
    """Side-by-side salary comparison."""

    comparisons: list[dict[str, Any]]


class MarketTrendsResponse(BaseModel):
    """Salary market trends over time."""

    role: str
    location: Optional[str] = None
    trend_data: list[dict[str, Any]]
    summary: str
