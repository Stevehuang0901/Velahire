"""Pydantic schemas for application-related endpoints."""

from datetime import datetime
from typing import Any, Literal, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class ApplicationCreate(BaseModel):
    """Request to submit a job application."""

    match_id: UUID
    mode: Literal["copilot", "autopilot"]


class ApplicationResponse(BaseModel):
    """Detailed application record."""

    id: UUID
    match_id: UUID
    status: str
    applied_at: Optional[datetime] = None
    platform_response: Optional[str] = None
    error_log: Optional[str] = None
    retry_count: int
    created_at: datetime

    model_config = {"from_attributes": True}


class ApplicationStatusUpdate(BaseModel):
    """Manual status update for an application."""

    status: str


class DashboardStats(BaseModel):
    """Aggregated statistics for the user's application dashboard."""

    total_applied: int
    response_rate: float = Field(..., ge=0, le=100)
    interview_rate: float = Field(..., ge=0, le=100)
    offer_rate: float = Field(..., ge=0, le=100)
    by_status: dict[str, int]
    by_platform: dict[str, int]
    weekly_trend: list[dict[str, Any]]


class BulkApplyRequest(BaseModel):
    """Request to apply to multiple matched jobs at once."""

    match_ids: list[UUID]
    mode: Literal["copilot", "autopilot"] = "copilot"


class BulkApplyResponse(BaseModel):
    """Result of a bulk apply operation."""

    submitted: int
    failed: int
    details: list[dict[str, Any]]
