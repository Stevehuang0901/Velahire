"""SmartRecruiters ATS platform adapter.

Uses the SmartRecruiters API where available and falls back
to form-based automation for career-site applications.
"""

import logging
from typing import Any, Optional

import httpx
from playwright.async_api import Page

from app.adapters.base import ApplicationData, BasePlatformAdapter, FormField
from app.utils.anti_detection import (
    random_delay,
    simulate_human_typing,
    random_mouse_movement,
)

logger = logging.getLogger(__name__)


class SmartRecruitersAdapter(BasePlatformAdapter):
    """Adapter for SmartRecruiters ATS.

    SmartRecruiters offers a public API for some operations, which is
    preferred over browser automation. When the API is not available,
    this adapter falls back to Playwright-based form filling.
    """

    platform_name = "smart_recruiters"
    base_url = "https://jobs.smartrecruiters.com"
    API_BASE = "https://api.smartrecruiters.com"

    SELECTORS = {
        "first_name": "input[name='firstName'], input[id*='firstName']",
        "last_name": "input[name='lastName'], input[id*='lastName']",
        "email": "input[name='email'], input[id*='email']",
        "phone": "input[name='phoneNumber'], input[id*='phone']",
        "resume_upload": "input[type='file']",
        "location": "input[name='location'], input[id*='location']",
        "submit_button": "button[type='submit'], button.apply-button",
        "consent_checkbox": "input[type='checkbox'][name*='consent']",
    }

    def __init__(self, api_key: Optional[str] = None) -> None:
        super().__init__()
        self._api_key = api_key
        self._credentials: dict[str, str] = {}

    @property
    def _has_api_access(self) -> bool:
        return bool(self._api_key)

    async def login(self, credentials: dict[str, str]) -> bool:
        """Store credentials or API key for SmartRecruiters.

        Args:
            credentials: Dict with 'email', 'password', and optionally 'api_key'.

        Returns:
            True.
        """
        self._credentials = credentials
        if "api_key" in credentials:
            self._api_key = credentials["api_key"]
        return True

    async def fill_application(self, page: Page, data: ApplicationData) -> bool:
        """Fill out a SmartRecruiters application.

        Attempts API submission first; falls back to form automation.

        Args:
            page: Playwright page (used for form-based fallback).
            data: Application data to populate.

        Returns:
            True if the form was filled successfully.
        """
        try:
            await page.set_extra_http_headers(self.anti_detection_headers())
            await random_delay(1.0, 2.0)

            # Fill standard fields
            await self._fill_standard_fields(page, data)

            # Upload resume
            await self._upload_resume(page, data)

            # Fill custom questions
            await self._fill_custom_questions(page, data)

            # Handle consent checkboxes
            await self._handle_consent(page)

            return True

        except Exception as e:
            logger.error(
                "Failed to fill SmartRecruiters application: %s", str(e)
            )
            return False

    async def submit(self, page: Page) -> dict[str, Any]:
        """Submit the SmartRecruiters application.

        Args:
            page: Playwright page with completed form.

        Returns:
            Dict with submission result.
        """
        try:
            submit_btn = await page.query_selector(self.SELECTORS["submit_button"])
            if not submit_btn:
                return {"success": False, "error": "Submit button not found"}

            await random_mouse_movement(page)
            await random_delay(0.5, 1.5)
            await submit_btn.click()
            await self._wait_for_navigation(page)

            # Check for success
            success = await page.query_selector(
                ".success-message, .confirmation, .thank-you"
            )
            if success:
                text = await success.inner_text()
                return {
                    "success": True,
                    "confirmation_id": text.strip(),
                    "platform": self.platform_name,
                }

            errors = await page.query_selector_all(".error, .field-error")
            if errors:
                error_texts = []
                for err in errors:
                    error_texts.append((await err.inner_text()).strip())
                return {"success": False, "error": "; ".join(error_texts)}

            return {"success": True, "platform": self.platform_name}

        except Exception as e:
            logger.error("SmartRecruiters submission failed: %s", str(e))
            return {"success": False, "error": str(e)}

    # ------------------------------------------------------------------ #
    # API-based methods
    # ------------------------------------------------------------------ #

    async def apply_via_api(
        self, posting_id: str, data: ApplicationData
    ) -> dict[str, Any]:
        """Submit an application via the SmartRecruiters API.

        This is preferred over browser automation when an API key is available.

        Args:
            posting_id: The SmartRecruiters posting/job ID.
            data: Application data.

        Returns:
            Dict with submission result.
        """
        if not self._has_api_access:
            return {"success": False, "error": "No API key configured"}

        url = f"{self.API_BASE}/postings/{posting_id}/candidates"
        headers = {
            "X-SmartToken": self._api_key,
            "Content-Type": "application/json",
        }

        payload = {
            "firstName": data.first_name,
            "lastName": data.last_name,
            "email": data.email,
            "phoneNumber": data.phone,
            "web": {
                "linkedIn": data.linkedin_url or "",
                "portfolio": data.portfolio_url or "",
            },
            "tags": [],
        }

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(url, json=payload, headers=headers)

                if response.status_code in (200, 201):
                    result = response.json()
                    candidate_id = result.get("id", "")

                    # Upload resume if candidate was created
                    if candidate_id and data.resume_path:
                        await self._upload_resume_via_api(
                            candidate_id, data.resume_path
                        )

                    return {
                        "success": True,
                        "confirmation_id": candidate_id,
                        "platform": self.platform_name,
                        "method": "api",
                    }
                else:
                    return {
                        "success": False,
                        "error": f"API returned {response.status_code}: {response.text}",
                    }

        except Exception as e:
            logger.error("SmartRecruiters API submission failed: %s", str(e))
            return {"success": False, "error": str(e)}

    async def get_job_details(self, posting_id: str) -> Optional[dict[str, Any]]:
        """Fetch job posting details via API.

        Args:
            posting_id: SmartRecruiters posting ID.

        Returns:
            Job details dict or None.
        """
        if not self._has_api_access:
            return None

        url = f"{self.API_BASE}/postings/{posting_id}"
        headers = {"X-SmartToken": self._api_key}

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(url, headers=headers)
                if response.status_code == 200:
                    return response.json()
        except Exception as e:
            logger.error("Failed to fetch SR job details: %s", str(e))

        return None

    # ------------------------------------------------------------------ #
    # Private helpers
    # ------------------------------------------------------------------ #

    async def _upload_resume_via_api(
        self, candidate_id: str, resume_path: str
    ) -> bool:
        """Upload a resume via the SmartRecruiters API."""
        url = f"{self.API_BASE}/candidates/{candidate_id}/attachments"
        headers = {"X-SmartToken": self._api_key}

        try:
            async with httpx.AsyncClient() as client:
                with open(resume_path, "rb") as f:
                    files = {"file": (resume_path.split("/")[-1], f)}
                    response = await client.post(
                        url, files=files, headers=headers
                    )
                    return response.status_code in (200, 201)
        except Exception as e:
            logger.error("SR resume API upload failed: %s", str(e))
            return False

    async def _fill_standard_fields(
        self, page: Page, data: ApplicationData
    ) -> None:
        """Fill standard SmartRecruiters form fields."""
        field_map = {
            self.SELECTORS["first_name"]: data.first_name,
            self.SELECTORS["last_name"]: data.last_name,
            self.SELECTORS["email"]: data.email,
            self.SELECTORS["phone"]: data.phone,
        }

        for selector, value in field_map.items():
            if not value:
                continue
            el = await page.query_selector(selector)
            if el:
                await el.click()
                await random_delay(0.1, 0.3)
                await simulate_human_typing(page, selector, value)
                await random_delay(0.2, 0.5)

    async def _upload_resume(self, page: Page, data: ApplicationData) -> None:
        """Upload resume via the form file input."""
        if not data.resume_path:
            return

        file_input = await page.query_selector(self.SELECTORS["resume_upload"])
        if file_input:
            await file_input.set_input_files(data.resume_path)
            await random_delay(1.5, 3.0)
            logger.info("Resume uploaded to SmartRecruiters form")

    async def _fill_custom_questions(
        self, page: Page, data: ApplicationData
    ) -> None:
        """Fill custom screening questions."""
        if not data.custom_answers:
            return

        fields = await self.detect_fields(page)
        for field in fields:
            answer = data.custom_answers.get(field.name) or data.custom_answers.get(
                field.label
            )
            if not answer:
                continue

            if field.field_type in ("text", "textarea"):
                await simulate_human_typing(page, field.selector, answer)
            elif field.field_type == "select":
                await page.select_option(field.selector, label=answer)
            elif field.field_type in ("checkbox", "radio"):
                if answer.lower() in ("yes", "true", "1"):
                    await page.click(field.selector)

            await random_delay(0.2, 0.5)

    async def _handle_consent(self, page: Page) -> None:
        """Check any consent/GDPR checkboxes on the form."""
        consent_boxes = await page.query_selector_all(
            self.SELECTORS["consent_checkbox"]
        )
        for cb in consent_boxes:
            is_checked = await cb.is_checked()
            if not is_checked:
                await cb.check()
                await random_delay(0.2, 0.4)
