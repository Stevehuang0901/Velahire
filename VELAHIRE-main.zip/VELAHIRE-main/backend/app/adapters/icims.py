"""iCIMS ATS platform adapter.

Handles iCIMS multi-page application flows, profile creation,
and management across different company career portals.
"""

import logging
from typing import Any

from playwright.async_api import Page

from app.adapters.base import ApplicationData, BasePlatformAdapter, FormField
from app.utils.anti_detection import (
    random_delay,
    simulate_human_typing,
    random_mouse_movement,
)

logger = logging.getLogger(__name__)


class ICIMSAdapter(BasePlatformAdapter):
    """Adapter for iCIMS ATS platforms.

    iCIMS applications typically involve:
    1. Profile creation or login
    2. Personal information page
    3. Resume/document upload page
    4. Work experience page
    5. Education page
    6. Custom questionnaire page(s)
    7. Review and submit
    """

    platform_name = "icims"
    base_url = "https://careers-{company}.icims.com"

    SELECTORS = {
        "login_email": "input#LoginEmail",
        "login_password": "input#LoginPassword",
        "login_button": "button#LoginButton, input[type='submit']#LoginButton",
        "create_account_link": "a#CreateAccountLink",
        "first_name": "input[id*='FirstName'], input[name*='firstName']",
        "last_name": "input[id*='LastName'], input[name*='lastName']",
        "email": "input[id*='Email'], input[name*='email']",
        "phone": "input[id*='Phone'], input[name*='phone']",
        "address": "input[id*='Address'], input[name*='address']",
        "city": "input[id*='City'], input[name*='city']",
        "state": "select[id*='State'], select[name*='state']",
        "zip_code": "input[id*='Zip'], input[name*='zip']",
        "resume_upload": "input[type='file'][id*='resume'], input[type='file'][name*='resume']",
        "next_button": "button#next, button.btn-next, input[value='Next']",
        "prev_button": "button#prev, button.btn-prev",
        "submit_button": "button#submit, button.btn-submit, input[value='Submit']",
        "save_button": "button#save, button.btn-save",
        "progress_bar": ".progress-bar, .step-indicator",
    }

    def __init__(self) -> None:
        super().__init__()
        self._credentials: dict[str, str] = {}
        self._current_step: int = 0
        self._total_steps: int = 0

    async def login(self, credentials: dict[str, str]) -> bool:
        """Store credentials for the iCIMS login step.

        Args:
            credentials: Dict with 'email' and 'password'.

        Returns:
            True (actual login happens during fill_application).
        """
        self._credentials = credentials
        return True

    async def fill_application(self, page: Page, data: ApplicationData) -> bool:
        """Fill out an iCIMS multi-page application.

        Args:
            page: Playwright page with the iCIMS application loaded.
            data: Application data to populate.

        Returns:
            True if all pages were filled successfully.
        """
        try:
            await page.set_extra_http_headers(self.anti_detection_headers())

            # Step 1: Handle login / profile creation
            await self._handle_auth(page, data)

            # Step 2: Iterate through multi-page form
            max_pages = 10  # Safety limit
            for _ in range(max_pages):
                await random_delay(1.0, 2.0)

                # Detect current page type and fill accordingly
                await self._fill_current_page(page, data)

                # Check if we're on the review/submit page
                if await self._is_review_page(page):
                    break

                # Navigate to next page
                has_next = await self._click_next(page)
                if not has_next:
                    break

            return True

        except Exception as e:
            logger.error("Failed to fill iCIMS application: %s", str(e))
            return False

    async def submit(self, page: Page) -> dict[str, Any]:
        """Submit the completed iCIMS application.

        Args:
            page: Playwright page on the review/submit step.

        Returns:
            Dict with submission result.
        """
        try:
            submit_btn = await page.query_selector(self.SELECTORS["submit_button"])
            if not submit_btn:
                return {"success": False, "error": "Submit button not found"}

            await random_mouse_movement(page)
            await random_delay(0.5, 1.5)
            await submit_btn.click()
            await self._wait_for_navigation(page)

            # Check for confirmation
            confirmation = await page.query_selector(
                ".confirmation-message, .success-message, #confirmationMessage"
            )
            if confirmation:
                text = await confirmation.inner_text()
                return {
                    "success": True,
                    "confirmation_id": text.strip(),
                    "platform": self.platform_name,
                }

            # Check for errors
            errors = await page.query_selector_all(
                ".error-message, .validation-error, .field-error"
            )
            if errors:
                error_texts = []
                for err in errors:
                    error_texts.append((await err.inner_text()).strip())
                return {"success": False, "error": "; ".join(error_texts)}

            return {"success": True, "platform": self.platform_name}

        except Exception as e:
            logger.error("iCIMS submission failed: %s", str(e))
            return {"success": False, "error": str(e)}

    # ------------------------------------------------------------------ #
    # Profile management
    # ------------------------------------------------------------------ #

    async def create_profile(self, page: Page, data: ApplicationData) -> bool:
        """Create a new iCIMS candidate profile.

        Args:
            page: Playwright page on the account creation form.
            data: Application data for profile fields.

        Returns:
            True if profile was created.
        """
        try:
            # Fill registration form
            email_input = await page.query_selector(
                "input[id*='regEmail'], input[name*='email']"
            )
            if email_input:
                await simulate_human_typing(
                    page,
                    "input[id*='regEmail'], input[name*='email']",
                    data.email,
                )

            password = self._credentials.get("password", "")
            pw_input = await page.query_selector(
                "input[id*='regPassword'], input[type='password']"
            )
            if pw_input and password:
                await simulate_human_typing(
                    page,
                    "input[id*='regPassword'], input[type='password']",
                    password,
                )

            # First and last name
            if data.first_name:
                fn = await page.query_selector(self.SELECTORS["first_name"])
                if fn:
                    await simulate_human_typing(
                        page, self.SELECTORS["first_name"], data.first_name
                    )

            if data.last_name:
                ln = await page.query_selector(self.SELECTORS["last_name"])
                if ln:
                    await simulate_human_typing(
                        page, self.SELECTORS["last_name"], data.last_name
                    )

            # Submit registration
            reg_btn = await page.query_selector(
                "button#registerButton, input[type='submit']"
            )
            if reg_btn:
                await random_delay(0.5, 1.0)
                await reg_btn.click()
                await self._wait_for_navigation(page)

            return True

        except Exception as e:
            logger.error("iCIMS profile creation failed: %s", str(e))
            return False

    async def update_profile(self, page: Page, data: ApplicationData) -> bool:
        """Update an existing iCIMS candidate profile.

        Args:
            page: Playwright page on the profile edit page.
            data: Updated application data.

        Returns:
            True if profile was updated.
        """
        try:
            fields = await self.detect_fields(page)
            for field in fields:
                value = self._get_field_value(field, data)
                if not value:
                    continue

                if field.field_type in ("text", "textarea"):
                    el = await page.query_selector(field.selector)
                    if el:
                        await el.fill("")
                        await simulate_human_typing(page, field.selector, value)
                elif field.field_type == "select":
                    await page.select_option(field.selector, label=value)

                await random_delay(0.2, 0.5)

            save_btn = await page.query_selector(self.SELECTORS["save_button"])
            if save_btn:
                await save_btn.click()
                await self._wait_for_navigation(page)

            return True

        except Exception as e:
            logger.error("iCIMS profile update failed: %s", str(e))
            return False

    # ------------------------------------------------------------------ #
    # Private helpers
    # ------------------------------------------------------------------ #

    async def _handle_auth(self, page: Page, data: ApplicationData) -> None:
        """Handle iCIMS login or account creation."""
        login_email = await page.query_selector(self.SELECTORS["login_email"])
        if not login_email:
            return

        email = self._credentials.get("email", data.email)
        password = self._credentials.get("password", "")

        if not password:
            # Try creating an account
            create_link = await page.query_selector(
                self.SELECTORS["create_account_link"]
            )
            if create_link:
                await create_link.click()
                await self._wait_for_navigation(page)
                await self.create_profile(page, data)
                return

        # Login
        await simulate_human_typing(
            page, self.SELECTORS["login_email"], email
        )
        await random_delay(0.3, 0.6)
        await simulate_human_typing(
            page, self.SELECTORS["login_password"], password
        )
        await random_delay(0.3, 0.8)

        login_btn = await page.query_selector(self.SELECTORS["login_button"])
        if login_btn:
            await login_btn.click()
            await self._wait_for_navigation(page)

    async def _fill_current_page(self, page: Page, data: ApplicationData) -> None:
        """Detect and fill all fields on the current iCIMS page."""
        # Upload resume if file input is present
        file_input = await page.query_selector(self.SELECTORS["resume_upload"])
        if file_input and data.resume_path:
            await file_input.set_input_files(data.resume_path)
            await random_delay(2.0, 4.0)
            logger.info("Resume uploaded to iCIMS")

        # Detect and fill all other fields
        fields = await self.detect_fields(page)
        for field in fields:
            value = self._get_field_value(field, data)
            if not value:
                continue

            if field.field_type in ("text", "textarea"):
                await simulate_human_typing(page, field.selector, value)
            elif field.field_type == "select":
                await page.select_option(field.selector, label=value)
            elif field.field_type == "checkbox":
                if value.lower() in ("yes", "true", "1"):
                    await page.check(field.selector)
            elif field.field_type == "radio":
                await page.click(field.selector)

            await random_delay(0.2, 0.5)

    async def _is_review_page(self, page: Page) -> bool:
        """Check if the current page is the review/summary page."""
        review_indicators = [
            ".review-section",
            "#reviewPage",
            "h2:has-text('Review')",
            "h1:has-text('Review')",
        ]
        for selector in review_indicators:
            el = await page.query_selector(selector)
            if el:
                return True
        return False

    async def _click_next(self, page: Page) -> bool:
        """Click next button and return whether navigation occurred."""
        next_btn = await page.query_selector(self.SELECTORS["next_button"])
        if not next_btn:
            return False

        await random_delay(0.5, 1.0)
        await next_btn.click()
        await self._wait_for_navigation(page)
        self._current_step += 1
        return True

    def _get_field_value(
        self, field: FormField, data: ApplicationData
    ) -> str:
        """Map a detected form field to a value from application data."""
        label_lower = field.label.lower()
        name_lower = field.name.lower()

        # Check custom answers first
        if field.name in data.custom_answers:
            return data.custom_answers[field.name]
        if field.label in data.custom_answers:
            return data.custom_answers[field.label]

        # Map common field patterns
        mapping: list[tuple[list[str], str]] = [
            (["first name", "firstname"], data.first_name),
            (["last name", "lastname", "surname"], data.last_name),
            (["email", "e-mail"], data.email),
            (["phone", "telephone", "mobile"], data.phone),
            (["linkedin"], data.linkedin_url),
            (["portfolio", "website", "personal"], data.portfolio_url),
            (["salary", "compensation"], data.salary_expectation),
            (["start date", "availability"], data.start_date),
            (["authorization", "authorized", "visa", "sponsorship"], data.work_authorization),
        ]

        for keywords, value in mapping:
            for keyword in keywords:
                if keyword in label_lower or keyword in name_lower:
                    return value or ""

        return ""
