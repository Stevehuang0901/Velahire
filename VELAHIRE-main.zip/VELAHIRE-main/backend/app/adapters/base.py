"""Base platform adapter with common functionality for ATS integrations."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional

from playwright.async_api import Page

from app.utils.anti_detection import rotate_user_agent


@dataclass
class FormField:
    """Represents a detected form field on an application page."""

    selector: str
    field_type: str  # text, select, checkbox, radio, file, textarea
    label: str = ""
    name: str = ""
    required: bool = False
    options: list[str] = field(default_factory=list)
    value: str = ""
    placeholder: str = ""


@dataclass
class ApplicationData:
    """Structured data for filling out a job application."""

    full_name: str = ""
    first_name: str = ""
    last_name: str = ""
    email: str = ""
    phone: str = ""
    resume_path: str = ""
    cover_letter: str = ""
    linkedin_url: str = ""
    portfolio_url: str = ""
    work_authorization: str = ""
    salary_expectation: str = ""
    start_date: str = ""
    custom_answers: dict[str, str] = field(default_factory=dict)
    additional_files: list[str] = field(default_factory=list)


class BasePlatformAdapter(ABC):
    """Abstract base class for ATS platform adapters.

    Each adapter handles the specifics of interacting with a particular
    Applicant Tracking System (e.g., Workday, Greenhouse, Lever).
    """

    platform_name: str = "unknown"
    base_url: str = ""

    def __init__(self) -> None:
        self._session_cookies: dict[str, str] = {}

    @abstractmethod
    async def login(self, credentials: dict[str, str]) -> bool:
        """Log into the platform with the given credentials.

        Args:
            credentials: Dict with keys like 'email', 'password', or OAuth tokens.

        Returns:
            True if login was successful, False otherwise.
        """
        ...

    @abstractmethod
    async def fill_application(self, page: Page, data: ApplicationData) -> bool:
        """Fill out the application form on the given page.

        Args:
            page: Playwright page with the application form loaded.
            data: Structured application data to populate the form.

        Returns:
            True if the form was filled successfully, False otherwise.
        """
        ...

    @abstractmethod
    async def submit(self, page: Page) -> dict[str, Any]:
        """Submit the filled application form.

        Args:
            page: Playwright page with the completed form.

        Returns:
            Dict with submission result, e.g. {'success': True, 'confirmation_id': '...'}.
        """
        ...

    async def detect_fields(self, page: Page) -> list[FormField]:
        """Detect form fields on the current page using DOM inspection.

        Scans the page for input, select, textarea, and file elements,
        extracting their labels, types, and attributes.

        Args:
            page: Playwright page to scan for form fields.

        Returns:
            List of detected FormField objects.
        """
        fields: list[FormField] = []

        # Detect standard input fields
        inputs = await page.query_selector_all(
            "input:not([type='hidden']):not([type='submit']):not([type='button'])"
        )
        for inp in inputs:
            field_type = await inp.get_attribute("type") or "text"
            name = await inp.get_attribute("name") or ""
            placeholder = await inp.get_attribute("placeholder") or ""
            required = await inp.get_attribute("required") is not None
            field_id = await inp.get_attribute("id") or ""

            # Try to find the associated label
            label_text = ""
            if field_id:
                label_el = await page.query_selector(f"label[for='{field_id}']")
                if label_el:
                    label_text = (await label_el.inner_text()).strip()

            if not label_text:
                # Try aria-label or parent label
                label_text = await inp.get_attribute("aria-label") or placeholder

            selector = f"#{field_id}" if field_id else f"input[name='{name}']"
            fields.append(
                FormField(
                    selector=selector,
                    field_type=field_type,
                    label=label_text,
                    name=name,
                    required=required,
                    placeholder=placeholder,
                )
            )

        # Detect select dropdowns
        selects = await page.query_selector_all("select")
        for sel in selects:
            name = await sel.get_attribute("name") or ""
            field_id = await sel.get_attribute("id") or ""
            required = await sel.get_attribute("required") is not None

            label_text = ""
            if field_id:
                label_el = await page.query_selector(f"label[for='{field_id}']")
                if label_el:
                    label_text = (await label_el.inner_text()).strip()

            # Extract options
            option_els = await sel.query_selector_all("option")
            options = []
            for opt in option_els:
                opt_text = (await opt.inner_text()).strip()
                if opt_text:
                    options.append(opt_text)

            selector = f"#{field_id}" if field_id else f"select[name='{name}']"
            fields.append(
                FormField(
                    selector=selector,
                    field_type="select",
                    label=label_text,
                    name=name,
                    required=required,
                    options=options,
                )
            )

        # Detect textareas
        textareas = await page.query_selector_all("textarea")
        for ta in textareas:
            name = await ta.get_attribute("name") or ""
            field_id = await ta.get_attribute("id") or ""
            required = await ta.get_attribute("required") is not None
            placeholder = await ta.get_attribute("placeholder") or ""

            label_text = ""
            if field_id:
                label_el = await page.query_selector(f"label[for='{field_id}']")
                if label_el:
                    label_text = (await label_el.inner_text()).strip()

            selector = f"#{field_id}" if field_id else f"textarea[name='{name}']"
            fields.append(
                FormField(
                    selector=selector,
                    field_type="textarea",
                    label=label_text or placeholder,
                    name=name,
                    required=required,
                    placeholder=placeholder,
                )
            )

        # Detect file upload inputs
        file_inputs = await page.query_selector_all("input[type='file']")
        for fi in file_inputs:
            name = await fi.get_attribute("name") or ""
            field_id = await fi.get_attribute("id") or ""
            accept = await fi.get_attribute("accept") or ""

            label_text = ""
            if field_id:
                label_el = await page.query_selector(f"label[for='{field_id}']")
                if label_el:
                    label_text = (await label_el.inner_text()).strip()

            selector = f"#{field_id}" if field_id else f"input[type='file'][name='{name}']"
            fields.append(
                FormField(
                    selector=selector,
                    field_type="file",
                    label=label_text or "File Upload",
                    name=name,
                    placeholder=accept,
                )
            )

        return fields

    def anti_detection_headers(self) -> dict[str, str]:
        """Generate headers that reduce automated-browsing detection.

        Returns:
            Dict of HTTP headers to use with requests.
        """
        user_agent = rotate_user_agent()
        return {
            "User-Agent": user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Cache-Control": "max-age=0",
        }

    async def _wait_for_navigation(self, page: Page, timeout: int = 30000) -> None:
        """Wait for page navigation to complete.

        Args:
            page: Playwright page.
            timeout: Maximum wait time in milliseconds.
        """
        try:
            await page.wait_for_load_state("networkidle", timeout=timeout)
        except Exception:
            await page.wait_for_load_state("domcontentloaded", timeout=timeout)
