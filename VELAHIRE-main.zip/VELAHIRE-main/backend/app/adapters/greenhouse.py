"""Greenhouse job board platform adapter.

Handles Greenhouse's embedded job board application forms,
direct submission, and file uploads.
"""

import logging
from typing import Any

from playwright.async_api import Page

from app.adapters.base import ApplicationData, BasePlatformAdapter, FormField
from app.utils.anti_detection import (
    random_delay,
    simulate_human_typing,
    random_mouse_movement,
)

logger = logging.getLogger(__name__)


class GreenhouseAdapter(BasePlatformAdapter):
    """Adapter for Greenhouse job board applications.

    Greenhouse boards typically have a single-page application form
    with optional custom questions. The form structure is relatively
    consistent across companies.
    """

    platform_name = "greenhouse"
    base_url = "https://boards.greenhouse.io"

    SELECTORS = {
        "first_name": "#first_name",
        "last_name": "#last_name",
        "email": "#email",
        "phone": "#phone",
        "resume_input": "input[type='file']#resume",
        "cover_letter_input": "input[type='file']#cover_letter",
        "cover_letter_text": "#cover_letter_text",
        "linkedin": "#job_application_answers_attributes_0_text_value",
        "submit_button": "#submit_app",
        "custom_fields_container": "#custom_fields",
    }

    async def login(self, credentials: dict[str, str]) -> bool:
        """Greenhouse boards typically do not require login.

        Args:
            credentials: Not used for Greenhouse.

        Returns:
            Always True since no login is needed.
        """
        return True

    async def fill_application(self, page: Page, data: ApplicationData) -> bool:
        """Fill out a Greenhouse application form.

        Args:
            page: Playwright page with the Greenhouse form loaded.
            data: Application data to populate.

        Returns:
            True if the form was filled successfully.
        """
        try:
            await page.set_extra_http_headers(self.anti_detection_headers())
            await random_delay(1.0, 2.5)

            # Fill basic info fields
            await self._fill_basic_info(page, data)

            # Handle resume upload
            await self._upload_resume(page, data)

            # Handle cover letter
            await self._handle_cover_letter(page, data)

            # Fill custom question fields
            await self._fill_custom_questions(page, data)

            return True

        except Exception as e:
            logger.error("Failed to fill Greenhouse application: %s", str(e))
            return False

    async def submit(self, page: Page) -> dict[str, Any]:
        """Submit the Greenhouse application.

        Args:
            page: Playwright page with completed form.

        Returns:
            Dict with submission result.
        """
        try:
            submit_btn = await page.query_selector(self.SELECTORS["submit_button"])
            if not submit_btn:
                return {"success": False, "error": "Submit button not found"}

            await random_mouse_movement(page)
            await random_delay(0.5, 1.5)
            await submit_btn.click()

            await self._wait_for_navigation(page)

            # Check for success message
            success_el = await page.query_selector("#application_confirmation")
            if success_el:
                text = await success_el.inner_text()
                return {
                    "success": True,
                    "confirmation_id": text.strip(),
                    "platform": self.platform_name,
                }

            # Check for validation errors
            errors = await page.query_selector_all(".field-error, .error-message")
            if errors:
                error_texts = []
                for err in errors:
                    error_texts.append((await err.inner_text()).strip())
                return {
                    "success": False,
                    "error": "; ".join(error_texts),
                }

            return {"success": True, "platform": self.platform_name}

        except Exception as e:
            logger.error("Greenhouse submission failed: %s", str(e))
            return {"success": False, "error": str(e)}

    # ------------------------------------------------------------------ #
    # Private helpers
    # ------------------------------------------------------------------ #

    async def _fill_basic_info(self, page: Page, data: ApplicationData) -> None:
        """Fill standard Greenhouse fields: name, email, phone."""
        fields = {
            self.SELECTORS["first_name"]: data.first_name,
            self.SELECTORS["last_name"]: data.last_name,
            self.SELECTORS["email"]: data.email,
            self.SELECTORS["phone"]: data.phone,
        }

        for selector, value in fields.items():
            if not value:
                continue
            el = await page.query_selector(selector)
            if el:
                await el.click()
                await random_delay(0.1, 0.3)
                await simulate_human_typing(page, selector, value)
                await random_delay(0.3, 0.7)

        # LinkedIn URL (often the first custom text field)
        if data.linkedin_url:
            linkedin_el = await page.query_selector(self.SELECTORS["linkedin"])
            if linkedin_el:
                await simulate_human_typing(
                    page, self.SELECTORS["linkedin"], data.linkedin_url
                )

    async def _upload_resume(self, page: Page, data: ApplicationData) -> None:
        """Upload resume file to Greenhouse."""
        if not data.resume_path:
            return

        # Greenhouse may use a styled upload button; find the underlying input
        resume_input = await page.query_selector(self.SELECTORS["resume_input"])
        if not resume_input:
            # Try alternative selector
            resume_input = await page.query_selector(
                "input[type='file'][name*='resume']"
            )

        if resume_input:
            await resume_input.set_input_files(data.resume_path)
            await random_delay(1.5, 3.0)
            logger.info("Resume uploaded to Greenhouse")

        # Upload additional files
        for file_path in data.additional_files:
            additional_input = await page.query_selector(
                "input[type='file']:not(#resume):not(#cover_letter)"
            )
            if additional_input:
                await additional_input.set_input_files(file_path)
                await random_delay(1.0, 2.0)

    async def _handle_cover_letter(self, page: Page, data: ApplicationData) -> None:
        """Handle cover letter upload or text input."""
        if not data.cover_letter:
            return

        # Try text area first
        text_area = await page.query_selector(self.SELECTORS["cover_letter_text"])
        if text_area:
            await simulate_human_typing(
                page, self.SELECTORS["cover_letter_text"], data.cover_letter
            )
            return

        # If cover_letter is a file path, try file upload
        cl_input = await page.query_selector(self.SELECTORS["cover_letter_input"])
        if cl_input and data.cover_letter.endswith((".pdf", ".docx", ".doc")):
            await cl_input.set_input_files(data.cover_letter)
            await random_delay(1.0, 2.0)

    async def _fill_custom_questions(
        self, page: Page, data: ApplicationData
    ) -> None:
        """Fill Greenhouse custom question fields."""
        if not data.custom_answers:
            return

        custom_container = await page.query_selector(
            self.SELECTORS["custom_fields_container"]
        )
        if not custom_container:
            custom_container = page  # Fall back to full page scan

        fields = await self.detect_fields(page)

        for field in fields:
            answer = data.custom_answers.get(field.name) or data.custom_answers.get(
                field.label
            )
            if not answer:
                continue

            if field.field_type in ("text", "textarea"):
                await simulate_human_typing(page, field.selector, answer)
            elif field.field_type == "select":
                await page.select_option(field.selector, label=answer)
            elif field.field_type == "checkbox":
                if answer.lower() in ("yes", "true", "1"):
                    await page.check(field.selector)
            elif field.field_type == "radio":
                await page.click(field.selector)

            await random_delay(0.2, 0.5)
