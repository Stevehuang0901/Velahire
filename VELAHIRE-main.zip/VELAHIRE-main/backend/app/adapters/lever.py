"""Lever ATS platform adapter.

Handles Lever's application forms with direct resume upload
and bypass of resume parsing where possible.
"""

import logging
from typing import Any

from playwright.async_api import Page

from app.adapters.base import ApplicationData, BasePlatformAdapter
from app.utils.anti_detection import (
    random_delay,
    simulate_human_typing,
    random_mouse_movement,
)

logger = logging.getLogger(__name__)


class LeverAdapter(BasePlatformAdapter):
    """Adapter for Lever ATS applications.

    Lever forms are typically single-page with a clean layout:
    - Name, email, phone, and org fields at the top
    - Resume upload (drag-and-drop or file select)
    - Optional cover letter
    - Custom questions below
    """

    platform_name = "lever"
    base_url = "https://jobs.lever.co"

    SELECTORS = {
        "name": "input[name='name']",
        "email": "input[name='email']",
        "phone": "input[name='phone']",
        "org": "input[name='org']",
        "urls_0": "input[name='urls[0]']",  # LinkedIn / portfolio
        "urls_1": "input[name='urls[1]']",
        "resume_input": "input[type='file'][name='resume']",
        "resume_drop_zone": ".resume-upload-area",
        "cover_letter": "textarea[name='comments']",
        "submit_button": "button[type='submit'].postings-btn",
        "consent_checkbox": "input[name='consent[marketing]']",
    }

    async def login(self, credentials: dict[str, str]) -> bool:
        """Lever does not require login for applications.

        Args:
            credentials: Not used.

        Returns:
            Always True.
        """
        return True

    async def fill_application(self, page: Page, data: ApplicationData) -> bool:
        """Fill out a Lever application form.

        Args:
            page: Playwright page with the Lever form loaded.
            data: Application data to populate.

        Returns:
            True if the form was filled successfully.
        """
        try:
            await page.set_extra_http_headers(self.anti_detection_headers())
            await random_delay(1.0, 2.0)

            # Fill name (Lever uses a single full name field)
            full_name = data.full_name or f"{data.first_name} {data.last_name}".strip()
            if full_name:
                await simulate_human_typing(page, self.SELECTORS["name"], full_name)
                await random_delay(0.3, 0.6)

            # Fill email
            if data.email:
                await simulate_human_typing(page, self.SELECTORS["email"], data.email)
                await random_delay(0.2, 0.5)

            # Fill phone
            if data.phone:
                await simulate_human_typing(page, self.SELECTORS["phone"], data.phone)
                await random_delay(0.2, 0.5)

            # Fill company/org
            org = data.custom_answers.get("org", "")
            if org:
                await simulate_human_typing(page, self.SELECTORS["org"], org)
                await random_delay(0.2, 0.4)

            # Fill URLs (LinkedIn, portfolio)
            urls = [data.linkedin_url, data.portfolio_url]
            for i, url in enumerate(urls):
                if url and i < 2:
                    selector = self.SELECTORS[f"urls_{i}"]
                    el = await page.query_selector(selector)
                    if el:
                        await simulate_human_typing(page, selector, url)
                        await random_delay(0.2, 0.4)

            # Upload resume directly (bypass parsing)
            await self._upload_resume(page, data)

            # Fill cover letter
            if data.cover_letter:
                await simulate_human_typing(
                    page, self.SELECTORS["cover_letter"], data.cover_letter
                )
                await random_delay(0.3, 0.6)

            # Fill custom questions
            await self._fill_custom_questions(page, data)

            # Handle consent checkbox if present
            consent = await page.query_selector(self.SELECTORS["consent_checkbox"])
            if consent:
                is_checked = await consent.is_checked()
                if not is_checked:
                    await consent.check()

            return True

        except Exception as e:
            logger.error("Failed to fill Lever application: %s", str(e))
            return False

    async def submit(self, page: Page) -> dict[str, Any]:
        """Submit the Lever application.

        Args:
            page: Playwright page with completed form.

        Returns:
            Dict with submission result.
        """
        try:
            submit_btn = await page.query_selector(self.SELECTORS["submit_button"])
            if not submit_btn:
                # Try fallback selector
                submit_btn = await page.query_selector(
                    "button[type='submit'], input[type='submit']"
                )

            if not submit_btn:
                return {"success": False, "error": "Submit button not found"}

            await random_mouse_movement(page)
            await random_delay(0.5, 1.5)
            await submit_btn.click()

            await self._wait_for_navigation(page)

            # Lever typically redirects to a thank-you page
            current_url = page.url
            if "thanks" in current_url or "thank-you" in current_url:
                return {
                    "success": True,
                    "confirmation_id": current_url,
                    "platform": self.platform_name,
                }

            # Check for success message on the page
            success_msg = await page.query_selector(
                ".application-confirmation, .thank-you-message"
            )
            if success_msg:
                text = await success_msg.inner_text()
                return {
                    "success": True,
                    "confirmation_id": text.strip(),
                    "platform": self.platform_name,
                }

            # Check for validation errors
            errors = await page.query_selector_all(
                ".application-error, .error, .field-error"
            )
            if errors:
                error_texts = []
                for err in errors:
                    error_texts.append((await err.inner_text()).strip())
                return {"success": False, "error": "; ".join(error_texts)}

            return {"success": True, "platform": self.platform_name}

        except Exception as e:
            logger.error("Lever submission failed: %s", str(e))
            return {"success": False, "error": str(e)}

    # ------------------------------------------------------------------ #
    # Private helpers
    # ------------------------------------------------------------------ #

    async def _upload_resume(self, page: Page, data: ApplicationData) -> None:
        """Upload resume directly to Lever, bypassing parsing.

        Lever accepts the file and stores it as-is, which is preferable
        to letting the ATS parse and potentially mangle the content.
        """
        if not data.resume_path:
            return

        resume_input = await page.query_selector(self.SELECTORS["resume_input"])
        if not resume_input:
            # Try finding any file input
            resume_input = await page.query_selector("input[type='file']")

        if resume_input:
            await resume_input.set_input_files(data.resume_path)
            await random_delay(1.5, 3.0)
            logger.info("Resume uploaded directly to Lever (parsing bypass)")

    async def _fill_custom_questions(self, page: Page, data: ApplicationData) -> None:
        """Fill Lever custom application questions."""
        if not data.custom_answers:
            return

        # Lever custom questions are in div.custom-questions
        custom_section = await page.query_selector(".custom-questions")
        if not custom_section:
            return

        fields = await self.detect_fields(page)
        for field in fields:
            answer = data.custom_answers.get(field.name) or data.custom_answers.get(
                field.label
            )
            if not answer:
                continue

            if field.field_type in ("text", "textarea"):
                await simulate_human_typing(page, field.selector, answer)
            elif field.field_type == "select":
                await page.select_option(field.selector, label=answer)
            elif field.field_type in ("checkbox", "radio"):
                if answer.lower() in ("yes", "true", "1"):
                    await page.click(field.selector)

            await random_delay(0.2, 0.5)
