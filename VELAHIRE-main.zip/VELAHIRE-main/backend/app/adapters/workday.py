"""Workday ATS platform adapter.

Handles Workday's multi-step application flow, account creation,
and specific form field structures.
"""

import logging
from typing import Any

from playwright.async_api import Page

from app.adapters.base import ApplicationData, BasePlatformAdapter, FormField
from app.utils.anti_detection import (
    random_delay,
    simulate_human_typing,
    random_mouse_movement,
)

logger = logging.getLogger(__name__)


class WorkdayAdapter(BasePlatformAdapter):
    """Adapter for Workday ATS platforms.

    Workday applications typically involve:
    1. Account creation or sign-in
    2. Multi-page form with personal info, experience, education
    3. Resume upload and parsing
    4. Custom questionnaire
    5. Review and submit
    """

    platform_name = "workday"
    base_url = "https://wd5.myworkday.com"

    # Common Workday selectors
    SELECTORS = {
        "sign_in_email": "input[data-automation-id='email']",
        "sign_in_password": "input[data-automation-id='password']",
        "sign_in_button": "button[data-automation-id='signInSubmitButton']",
        "create_account_link": "a[data-automation-id='createAccountLink']",
        "first_name": "input[data-automation-id='legalNameSection_firstName']",
        "last_name": "input[data-automation-id='legalNameSection_lastName']",
        "address_line1": "input[data-automation-id='addressSection_addressLine1']",
        "city": "input[data-automation-id='addressSection_city']",
        "state": "input[data-automation-id='addressSection_countryRegion']",
        "postal_code": "input[data-automation-id='addressSection_postalCode']",
        "phone": "input[data-automation-id='phone-number']",
        "resume_upload": "input[data-automation-id='file-upload-input-ref']",
        "next_button": "button[data-automation-id='bottom-navigation-next-button']",
        "submit_button": "button[data-automation-id='submit-button']",
        "save_button": "button[data-automation-id='bottom-navigation-save-button']",
    }

    async def login(self, credentials: dict[str, str]) -> bool:
        """Log into Workday with email and password.

        Args:
            credentials: Dict with 'email' and 'password' keys.

        Returns:
            True if login succeeded.
        """
        # Login is handled within the fill_application flow since
        # Workday embeds auth into the application process.
        self._session_cookies = {}
        self._credentials = credentials
        return True

    async def fill_application(self, page: Page, data: ApplicationData) -> bool:
        """Fill out a Workday application form.

        Handles the multi-step Workday flow:
        1. Sign in or create account
        2. Upload resume
        3. Fill personal information
        4. Fill work experience
        5. Fill education
        6. Answer custom questions

        Args:
            page: Playwright page with the Workday application loaded.
            data: Application data to populate.

        Returns:
            True if all steps completed successfully.
        """
        try:
            await page.set_extra_http_headers(self.anti_detection_headers())

            # Step 1: Handle authentication
            await self._handle_auth_step(page, data)

            # Step 2: Upload resume if the upload field is present
            await self._upload_resume(page, data)

            # Step 3: Fill personal information
            await self._fill_personal_info(page, data)

            # Step 4: Handle work experience section
            await self._fill_work_experience(page, data)

            # Step 5: Handle education section
            await self._fill_education(page, data)

            # Step 6: Handle custom questions
            await self._fill_custom_questions(page, data)

            return True

        except Exception as e:
            logger.error("Failed to fill Workday application: %s", str(e))
            return False

    async def submit(self, page: Page) -> dict[str, Any]:
        """Submit the completed Workday application.

        Args:
            page: Playwright page with completed form.

        Returns:
            Dict with submission result.
        """
        try:
            submit_btn = await page.query_selector(self.SELECTORS["submit_button"])
            if not submit_btn:
                return {"success": False, "error": "Submit button not found"}

            await random_mouse_movement(page)
            await random_delay(0.5, 1.5)
            await submit_btn.click()

            await self._wait_for_navigation(page)

            # Check for confirmation
            confirmation = await page.query_selector(
                "[data-automation-id='confirmationMessage']"
            )
            if confirmation:
                confirmation_text = await confirmation.inner_text()
                return {
                    "success": True,
                    "confirmation_id": confirmation_text,
                    "platform": self.platform_name,
                }

            # Check for errors
            error_el = await page.query_selector("[data-automation-id='errorMessage']")
            if error_el:
                error_text = await error_el.inner_text()
                return {"success": False, "error": error_text}

            return {"success": True, "platform": self.platform_name}

        except Exception as e:
            logger.error("Workday submission failed: %s", str(e))
            return {"success": False, "error": str(e)}

    # ------------------------------------------------------------------ #
    # Private helpers
    # ------------------------------------------------------------------ #

    async def _handle_auth_step(self, page: Page, data: ApplicationData) -> None:
        """Handle Workday sign-in or account creation."""
        sign_in_email = await page.query_selector(self.SELECTORS["sign_in_email"])
        if not sign_in_email:
            return  # No auth step on this page

        await random_delay(1.0, 2.0)

        # Check if we need to create an account
        create_link = await page.query_selector(self.SELECTORS["create_account_link"])
        if create_link and not self._credentials.get("password"):
            await create_link.click()
            await self._wait_for_navigation(page)
            await self._create_account(page, data)
            return

        # Sign in with existing credentials
        await simulate_human_typing(
            page,
            self.SELECTORS["sign_in_email"],
            self._credentials.get("email", data.email),
        )
        await random_delay(0.3, 0.8)
        await simulate_human_typing(
            page,
            self.SELECTORS["sign_in_password"],
            self._credentials.get("password", ""),
        )
        await random_delay(0.5, 1.0)

        sign_in_btn = await page.query_selector(self.SELECTORS["sign_in_button"])
        if sign_in_btn:
            await sign_in_btn.click()
            await self._wait_for_navigation(page)

    async def _create_account(self, page: Page, data: ApplicationData) -> None:
        """Handle Workday account creation flow."""
        email_input = await page.query_selector(
            "input[data-automation-id='createAccountEmail']"
        )
        if email_input:
            await simulate_human_typing(
                page,
                "input[data-automation-id='createAccountEmail']",
                data.email,
            )

        password_input = await page.query_selector(
            "input[data-automation-id='createAccountPassword']"
        )
        if password_input:
            await simulate_human_typing(
                page,
                "input[data-automation-id='createAccountPassword']",
                self._credentials.get("password", ""),
            )

        confirm_input = await page.query_selector(
            "input[data-automation-id='createAccountConfirmPassword']"
        )
        if confirm_input:
            await simulate_human_typing(
                page,
                "input[data-automation-id='createAccountConfirmPassword']",
                self._credentials.get("password", ""),
            )

        submit_btn = await page.query_selector(
            "button[data-automation-id='createAccountSubmitButton']"
        )
        if submit_btn:
            await random_delay(0.5, 1.0)
            await submit_btn.click()
            await self._wait_for_navigation(page)

    async def _upload_resume(self, page: Page, data: ApplicationData) -> None:
        """Upload resume file via Workday's file input."""
        if not data.resume_path:
            return

        file_input = await page.query_selector(self.SELECTORS["resume_upload"])
        if file_input:
            await file_input.set_input_files(data.resume_path)
            await random_delay(2.0, 4.0)  # Wait for parsing
            logger.info("Resume uploaded to Workday")

    async def _fill_personal_info(self, page: Page, data: ApplicationData) -> None:
        """Fill the personal information section."""
        field_map = {
            self.SELECTORS["first_name"]: data.first_name,
            self.SELECTORS["last_name"]: data.last_name,
            self.SELECTORS["phone"]: data.phone,
        }

        for selector, value in field_map.items():
            if not value:
                continue
            el = await page.query_selector(selector)
            if el:
                await el.click()
                await random_delay(0.1, 0.3)
                await simulate_human_typing(page, selector, value)
                await random_delay(0.2, 0.5)

        # Navigate to next step if multi-page
        await self._click_next(page)

    async def _fill_work_experience(self, page: Page, data: ApplicationData) -> None:
        """Fill the work experience section from custom answers."""
        experience_section = await page.query_selector(
            "[data-automation-id='workExperienceSection']"
        )
        if not experience_section:
            return

        # Use detected fields and custom answers to fill experience
        fields = await self.detect_fields(page)
        await self._fill_detected_fields(page, fields, data)
        await self._click_next(page)

    async def _fill_education(self, page: Page, data: ApplicationData) -> None:
        """Fill the education section."""
        education_section = await page.query_selector(
            "[data-automation-id='educationSection']"
        )
        if not education_section:
            return

        fields = await self.detect_fields(page)
        await self._fill_detected_fields(page, fields, data)
        await self._click_next(page)

    async def _fill_custom_questions(self, page: Page, data: ApplicationData) -> None:
        """Fill custom questionnaire fields."""
        fields = await self.detect_fields(page)
        await self._fill_detected_fields(page, fields, data)

    async def _fill_detected_fields(
        self, page: Page, fields: list[FormField], data: ApplicationData
    ) -> None:
        """Fill detected form fields using application data and custom answers."""
        for f in fields:
            value = data.custom_answers.get(f.name) or data.custom_answers.get(f.label)
            if not value:
                continue

            if f.field_type in ("text", "textarea"):
                await simulate_human_typing(page, f.selector, value)
            elif f.field_type == "select":
                await page.select_option(f.selector, label=value)
            elif f.field_type == "checkbox":
                if value.lower() in ("yes", "true", "1"):
                    await page.check(f.selector)
            elif f.field_type == "radio":
                await page.click(f.selector)

            await random_delay(0.2, 0.6)

    async def _click_next(self, page: Page) -> None:
        """Click the next button and wait for navigation."""
        next_btn = await page.query_selector(self.SELECTORS["next_button"])
        if next_btn:
            await random_delay(0.5, 1.5)
            await next_btn.click()
            await self._wait_for_navigation(page)
