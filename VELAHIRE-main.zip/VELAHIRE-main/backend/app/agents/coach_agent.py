"""
Coach Agent – Interview preparation and career coaching.

Provides interview preparation materials, generates STAR-format examples,
conducts mock interviews with detailed feedback, researches companies,
and suggests learning resources to close skill gaps.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from .base import AgentConfig, BaseAgent, agent_error_handler

logger = logging.getLogger(__name__)

INTERVIEW_PREP_SYSTEM = (
    "You are a senior interview coach with 20 years of experience preparing "
    "candidates for roles at top companies. Create a comprehensive interview "
    "preparation guide. Return a JSON object:\n\n"
    '  "company_overview": str\n'
    '  "role_analysis": {"key_responsibilities": [str], "must_have_skills": [str], '
    '"nice_to_have_skills": [str], "cultural_values": [str]}\n'
    '  "likely_questions": [{"question": str, "category": str, "difficulty": str, '
    '"why_asked": str, "suggested_approach": str, "sample_answer_outline": str}]\n'
    '  "behavioral_questions": [same structure]\n'
    '  "technical_questions": [same structure] or []\n'
    '  "questions_to_ask": [{"question": str, "purpose": str, "when_to_ask": str}]\n'
    '  "preparation_checklist": [str]\n'
    '  "red_flags_to_avoid": [str]\n'
    '  "salary_negotiation_tips": [str]\n'
    '  "dress_code_suggestion": str\n'
    '  "estimated_prep_hours": number\n\n'
    "Tailor everything to the specific candidate profile provided."
)

STAR_EXAMPLES_SYSTEM = (
    "You are a behavioral interview specialist. Generate STAR-format "
    "(Situation, Task, Action, Result) examples from the candidate's real "
    "experience. Return a JSON object with an 'examples' key:\n\n"
    '  {"examples": [{"competency": str, "situation": str, "task": str, '
    '"action": str, "result": str, "experience_source": str, '
    '"strength_demonstrated": str, "follow_up_questions": [str]}]}\n\n'
    "Rules:\n"
    "- Only use real experience from the candidate's profile.\n"
    "- Quantify results wherever possible.\n"
    "- Each example should highlight a different competency.\n"
    "- Make the stories compelling but truthful."
)

MOCK_INTERVIEW_SYSTEM = (
    "You are a demanding but fair interviewer. Evaluate the candidate's "
    "answer to the interview question. Return a JSON object:\n\n"
    '  "score": int (1-10)\n'
    '  "strengths": [str]\n  "weaknesses": [str]\n'
    '  "improved_answer": str\n  "delivery_tips": [str]\n'
    '  "follow_up_question": str\n'
    '  "category_scores": {"relevance": int, "specificity": int, '
    '"structure": int, "impact": int, "communication": int}\n'
    '  "overall_feedback": str\n'
)

COMPANY_RESEARCH_SYSTEM = (
    "You are a competitive intelligence analyst. Research the given company "
    "and provide insights useful for a job interview. Return a JSON object:\n\n"
    '  "company_name": str, "industry": str, "founded": str or null,\n'
    '  "headquarters": str, "size": str, "mission_statement": str or null,\n'
    '  "core_values": [str], "products_services": [str],\n'
    '  "recent_news": [{"headline": str, "relevance": str}],\n'
    '  "culture": {"work_style": str, "dress_code": str, "remote_policy": str,\n'
    '    "glassdoor_rating": float or null, "notable_perks": [str]},\n'
    '  "competitors": [str], "growth_trajectory": str,\n'
    '  "technology_stack": [str] or null,\n'
    '  "interview_process": {"typical_rounds": int, "format": str,\n'
    '    "timeline_days": int, "known_question_themes": [str]},\n'
    '  "talking_points": [str], "questions_about_company": [str]\n'
)

LEARNING_RESOURCES_SYSTEM = (
    "You are a technical learning advisor. For each skill gap, suggest "
    "the best learning resources. Return a JSON object with a 'resources' key:\n\n"
    '  {"resources": [{"skill": str, "current_level": str, "target_level": str,\n'
    '    "estimated_hours": number, "resources": [{"name": str,\n'
    '    "type": str, "provider": str, "url": str or null, "cost": str,\n'
    '    "duration": str, "difficulty": str, "why_recommended": str}],\n'
    '    "practice_projects": [{"name": str, "description": str, '
    '"skills_practiced": [str]}], "priority": str}]}\n'
)


class CoachAgent(BaseAgent):
    """Provides interview preparation, mock interviews, company research,
    and learning resource recommendations."""

    name: str = "CoachAgent"
    description: str = "Interview preparation, career coaching, and skill gap analysis"

    def __init__(self, config: Optional[AgentConfig] = None) -> None:
        super().__init__(config)

    @agent_error_handler
    async def execute(
        self,
        company: str = "",
        role: str = "",
        profile: dict[str, Any] | None = None,
        task: str = "prepare",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Full coaching pipeline: prep + STAR examples + company research."""
        company = company or kwargs.get("company", "")
        role = role or kwargs.get("role", "")
        profile = profile or kwargs.get("profile", {})

        if task == "prepare":
            prep = await self.prepare_interview(company, role, profile)
            company_info = await self.research_company(company)

            competencies = []
            for q in prep.get("behavioral_questions", []):
                cat = q.get("category", "")
                if cat and cat not in competencies:
                    competencies.append(cat)
            if not competencies:
                competencies = ["leadership", "problem-solving", "teamwork", "communication", "adaptability"]

            star_examples = await self.generate_star_examples(profile.get("experience", []), competencies)
            return {"interview_prep": prep, "company_research": company_info, "star_examples": star_examples}
        elif task == "mock":
            return await self.conduct_mock_interview(
                kwargs.get("role", role), kwargs.get("question", ""), kwargs.get("answer", ""),
            )
        return {}

    @agent_error_handler
    async def prepare_interview(self, company: str, role: str, profile: dict[str, Any]) -> dict:
        """Generate comprehensive interview preparation materials.

        Creates a tailored preparation guide with likely questions,
        suggested approaches, and a preparation checklist.

        Args:
            company: Target company name.
            role: Job title/role being interviewed for.
            profile: Candidate's profile dict.

        Returns:
            Interview prep dict with questions, tips, and checklist.
        """
        prompt = (
            f"Create an interview preparation guide for:\n\n"
            f"Company: {company}\nRole: {role}\n\n"
            f"Candidate Profile:\n{json.dumps(profile, default=str)[:4000]}\n\n"
            f"Tailor the preparation to this specific candidate's background. "
            f"Include at least 8 likely questions with detailed suggested approaches."
        )
        response = await self.call_llm(
            prompt=prompt, system_prompt=INTERVIEW_PREP_SYSTEM,
            response_format={"type": "json_object"}, temperature=0.6,
        )
        return json.loads(response)

    @agent_error_handler
    async def generate_star_examples(self, experience: list, competencies: list) -> list[dict]:
        """Generate STAR-format behavioral interview examples.

        Args:
            experience: List of experience dicts from the candidate's profile.
            competencies: List of competency strings to generate examples for.

        Returns:
            List of STAR example dicts, one per competency.
        """
        prompt = (
            f"Generate STAR-format examples for these competencies:\n\n"
            f"Competencies: {json.dumps(competencies)}\n\n"
            f"Candidate's Experience:\n{json.dumps(experience, default=str)[:5000]}\n\n"
            f"Create one compelling STAR example per competency, drawing "
            f"from the candidate's actual experience. Quantify results."
        )
        response = await self.call_llm(
            prompt=prompt, system_prompt=STAR_EXAMPLES_SYSTEM,
            response_format={"type": "json_object"}, temperature=0.6,
        )
        parsed = json.loads(response)
        if isinstance(parsed, dict):
            parsed = parsed.get("examples", parsed.get("star_examples", []))
        return parsed if isinstance(parsed, list) else []

    @agent_error_handler
    async def conduct_mock_interview(self, role: str, question: str, answer: str) -> dict:
        """Evaluate a candidate's answer in a mock interview setting.

        Args:
            role: The role being interviewed for.
            question: The interview question asked.
            answer: The candidate's answer to evaluate.

        Returns:
            Evaluation dict with scores, feedback, and improved answer.
        """
        prompt = (
            f"Evaluate this interview answer:\n\n"
            f"Role: {role}\nQuestion: {question}\n\n"
            f"Candidate's Answer:\n{answer}\n\n"
            f"Provide detailed, actionable feedback with category scores."
        )
        response = await self.call_llm(
            prompt=prompt, system_prompt=MOCK_INTERVIEW_SYSTEM,
            response_format={"type": "json_object"}, temperature=0.4,
        )
        return json.loads(response)

    @agent_error_handler
    async def research_company(self, company_name: str) -> dict:
        """Research a company for interview preparation.

        Args:
            company_name: Name of the company to research.

        Returns:
            Company research dict with culture, process, and insights.
        """
        prompt = (
            f"Provide comprehensive research on '{company_name}' for "
            f"job interview preparation. Include company culture, interview "
            f"process, technology stack, and smart questions to ask."
        )
        response = await self.call_llm(
            prompt=prompt, system_prompt=COMPANY_RESEARCH_SYSTEM,
            response_format={"type": "json_object"}, temperature=0.5,
        )
        return json.loads(response)

    @agent_error_handler
    async def suggest_learning_resources(self, skill_gaps: list) -> list[dict]:
        """Suggest learning resources to close identified skill gaps.

        Args:
            skill_gaps: List of dicts with 'skill', 'current_level', and
                        'target_level' keys, or simple skill name strings.

        Returns:
            List of resource recommendation dicts per skill.
        """
        normalized = []
        for gap in skill_gaps:
            if isinstance(gap, str):
                normalized.append({"skill": gap, "current_level": "beginner", "target_level": "intermediate"})
            else:
                normalized.append(gap)

        prompt = (
            f"Suggest learning resources for these skill gaps:\n\n"
            f"{json.dumps(normalized, indent=2)}\n\n"
            f"Prioritize free, high-quality resources with a mix of formats."
        )
        response = await self.call_llm(
            prompt=prompt, system_prompt=LEARNING_RESOURCES_SYSTEM,
            response_format={"type": "json_object"}, temperature=0.5,
        )
        parsed = json.loads(response)
        if isinstance(parsed, dict):
            parsed = parsed.get("resources", parsed.get("skill_gaps", []))
        return parsed if isinstance(parsed, list) else []
