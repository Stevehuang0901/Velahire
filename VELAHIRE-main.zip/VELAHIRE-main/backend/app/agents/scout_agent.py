"""
Scout Agent – Job discovery, matching, and market analysis.

Searches across multiple job platforms, computes detailed match scores
between candidate profiles and job listings, and provides labour-market
intelligence.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Optional

from .base import AgentConfig, BaseAgent, agent_error_handler

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class Job:
    """Minimal representation of a job listing."""

    id: str = ""
    title: str = ""
    company: str = ""
    location: str = ""
    description: str = ""
    requirements: list[str] = field(default_factory=list)
    salary_range: Optional[str] = None
    url: str = ""
    platform: str = ""
    posted_date: Optional[str] = None
    job_type: str = ""  # full-time, contract, etc.
    remote: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class MatchScore:
    """Breakdown of how well a candidate matches a job."""

    overall: float = 0.0
    skill_match: float = 0.0
    experience_match: float = 0.0
    education_match: float = 0.0
    keyword_overlap: float = 0.0
    location_match: float = 0.0
    details: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

JOB_SCRAPE_SYSTEM = (
    "You are a job-listing extraction engine.  Given raw HTML or text from a "
    "job posting, return a JSON object with the following keys:\n\n"
    '  "title": str\n  "company": str\n  "location": str\n'
    '  "description": str\n  "requirements": [str]\n'
    '  "salary_range": str or null\n  "job_type": str\n'
    '  "remote": bool\n  "posted_date": str or null\n'
    '  "benefits": [str]\n  "qualifications": [str]\n'
    '  "responsibilities": [str]\n\n'
    "Extract every detail present; use null for missing fields."
)

MATCH_SCORE_SYSTEM = (
    "You are a recruitment-matching engine.  Compare the candidate profile to "
    "the job listing and return a JSON object:\n\n"
    '  "overall": float (0-100)\n'
    '  "skill_match": float (0-100)\n'
    '  "experience_match": float (0-100)\n'
    '  "education_match": float (0-100)\n'
    '  "keyword_overlap": float (0-100)\n'
    '  "location_match": float (0-100)\n'
    '  "matched_skills": [str]\n'
    '  "missing_skills": [str]\n'
    '  "matched_keywords": [str]\n'
    '  "strengths": [str]\n'
    '  "gaps": [str]\n'
    '  "recommendation": str\n\n'
    "Be data-driven; consider years of experience, skill overlap, education "
    "requirements, and location preferences."
)

MARKET_ANALYSIS_SYSTEM = (
    "You are a labour-market analyst.  Provide a comprehensive market analysis "
    "for the given industry and role.  Return JSON:\n\n"
    '  "demand_level": str (high/medium/low)\n'
    '  "salary_range": {min, median, max, currency}\n'
    '  "growth_outlook": str\n'
    '  "top_skills_in_demand": [str]\n'
    '  "top_employers": [str]\n'
    '  "geographic_hotspots": [str]\n'
    '  "remote_availability": str\n'
    '  "competition_level": str\n'
    '  "emerging_trends": [str]\n'
    '  "advice": str\n'
)


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------


class ScoutAgent(BaseAgent):
    """Discovers jobs, computes match scores, and provides market intelligence."""

    name: str = "ScoutAgent"
    description: str = "Job discovery, matching, and market analysis"

    SUPPORTED_PLATFORMS = ("indeed", "linkedin", "glassdoor")

    def __init__(self, config: Optional[AgentConfig] = None) -> None:
        super().__init__(config)

    # -- Public API -----------------------------------------------------------

    @agent_error_handler
    async def execute(
        self,
        profile: dict[str, Any],
        criteria: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Full pipeline: search → match → rank."""
        criteria = criteria or self._criteria_from_profile(profile)
        jobs = await self.search_jobs(criteria)
        matches = []
        for job in jobs:
            score = await self.calculate_match_score(profile, job)
            matches.append({"job": job, "score": score})
        ranked = await self.rank_and_filter(
            matches, preferences=criteria.get("preferences", {})
        )
        return {"jobs_found": len(jobs), "matches": ranked}

    @agent_error_handler
    async def search_jobs(
        self, criteria: dict[str, Any]
    ) -> list[Job]:
        """Orchestrate job search across configured platforms.

        Parameters
        ----------
        criteria:
            Dict with keys such as ``title``, ``location``, ``keywords``,
            ``remote``, ``salary_min``, and ``platforms``.

        Returns
        -------
        list[Job]
            Aggregated and deduplicated job listings.
        """
        platforms = criteria.get("platforms", list(self.SUPPORTED_PLATFORMS))
        all_jobs: list[Job] = []

        for platform in platforms:
            platform = platform.lower()
            try:
                jobs = await self._search_platform(platform, criteria)
                all_jobs.extend(jobs)
                self.logger.info(
                    "Found %d jobs on %s", len(jobs), platform
                )
            except Exception as exc:
                self.logger.warning(
                    "Platform %s search failed: %s", platform, exc
                )

        # Deduplicate by title+company
        seen: set[str] = set()
        unique: list[Job] = []
        for job in all_jobs:
            key = f"{job.title.lower().strip()}|{job.company.lower().strip()}"
            if key not in seen:
                seen.add(key)
                unique.append(job)

        return unique

    @agent_error_handler
    async def scrape_job_listing(
        self, url: str, platform: str = "generic"
    ) -> dict[str, Any]:
        """Fetch and extract structured data from a single job-listing URL.

        Uses ``httpx`` to retrieve the page and an LLM to parse the HTML into
        a structured dict.
        """
        import httpx

        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "en-US,en;q=0.9",
        }

        async with httpx.AsyncClient(
            follow_redirects=True, timeout=30.0
        ) as client:
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()

        from bs4 import BeautifulSoup

        soup = BeautifulSoup(resp.text, "html.parser")
        # Remove scripts/styles to reduce token usage
        for tag in soup(["script", "style", "nav", "footer", "header"]):
            tag.decompose()
        clean_text = soup.get_text(separator="\n", strip=True)[:12000]

        response = await self.call_llm(
            prompt=f"Extract job details from this listing ({platform}):\n\n{clean_text}",
            system_prompt=JOB_SCRAPE_SYSTEM,
            response_format={"type": "json_object"},
        )
        data = json.loads(response)
        data["url"] = url
        data["platform"] = platform
        return data

    @agent_error_handler
    async def calculate_match_score(
        self, profile: dict[str, Any], job: Any
    ) -> MatchScore:
        """Compute a detailed match score between a profile and a job.

        Combines algorithmic keyword overlap with LLM-based qualitative
        assessment.
        """
        # Prepare job dict
        if hasattr(job, "__dict__"):
            job_dict = {
                k: v for k, v in job.__dict__.items() if not k.startswith("_")
            }
        elif isinstance(job, dict):
            job_dict = job
        else:
            job_dict = {"description": str(job)}

        # Algorithmic keyword overlap
        profile_skills = {
            s.lower()
            for s in profile.get("skills", {}).get("all", [])
        }
        job_text = (
            job_dict.get("description", "")
            + " "
            + " ".join(job_dict.get("requirements", []))
        ).lower()
        job_keywords = set(re.findall(r"\b[a-z][a-z+#/.]{1,30}\b", job_text))
        overlap = profile_skills & job_keywords
        keyword_score = (
            (len(overlap) / len(profile_skills) * 100) if profile_skills else 0.0
        )

        # LLM-based assessment
        prompt = (
            "Profile:\n"
            f"{json.dumps(profile, default=str)[:4000]}\n\n"
            "Job:\n"
            f"{json.dumps(job_dict, default=str)[:4000]}"
        )
        response = await self.call_llm(
            prompt=prompt,
            system_prompt=MATCH_SCORE_SYSTEM,
            response_format={"type": "json_object"},
        )
        llm_scores = json.loads(response)

        # Blend algorithmic and LLM scores (70% LLM, 30% algorithmic keyword)
        blended_keyword = llm_scores.get("keyword_overlap", 0) * 0.7 + keyword_score * 0.3

        return MatchScore(
            overall=llm_scores.get("overall", 0),
            skill_match=llm_scores.get("skill_match", 0),
            experience_match=llm_scores.get("experience_match", 0),
            education_match=llm_scores.get("education_match", 0),
            keyword_overlap=round(blended_keyword, 1),
            location_match=llm_scores.get("location_match", 0),
            details={
                "matched_skills": llm_scores.get("matched_skills", []),
                "missing_skills": llm_scores.get("missing_skills", []),
                "matched_keywords": list(overlap),
                "strengths": llm_scores.get("strengths", []),
                "gaps": llm_scores.get("gaps", []),
                "recommendation": llm_scores.get("recommendation", ""),
            },
        )

    @agent_error_handler
    async def rank_and_filter(
        self,
        matches: list[dict[str, Any]],
        preferences: Optional[dict[str, Any]] = None,
    ) -> list[dict[str, Any]]:
        """Apply user preferences and rank matches by overall score.

        Parameters
        ----------
        matches:
            List of ``{"job": Job, "score": MatchScore}`` dicts.
        preferences:
            Optional dict with keys like ``min_score``, ``remote_only``,
            ``excluded_companies``, ``preferred_locations``.
        """
        prefs = preferences or {}
        min_score = prefs.get("min_score", 0)
        remote_only = prefs.get("remote_only", False)
        excluded = {c.lower() for c in prefs.get("excluded_companies", [])}

        filtered = []
        for m in matches:
            score: MatchScore = m["score"]
            job: Job = m["job"] if isinstance(m["job"], Job) else Job(**m["job"]) if isinstance(m["job"], dict) else m["job"]

            if score.overall < min_score:
                continue
            if remote_only and not getattr(job, "remote", False):
                continue
            if getattr(job, "company", "").lower() in excluded:
                continue
            filtered.append(m)

        filtered.sort(key=lambda m: m["score"].overall, reverse=True)
        return filtered

    @agent_error_handler
    async def analyze_market(
        self, industry: str, role: str
    ) -> dict[str, Any]:
        """Return labour-market intelligence for a given industry + role."""
        response = await self.call_llm(
            prompt=(
                f"Provide a comprehensive market analysis for the role of "
                f"'{role}' in the '{industry}' industry.  Include salary data, "
                f"demand level, geographic hotspots, and emerging trends."
            ),
            system_prompt=MARKET_ANALYSIS_SYSTEM,
            response_format={"type": "json_object"},
        )
        return json.loads(response)

    # -- Platform-specific scrapers (internal) --------------------------------

    async def _search_platform(
        self, platform: str, criteria: dict[str, Any]
    ) -> list[Job]:
        """Dispatch to the correct platform scraper."""
        scrapers = {
            "indeed": self._search_indeed,
            "linkedin": self._search_linkedin,
            "glassdoor": self._search_glassdoor,
        }
        scraper = scrapers.get(platform)
        if not scraper:
            self.logger.warning("Unsupported platform: %s", platform)
            return []
        return await scraper(criteria)

    async def _search_indeed(
        self, criteria: dict[str, Any]
    ) -> list[Job]:
        """Scrape Indeed search results.

        Constructs a search URL from criteria, fetches results, and parses
        listing cards into Job objects.
        """
        import httpx
        from bs4 import BeautifulSoup
        from urllib.parse import quote_plus

        title = quote_plus(criteria.get("title", "software engineer"))
        location = quote_plus(criteria.get("location", ""))
        url = f"https://www.indeed.com/jobs?q={title}&l={location}&sort=date"

        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            ),
        }

        try:
            async with httpx.AsyncClient(
                follow_redirects=True, timeout=30.0
            ) as client:
                resp = await client.get(url, headers=headers)
                resp.raise_for_status()

            soup = BeautifulSoup(resp.text, "html.parser")
            jobs: list[Job] = []

            for card in soup.select(".job_seen_beacon, .jobsearch-ResultsList > li"):
                title_el = card.select_one("h2.jobTitle a, .jobTitle > a")
                company_el = card.select_one("[data-testid='company-name'], .companyName")
                location_el = card.select_one("[data-testid='text-location'], .companyLocation")

                if title_el:
                    job = Job(
                        title=title_el.get_text(strip=True),
                        company=company_el.get_text(strip=True) if company_el else "",
                        location=location_el.get_text(strip=True) if location_el else "",
                        url="https://www.indeed.com" + title_el.get("href", ""),
                        platform="indeed",
                    )
                    jobs.append(job)

            return jobs[:20]
        except Exception as exc:
            self.logger.warning("Indeed scraping failed: %s", exc)
            return []

    async def _search_linkedin(
        self, criteria: dict[str, Any]
    ) -> list[Job]:
        """Scrape LinkedIn public job search results."""
        import httpx
        from bs4 import BeautifulSoup
        from urllib.parse import quote_plus

        title = quote_plus(criteria.get("title", "software engineer"))
        location = quote_plus(criteria.get("location", ""))
        url = (
            f"https://www.linkedin.com/jobs/search/?keywords={title}"
            f"&location={location}&sortBy=DD"
        )

        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            ),
        }

        try:
            async with httpx.AsyncClient(
                follow_redirects=True, timeout=30.0
            ) as client:
                resp = await client.get(url, headers=headers)
                resp.raise_for_status()

            soup = BeautifulSoup(resp.text, "html.parser")
            jobs: list[Job] = []

            for card in soup.select(".base-card, .job-search-card"):
                title_el = card.select_one(".base-search-card__title, h3")
                company_el = card.select_one(".base-search-card__subtitle, h4")
                location_el = card.select_one(".job-search-card__location")
                link_el = card.select_one("a.base-card__full-link, a")

                if title_el:
                    job = Job(
                        title=title_el.get_text(strip=True),
                        company=company_el.get_text(strip=True) if company_el else "",
                        location=location_el.get_text(strip=True) if location_el else "",
                        url=link_el.get("href", "") if link_el else "",
                        platform="linkedin",
                    )
                    jobs.append(job)

            return jobs[:20]
        except Exception as exc:
            self.logger.warning("LinkedIn scraping failed: %s", exc)
            return []

    async def _search_glassdoor(
        self, criteria: dict[str, Any]
    ) -> list[Job]:
        """Scrape Glassdoor job search results."""
        import httpx
        from bs4 import BeautifulSoup
        from urllib.parse import quote_plus

        title = quote_plus(criteria.get("title", "software engineer"))
        url = f"https://www.glassdoor.com/Job/jobs.htm?sc.keyword={title}"

        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            ),
        }

        try:
            async with httpx.AsyncClient(
                follow_redirects=True, timeout=30.0
            ) as client:
                resp = await client.get(url, headers=headers)
                resp.raise_for_status()

            soup = BeautifulSoup(resp.text, "html.parser")
            jobs: list[Job] = []

            for card in soup.select("[data-test='jobListing'], .react-job-listing"):
                title_el = card.select_one("[data-test='job-title'], .job-title")
                company_el = card.select_one("[data-test='emp-name'], .employer-name")
                location_el = card.select_one("[data-test='emp-location'], .location")

                if title_el:
                    job = Job(
                        title=title_el.get_text(strip=True),
                        company=company_el.get_text(strip=True) if company_el else "",
                        location=location_el.get_text(strip=True) if location_el else "",
                        url="https://www.glassdoor.com" + title_el.get("href", ""),
                        platform="glassdoor",
                    )
                    jobs.append(job)

            return jobs[:20]
        except Exception as exc:
            self.logger.warning("Glassdoor scraping failed: %s", exc)
            return []

    # -- Helpers --------------------------------------------------------------

    @staticmethod
    def _criteria_from_profile(profile: dict[str, Any]) -> dict[str, Any]:
        """Derive search criteria from a candidate profile."""
        latest_title = ""
        experience = profile.get("experience", [])
        if experience:
            latest_title = experience[0].get("title", "")

        location = profile.get("contact", {}).get("location", "")

        return {
            "title": latest_title,
            "location": location,
            "keywords": profile.get("skills", {}).get("technical", [])[:10],
            "platforms": ["indeed", "linkedin", "glassdoor"],
        }
