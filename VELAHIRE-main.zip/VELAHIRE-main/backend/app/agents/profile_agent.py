"""
Profile Agent – Resume parsing, profile building, and career analysis.

Responsible for ingesting raw resumes (PDF / DOCX / plain text), extracting
structured data via LLM, generating vector embeddings for semantic matching,
and providing resume quality feedback.
"""

from __future__ import annotations

import json
import os
from typing import Any, Optional

from .base import AgentConfig, BaseAgent, agent_error_handler

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

RESUME_PARSE_SYSTEM = (
    "You are an expert HR technology system that extracts structured data from "
    "resumes.  Return a valid JSON object with the following top-level keys:\n\n"
    '  "contact": {name, email, phone, location, linkedin, github, website}\n'
    '  "summary": string – professional summary or objective\n'
    '  "experience": [{title, company, location, start_date, end_date, '
    "description, achievements: [str]}]\n"
    '  "education": [{degree, institution, location, graduation_date, gpa, '
    "honors}]\n"
    '  "skills": {technical: [str], soft: [str], tools: [str], languages: [str]}\n'
    '  "certifications": [{name, issuer, date, expiry}]\n'
    '  "projects": [{name, description, technologies: [str], url}]\n'
    '  "publications": [{title, venue, date}]\n\n'
    "Be thorough – extract every item present.  Use null for missing fields.\n"
    "Dates should be ISO-8601 where possible (YYYY-MM or YYYY-MM-DD)."
)

RESUME_QUALITY_SYSTEM = (
    "You are an ATS (Applicant Tracking System) resume expert.  Evaluate the "
    "resume text and return a JSON object:\n\n"
    '  "overall_score": int (1-10)\n'
    '  "categories": {\n'
    '    "formatting": {"score": int, "feedback": str},\n'
    '    "keywords": {"score": int, "feedback": str},\n'
    '    "quantification": {"score": int, "feedback": str},\n'
    '    "layout": {"score": int, "feedback": str},\n'
    '    "relevance": {"score": int, "feedback": str}\n'
    "  }\n"
    '  "suggestions": [str] – ordered list of actionable improvements\n'
    '  "missing_sections": [str]\n'
    '  "keyword_density": float (0-1)\n'
)

CAREER_PATH_SYSTEM = (
    "You are a senior career counsellor and labor-market analyst.  Given the "
    "candidate's profile, analyse their career trajectory and provide:\n\n"
    '  "trajectory_summary": str\n'
    '  "current_level": str (e.g. "Mid-Senior", "Entry", "Executive")\n'
    '  "strengths": [str]\n'
    '  "growth_areas": [str]\n'
    '  "suggested_next_roles": [{title, rationale, estimated_salary_range}]\n'
    '  "suggested_industries": [{industry, rationale}]\n'
    '  "skill_gaps": [{skill, importance, learning_path}]\n'
    '  "timeline": str – suggested 1-3 year roadmap\n\n'
    "Return valid JSON."
)


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------


class ProfileAgent(BaseAgent):
    """Parses resumes, constructs structured profiles, generates embeddings,
    and provides career-path analysis."""

    name: str = "ProfileAgent"
    description: str = "Resume parsing, profile building, and career analysis"

    def __init__(self, config: Optional[AgentConfig] = None) -> None:
        super().__init__(config)

    # -- Public API -----------------------------------------------------------

    @agent_error_handler
    async def execute(
        self, file_path: str, file_type: str = "pdf", **kwargs: Any
    ) -> dict[str, Any]:
        """Full pipeline: parse → build profile → generate embeddings → quality check."""
        parsed = await self.parse_resume(file_path, file_type)
        profile = await self.build_profile(parsed)
        embeddings = await self.generate_embeddings(profile)
        quality = await self.assess_resume_quality(parsed)
        career = await self.analyze_career_path(profile)

        return {
            "parsed_data": parsed,
            "profile": profile,
            "embeddings": embeddings,
            "quality_assessment": quality,
            "career_analysis": career,
        }

    @agent_error_handler
    async def parse_resume(
        self, file_path: str, file_type: str = "pdf"
    ) -> dict[str, Any]:
        """Extract text from a resume file and parse it into structured JSON
        using an LLM.

        Parameters
        ----------
        file_path:
            Absolute path to the resume file.
        file_type:
            One of ``pdf``, ``docx``, or ``txt``.

        Returns
        -------
        dict
            Structured resume data (contact, experience, education, …).
        """
        raw_text = await self._extract_text(file_path, file_type)

        if not raw_text or not raw_text.strip():
            raise ValueError(f"No text could be extracted from {file_path}")

        response = await self.call_llm(
            prompt=f"Parse the following resume:\n\n{raw_text}",
            system_prompt=RESUME_PARSE_SYSTEM,
            response_format={"type": "json_object"},
        )
        parsed: dict[str, Any] = json.loads(response)
        parsed["_raw_text"] = raw_text
        parsed["_source_file"] = file_path
        parsed["_file_type"] = file_type
        return parsed

    @agent_error_handler
    async def build_profile(self, parsed_data: dict[str, Any]) -> dict[str, Any]:
        """Transform raw parsed data into a canonical VelaHire profile dict.

        Normalises fields, deduplicates skills, and calculates derived
        attributes such as total years of experience.
        """
        skills_raw = parsed_data.get("skills", {})
        all_skills: list[str] = []
        for category in ("technical", "soft", "tools", "languages"):
            all_skills.extend(skills_raw.get(category, []) or [])
        unique_skills = list(dict.fromkeys(s.strip() for s in all_skills if s))

        experience = parsed_data.get("experience", []) or []
        total_years = self._estimate_years(experience)

        profile: dict[str, Any] = {
            "contact": parsed_data.get("contact", {}),
            "summary": parsed_data.get("summary"),
            "experience": experience,
            "education": parsed_data.get("education", []),
            "skills": {
                "all": unique_skills,
                "technical": skills_raw.get("technical", []),
                "soft": skills_raw.get("soft", []),
                "tools": skills_raw.get("tools", []),
                "languages": skills_raw.get("languages", []),
            },
            "certifications": parsed_data.get("certifications", []),
            "projects": parsed_data.get("projects", []),
            "publications": parsed_data.get("publications", []),
            "total_years_experience": total_years,
        }
        return profile

    @agent_error_handler
    async def generate_embeddings(
        self, profile: dict[str, Any]
    ) -> list[float]:
        """Generate a vector embedding for the profile using the OpenAI
        embeddings API.

        The text fed to the model is a distilled representation of the
        candidate's skills, experience titles, and summary.
        """
        parts: list[str] = []
        if profile.get("summary"):
            parts.append(profile["summary"])
        for exp in profile.get("experience", []):
            title = exp.get("title", "")
            company = exp.get("company", "")
            if title:
                parts.append(f"{title} at {company}" if company else title)
        parts.extend(profile.get("skills", {}).get("all", []))

        text = " | ".join(parts) if parts else "general candidate profile"

        from openai import AsyncOpenAI

        client = self.openai_client  # reuse cached client
        response = await client.embeddings.create(
            model="text-embedding-3-small",
            input=text[:8000],  # stay within token limits
        )
        return response.data[0].embedding

    @agent_error_handler
    async def assess_resume_quality(
        self, parsed_data: dict[str, Any]
    ) -> dict[str, Any]:
        """Score the resume on ATS-friendliness and return actionable
        suggestions.

        Returns
        -------
        dict
            Contains ``overall_score`` (1-10), per-category scores, and a list
            of improvement suggestions.
        """
        raw_text = parsed_data.get("_raw_text", json.dumps(parsed_data, default=str))

        response = await self.call_llm(
            prompt=(
                "Evaluate the following resume for ATS compatibility and "
                f"overall quality:\n\n{raw_text}"
            ),
            system_prompt=RESUME_QUALITY_SYSTEM,
            response_format={"type": "json_object"},
        )
        return json.loads(response)

    @agent_error_handler
    async def analyze_career_path(
        self, profile: dict[str, Any]
    ) -> dict[str, Any]:
        """Analyse the candidate's career trajectory and suggest future paths.

        Returns
        -------
        dict
            Trajectory summary, suggested roles, skill gaps, and a timeline.
        """
        profile_summary = json.dumps(profile, default=str, indent=2)

        response = await self.call_llm(
            prompt=(
                "Analyze the following candidate profile and provide career "
                f"path recommendations:\n\n{profile_summary}"
            ),
            system_prompt=CAREER_PATH_SYSTEM,
            response_format={"type": "json_object"},
        )
        return json.loads(response)

    # -- Internal helpers -----------------------------------------------------

    @staticmethod
    async def _extract_text(file_path: str, file_type: str) -> str:
        """Read raw text from a resume file on disk.

        Supports PDF (via PyPDF2), DOCX (via python-docx), and plain text.
        """
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"Resume file not found: {file_path}")

        file_type = file_type.lower().strip(".")

        if file_type == "pdf":
            from PyPDF2 import PdfReader

            reader = PdfReader(file_path)
            pages = [page.extract_text() or "" for page in reader.pages]
            return "\n".join(pages)

        if file_type in ("docx", "doc"):
            from docx import Document

            doc = Document(file_path)
            return "\n".join(para.text for para in doc.paragraphs)

        if file_type in ("txt", "text", "md"):
            with open(file_path, "r", encoding="utf-8") as fh:
                return fh.read()

        raise ValueError(f"Unsupported file type: {file_type}")

    @staticmethod
    def _estimate_years(experience: list[dict[str, Any]]) -> float:
        """Best-effort estimate of total years of professional experience."""
        from datetime import datetime

        total_months = 0
        for exp in experience:
            start = exp.get("start_date")
            end = exp.get("end_date")
            if not start:
                continue
            try:
                start_dt = datetime.fromisoformat(start.replace("Z", ""))
                if end and end.lower() not in ("present", "current", "now"):
                    end_dt = datetime.fromisoformat(end.replace("Z", ""))
                else:
                    end_dt = datetime.now()
                months = (end_dt.year - start_dt.year) * 12 + (
                    end_dt.month - start_dt.month
                )
                total_months += max(months, 0)
            except (ValueError, TypeError):
                continue
        return round(total_months / 12, 1)
