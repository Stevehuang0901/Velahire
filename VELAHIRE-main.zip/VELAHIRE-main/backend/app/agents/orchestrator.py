"""
Agent Orchestrator – Coordinates all AI agents for end-to-end workflows.

Manages state, routes tasks to the appropriate agent, handles error
recovery, and provides the main entry points consumed by API routes
and Celery tasks.
"""

from __future__ import annotations

import asyncio
import logging
import os
import tempfile
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

from .base import AgentConfig, AgentExecutionError
from .profile_agent import ProfileAgent
from .scout_agent import ScoutAgent
from .writer_agent import WriterAgent
from .apply_agent import ApplyAgent
from .monitor_agent import MonitorAgent
from .coach_agent import CoachAgent

logger = logging.getLogger(__name__)


class AgentOrchestrator:
    """Coordinates multi-agent workflows for the VelaHire platform.

    Initialises all six specialised agents and exposes high-level pipeline
    methods that chain agent calls together with state management and
    error recovery.
    """

    def __init__(self, config: Optional[AgentConfig] = None) -> None:
        self.config = config or AgentConfig()
        self.profile_agent = ProfileAgent(self.config)
        self.scout_agent = ScoutAgent(self.config)
        self.writer_agent = WriterAgent(self.config)
        self.apply_agent = ApplyAgent(self.config)
        self.monitor_agent = MonitorAgent(self.config)
        self.coach_agent = CoachAgent(self.config)
        self._state: dict[str, dict[str, Any]] = {}
        self.logger = logging.getLogger("velahire.orchestrator")

    # ------------------------------------------------------------------
    # State management
    # ------------------------------------------------------------------

    def _init_state(self, workflow_id: str, workflow_type: str) -> dict[str, Any]:
        state = {
            "workflow_id": workflow_id,
            "workflow_type": workflow_type,
            "status": "started",
            "started_at": datetime.now(timezone.utc).isoformat(),
            "completed_at": None,
            "current_step": None,
            "steps_completed": [],
            "error": None,
            "result": None,
        }
        self._state[workflow_id] = state
        return state

    def _update_state(
        self, workflow_id: str, *, step: str | None = None,
        status: str | None = None, result: Any = None, error: str | None = None,
    ) -> None:
        state = self._state.get(workflow_id, {})
        if step:
            state["current_step"] = step
            state.setdefault("steps_completed", []).append(step)
        if status:
            state["status"] = status
        if result is not None:
            state["result"] = result
        if error:
            state["error"] = error
            state["status"] = "failed"
        if status == "completed":
            state["completed_at"] = datetime.now(timezone.utc).isoformat()

    # ------------------------------------------------------------------
    # Pipeline: Resume Upload
    # ------------------------------------------------------------------

    async def process_resume_upload(
        self, user_id: str, file_content: bytes, file_type: str
    ) -> dict[str, Any]:
        """Pipeline: parse resume -> build profile -> generate embeddings -> quality score.

        Args:
            user_id: The user's UUID string.
            file_content: Raw bytes of the uploaded resume file.
            file_type: MIME type or extension (pdf, docx, txt).

        Returns:
            Dict with parsed_data, profile, quality assessment, and career analysis.
        """
        wid = str(uuid.uuid4())
        self._init_state(wid, "resume_upload")
        self.logger.info("Resume upload pipeline for user %s [%s]", user_id, wid)

        # ProfileAgent.parse_resume expects a file path, so persist bytes to a
        # temporary file that is cleaned up after the pipeline completes.
        ext = file_type if file_type.startswith(".") else f".{file_type}"
        tmp = tempfile.NamedTemporaryFile(suffix=ext, delete=False)
        file_path = tmp.name
        try:
            tmp.write(file_content)
            tmp.flush()
            tmp.close()

            self._update_state(wid, step="parse_resume")
            parsed = await self.profile_agent.parse_resume(file_path, file_type)

            self._update_state(wid, step="build_profile")
            profile = await self.profile_agent.build_profile(parsed)

            self._update_state(wid, step="generate_embeddings")
            try:
                embeddings = await self.profile_agent.generate_embeddings(profile)
            except Exception as exc:
                self.logger.warning("Embedding generation failed (non-critical): %s", exc)
                embeddings = []

            self._update_state(wid, step="assess_quality")
            quality = await self.profile_agent.assess_resume_quality(parsed)

            self._update_state(wid, step="analyze_career")
            career = await self.profile_agent.analyze_career_path(profile)

            result = {
                "workflow_id": wid,
                "user_id": user_id,
                "parsed_data": parsed,
                "profile": profile,
                "embedding_dimensions": len(embeddings),
                "ats_score": quality,
                "career_path": career,
            }
            self._update_state(wid, status="completed", result=result)
            return result

        except Exception as exc:
            self._update_state(wid, error=str(exc))
            raise
        finally:
            # Clean up the temporary resume file
            try:
                os.unlink(file_path)
            except OSError:
                pass

    # ------------------------------------------------------------------
    # Pipeline: Job Matching
    # ------------------------------------------------------------------

    async def process_job_matching(
        self, user_id: str, profile: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        """Pipeline: search jobs -> calculate match scores -> rank and filter."""
        wid = str(uuid.uuid4())
        self._init_state(wid, "job_matching")
        self.logger.info("Job matching pipeline for user %s [%s]", user_id, wid)

        try:
            if profile is None:
                profile = await self._load_user_profile(user_id)

            self._update_state(wid, step="search_jobs")
            criteria = self.scout_agent._criteria_from_profile(profile)
            jobs = await self.scout_agent.search_jobs(criteria)

            self._update_state(wid, step="calculate_scores")
            matches = []
            for job in jobs:
                try:
                    score = await self.scout_agent.calculate_match_score(profile, job)
                    matches.append({"job": job, "score": score})
                except Exception as exc:
                    self.logger.warning("Score calculation failed: %s", exc)

            self._update_state(wid, step="rank_and_filter")
            ranked = await self.scout_agent.rank_and_filter(matches, {})

            self._update_state(wid, status="completed", result=ranked)
            return ranked

        except Exception as exc:
            self._update_state(wid, error=str(exc))
            raise

    # ------------------------------------------------------------------
    # Pipeline: Content Generation
    # ------------------------------------------------------------------

    async def process_content_generation(
        self,
        match_id: str | None = None,
        match_data: dict[str, Any] | None = None,
        profile: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Pipeline: generate cover letter + tailor resume + background statement."""
        wid = str(uuid.uuid4())
        self._init_state(wid, "content_generation")
        self.logger.info("Content generation for match %s [%s]", match_id or "inline", wid)

        try:
            if match_data is None and match_id:
                match_data = await self._load_match_data(match_id)
            if match_data is None:
                raise ValueError("Either match_id or match_data must be provided")
            if profile is None:
                profile = match_data.get("profile", {})

            job = match_data.get("job", {})

            self._update_state(wid, step="cover_letter")
            cover_letter = await self.writer_agent.generate_cover_letter(profile, job)

            self._update_state(wid, step="tailor_resume")
            tailored_resume = await self.writer_agent.tailor_resume(profile, job)

            self._update_state(wid, step="background_statement")
            background = await self.writer_agent.generate_background_statement(profile, job)

            self._update_state(wid, step="open_questions")
            open_questions = match_data.get("open_questions", [])
            answers: list[dict[str, str]] = []
            if open_questions:
                answers = await self.writer_agent.answer_open_questions(open_questions, profile, job)

            result = {
                "workflow_id": wid,
                "cover_letter": cover_letter,
                "tailored_resume": tailored_resume,
                "background_statement": background,
                "open_question_answers": answers,
            }
            self._update_state(wid, status="completed", result=result)
            return result

        except Exception as exc:
            self._update_state(wid, error=str(exc))
            raise

    # ------------------------------------------------------------------
    # Pipeline: Application Submission
    # ------------------------------------------------------------------

    async def process_application(
        self,
        match_id: str | None = None,
        match_data: dict[str, Any] | None = None,
        content: dict[str, Any] | None = None,
        credentials: dict[str, str] | None = None,
        mode: str = "copilot",
    ) -> dict[str, Any]:
        """Pipeline: apply to a job in copilot or autopilot mode."""
        wid = str(uuid.uuid4())
        self._init_state(wid, "application")
        self.logger.info("Application in %s mode [%s]", mode, wid)

        try:
            if match_data is None and match_id:
                match_data = await self._load_match_data(match_id)
            if match_data is None:
                raise ValueError("Either match_id or match_data must be provided")

            if content is None:
                content = await self.process_content_generation(match_data=match_data)

            if mode == "autopilot":
                self._update_state(wid, step="submit_application")
                result = await self.apply_agent.execute_application(
                    match_data, content, credentials or {}
                )
                self._update_state(wid, status="completed", result=result)
                return result
            else:
                result = {
                    "status": "pending_review",
                    "workflow_id": wid,
                    "content": content,
                    "message": "Content ready for your review before submission",
                }
                self._update_state(wid, status="completed", result=result)
                return result

        except Exception as exc:
            self._update_state(wid, error=str(exc))
            raise

    # ------------------------------------------------------------------
    # Pipeline: Bulk Apply
    # ------------------------------------------------------------------

    async def process_bulk_apply(
        self,
        match_ids: list[str] | None = None,
        matches: list[dict[str, Any]] | None = None,
        profile: dict[str, Any] | None = None,
        credentials: dict[str, str] | None = None,
        mode: str = "copilot",
    ) -> list[dict[str, Any]]:
        """Apply to multiple jobs with rate limiting and error isolation."""
        results: list[dict[str, Any]] = []

        if matches is None and match_ids:
            matches = []
            for mid in match_ids:
                try:
                    matches.append(await self._load_match_data(mid))
                except Exception as exc:
                    results.append({"match_id": mid, "success": False, "error": str(exc)})

        for match_data in (matches or []):
            try:
                content = await self.process_content_generation(match_data=match_data, profile=profile)
                result = await self.process_application(
                    match_data=match_data, content=content, credentials=credentials, mode=mode,
                )
                results.append(result)
                await asyncio.sleep(2.0)
            except Exception as exc:
                self.logger.error("Bulk apply item failed: %s", exc, exc_info=True)
                results.append({
                    "job": match_data.get("job", {}).get("title", "unknown"),
                    "success": False,
                    "error": str(exc),
                })

        return results

    # ------------------------------------------------------------------
    # Pipeline: Interview Preparation
    # ------------------------------------------------------------------

    async def generate_interview_prep(
        self,
        match_id: str | None = None,
        company: str = "",
        role: str = "",
        profile: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Pipeline: research company -> generate prep -> STAR examples."""
        wid = str(uuid.uuid4())
        self._init_state(wid, "interview_prep")

        try:
            if match_id and (not company or not role):
                match_data = await self._load_match_data(match_id)
                job = match_data.get("job", {})
                company = company or job.get("company", "")
                role = role or job.get("title", "")
                if profile is None:
                    profile = match_data.get("profile", {})

            if profile is None:
                profile = {}

            self.logger.info("Interview prep for %s at %s [%s]", role, company, wid)

            self._update_state(wid, step="prepare_interview")
            prep = await self.coach_agent.prepare_interview(company, role, profile)

            self._update_state(wid, step="research_company")
            company_info = await self.coach_agent.research_company(company)

            self._update_state(wid, step="star_examples")
            competencies = ["leadership", "problem-solving", "teamwork", "communication", "adaptability"]
            star = await self.coach_agent.generate_star_examples(profile.get("experience", []), competencies)

            result = {
                "workflow_id": wid,
                "interview_prep": prep,
                "company_research": company_info,
                "star_examples": star,
            }
            self._update_state(wid, status="completed", result=result)
            return result

        except Exception as exc:
            self._update_state(wid, error=str(exc))
            raise

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _load_user_profile(self, user_id: str) -> dict[str, Any]:
        """Load a user's profile from the database."""
        from uuid import UUID as UUIDType
        from sqlalchemy import select
        from app.core.database import async_session_factory
        from app.models.profile import Profile

        async with async_session_factory() as session:
            result = await session.execute(
                select(Profile).where(Profile.user_id == UUIDType(user_id))
            )
            profile = result.scalar_one_or_none()
            if profile is None:
                raise ValueError(f"No profile found for user {user_id}")
            return {
                "skills": profile.skills or {},
                "experience": profile.experience or [],
                "education": profile.education or [],
                "certifications": profile.certifications or [],
                "summary": profile.summary or "",
                "career_objectives": profile.career_objectives or "",
            }

    async def _load_match_data(self, match_id: str) -> dict[str, Any]:
        """Load match data (job + profile) from the database."""
        from uuid import UUID as UUIDType
        from sqlalchemy import select
        from sqlalchemy.orm import selectinload
        from app.core.database import async_session_factory
        from app.models.match import Match

        async with async_session_factory() as session:
            result = await session.execute(
                select(Match)
                .options(selectinload(Match.job), selectinload(Match.user))
                .where(Match.id == UUIDType(match_id))
            )
            match = result.scalar_one_or_none()
            if match is None:
                raise ValueError(f"No match found with ID {match_id}")

            job_data = {
                "title": match.job.title,
                "company": match.job.company,
                "location": match.job.location,
                "url": match.job.url,
                "description": match.job.jd_text,
                "required_skills": match.job.required_skills,
            }

            return {
                "match_id": match_id,
                "job": job_data,
                "profile": await self._load_user_profile(str(match.user_id)),
                "application_url": match.job.url,
            }
