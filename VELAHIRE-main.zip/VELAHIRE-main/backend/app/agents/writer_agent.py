"""
Writer Agent – Content generation for job applications.

Generates cover letters, tailored resumes, professional summaries,
background statements, and answers to open-ended application questions.
Supports writing-style cloning to maintain the candidate's voice.
"""

from __future__ import annotations

import json
from typing import Any, Optional

from .base import AgentConfig, BaseAgent, agent_error_handler

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

COVER_LETTER_SYSTEM = (
    "You are an expert career writer who crafts compelling, personalised cover "
    "letters.  Follow these rules:\n\n"
    "1. Address the hiring manager by name if available, otherwise use the "
    "company name.\n"
    "2. Open with a strong hook that connects the candidate's passion to the "
    "company's mission.\n"
    "3. In the body, map 2-3 of the candidate's strongest achievements to the "
    "job's key requirements.  Use specific metrics and results.\n"
    "4. Close with enthusiasm and a clear call to action.\n"
    "5. Keep it under 400 words.\n"
    "6. Match the requested tone/style: professional, conversational, or bold.\n"
    "7. Never fabricate experience – only use details from the profile.\n"
    "8. Avoid cliches like 'I am writing to apply for…' or 'I believe I am "
    "the perfect candidate'."
)

TAILOR_RESUME_SYSTEM = (
    "You are an ATS-optimisation specialist.  Given a candidate profile and a "
    "target job listing, adjust the resume content for maximum relevance.  "
    "Return a JSON object:\n\n"
    '  "summary": str – rewritten professional summary targeting this role\n'
    '  "experience": [{...original with rewritten bullet points...}]\n'
    '  "skills_to_highlight": [str] – ordered by relevance to the job\n'
    '  "skills_to_add": [str] – transferable skills the candidate has but '
    "didn't list\n"
    '  "keywords_added": [str] – ATS keywords woven into the content\n'
    '  "formatting_tips": [str]\n\n'
    "Rules:\n"
    "- Never invent experience or skills the candidate does not have.\n"
    "- Reword bullet points to incorporate job-description keywords naturally.\n"
    "- Quantify achievements wherever possible.\n"
    "- Prioritise the most relevant experience."
)

BACKGROUND_STATEMENT_SYSTEM = (
    "You are a career storytelling expert.  Write a concise 'Why I'm a fit' "
    "statement (150-250 words) that:\n"
    "1. Opens with the candidate's unique value proposition.\n"
    "2. Connects their background directly to the role's requirements.\n"
    "3. Demonstrates cultural alignment with the company.\n"
    "4. Ends with a forward-looking statement about contributions.\n"
    "Use a confident, authentic voice.  Do not fabricate details."
)

OPEN_QUESTIONS_SYSTEM = (
    "You are an application-response specialist.  Answer the open-ended "
    "questions below using the candidate's profile and the job description.  "
    "Return a JSON array of objects:\n\n"
    '  [{"question": str, "answer": str, "word_count": int}]\n\n'
    "Guidelines:\n"
    "- Use the STAR method where appropriate (Situation, Task, Action, Result).\n"
    "- Be specific – reference real projects, metrics, and outcomes from the "
    "profile.\n"
    "- Stay within any stated word limits.\n"
    "- Maintain a professional yet personable tone."
)

STYLE_CLONE_SYSTEM = (
    "You are a writing-style analyst.  Examine the sample text and extract the "
    "author's writing style characteristics.  Return a JSON object:\n\n"
    '  "tone": str\n  "formality": str (formal/semi-formal/casual)\n'
    '  "sentence_structure": str\n  "vocabulary_level": str\n'
    '  "rhetorical_devices": [str]\n  "paragraph_length": str\n'
    '  "voice": str (active/passive/mixed)\n'
    '  "personality_traits": [str]\n'
    '  "style_prompt": str – a prompt that would instruct an LLM to replicate '
    "this exact writing style"
)

PROFESSIONAL_SUMMARY_SYSTEM = (
    "You are a resume-writing expert.  Create a professional summary (3-5 "
    "sentences) for the candidate targeting the specified role.  The summary "
    "should:\n"
    "1. Lead with years of experience and primary expertise.\n"
    "2. Highlight 2-3 signature achievements with metrics.\n"
    "3. Mention key technical skills relevant to the target role.\n"
    "4. End with a statement about what the candidate brings to the role.\n"
    "Be concise, impactful, and ATS-friendly."
)


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------


class WriterAgent(BaseAgent):
    """Generates tailored application content – cover letters, resume rewrites,
    background statements, and open-question answers."""

    name: str = "WriterAgent"
    description: str = "Content generation for job applications"

    def __init__(self, config: Optional[AgentConfig] = None) -> None:
        super().__init__(config)
        self._cached_style: Optional[str] = None

    # -- Public API -----------------------------------------------------------

    @agent_error_handler
    async def execute(
        self,
        profile: dict[str, Any],
        job: dict[str, Any],
        style: str = "professional",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Full pipeline: cover letter + tailored resume + summary."""
        cover_letter = await self.generate_cover_letter(profile, job, style)
        tailored = await self.tailor_resume(profile, job)
        summary = await self.generate_summary(
            profile, job.get("title", "the role")
        )
        background = await self.generate_background_statement(profile, job)

        return {
            "cover_letter": cover_letter,
            "tailored_resume": tailored,
            "professional_summary": summary,
            "background_statement": background,
        }

    @agent_error_handler
    async def generate_cover_letter(
        self,
        profile: dict[str, Any],
        job: dict[str, Any],
        style: str = "professional",
    ) -> str:
        """Generate a personalised cover letter.

        Parameters
        ----------
        profile:
            Candidate profile dict.
        job:
            Job listing dict (title, company, description, requirements).
        style:
            Writing style – ``professional``, ``conversational``, or ``bold``.

        Returns
        -------
        str
            The cover letter text.
        """
        style_instruction = ""
        if self._cached_style:
            style_instruction = (
                f"\n\nIMPORTANT – replicate this writing style:\n{self._cached_style}"
            )

        prompt = (
            f"Write a {style} cover letter for the following candidate and job.\n\n"
            f"CANDIDATE PROFILE:\n{json.dumps(profile, default=str)[:3000]}\n\n"
            f"JOB LISTING:\n{json.dumps(job, default=str)[:3000]}"
            f"{style_instruction}"
        )

        return await self.call_llm(
            prompt=prompt,
            system_prompt=COVER_LETTER_SYSTEM,
            temperature=0.7,
        )

    @agent_error_handler
    async def tailor_resume(
        self, profile: dict[str, Any], job: dict[str, Any]
    ) -> dict[str, Any]:
        """Adjust resume content for a specific job, optimising for ATS
        keyword matching.

        Returns
        -------
        dict
            Rewritten summary, experience bullets, highlighted skills, and
            keyword additions.
        """
        prompt = (
            "Tailor the candidate's resume for this specific job.\n\n"
            f"CANDIDATE PROFILE:\n{json.dumps(profile, default=str)[:4000]}\n\n"
            f"TARGET JOB:\n{json.dumps(job, default=str)[:3000]}"
        )

        response = await self.call_llm(
            prompt=prompt,
            system_prompt=TAILOR_RESUME_SYSTEM,
            response_format={"type": "json_object"},
        )
        return json.loads(response)

    @agent_error_handler
    async def generate_background_statement(
        self, profile: dict[str, Any], job: dict[str, Any]
    ) -> str:
        """Generate a 'Why I'm a fit' statement connecting the candidate to
        the role."""
        prompt = (
            "Write a background statement for this candidate applying to this role.\n\n"
            f"CANDIDATE PROFILE:\n{json.dumps(profile, default=str)[:3000]}\n\n"
            f"JOB LISTING:\n{json.dumps(job, default=str)[:3000]}"
        )

        return await self.call_llm(
            prompt=prompt,
            system_prompt=BACKGROUND_STATEMENT_SYSTEM,
            temperature=0.6,
        )

    @agent_error_handler
    async def answer_open_questions(
        self,
        questions: list[str],
        profile: dict[str, Any],
        job: dict[str, Any],
    ) -> list[dict[str, str]]:
        """Answer open-ended application questions using the candidate's
        profile.

        Parameters
        ----------
        questions:
            List of question strings from the application form.
        profile:
            Candidate profile dict.
        job:
            Job listing dict.

        Returns
        -------
        list[dict]
            Each element has ``question``, ``answer``, and ``word_count`` keys.
        """
        questions_text = "\n".join(
            f"{i + 1}. {q}" for i, q in enumerate(questions)
        )

        prompt = (
            "Answer these application questions for the candidate.\n\n"
            f"QUESTIONS:\n{questions_text}\n\n"
            f"CANDIDATE PROFILE:\n{json.dumps(profile, default=str)[:3000]}\n\n"
            f"JOB LISTING:\n{json.dumps(job, default=str)[:2000]}"
        )

        response = await self.call_llm(
            prompt=prompt,
            system_prompt=OPEN_QUESTIONS_SYSTEM,
            response_format={"type": "json_object"},
            temperature=0.5,
        )

        parsed = json.loads(response)
        # Handle case where LLM wraps array in an object
        if isinstance(parsed, dict):
            parsed = parsed.get("answers", parsed.get("questions", []))
        return parsed

    @agent_error_handler
    async def clone_writing_style(self, sample_text: str) -> str:
        """Extract and store the user's writing style from a sample.

        The extracted style profile is cached and automatically applied to
        subsequent content generation calls.

        Returns
        -------
        str
            A style prompt that can reproduce the writing style.
        """
        response = await self.call_llm(
            prompt=f"Analyze the writing style of this text:\n\n{sample_text[:4000]}",
            system_prompt=STYLE_CLONE_SYSTEM,
            response_format={"type": "json_object"},
        )
        style_data = json.loads(response)
        self._cached_style = style_data.get(
            "style_prompt", json.dumps(style_data)
        )
        self.logger.info("Writing style cached for future content generation")
        return self._cached_style

    @agent_error_handler
    async def generate_summary(
        self, profile: dict[str, Any], target_role: str
    ) -> str:
        """Generate a professional summary targeting a specific role.

        Parameters
        ----------
        profile:
            Candidate profile dict.
        target_role:
            The role title the candidate is targeting.

        Returns
        -------
        str
            A 3-5 sentence professional summary.
        """
        prompt = (
            f"Create a professional summary for this candidate targeting the "
            f"role of '{target_role}'.\n\n"
            f"CANDIDATE PROFILE:\n{json.dumps(profile, default=str)[:4000]}"
        )

        return await self.call_llm(
            prompt=prompt,
            system_prompt=PROFESSIONAL_SUMMARY_SYSTEM,
            temperature=0.5,
        )
