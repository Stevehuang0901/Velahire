"""
Base agent module for VelaHire multi-agent system.

Provides the abstract base class that all specialized agents inherit from,
including LLM client initialization, structured logging, and error handling.
"""

from __future__ import annotations

import asyncio
import logging
import time
from abc import ABC, abstractmethod
from enum import Enum
from functools import wraps
from typing import Any, Optional

from pydantic import BaseModel

# ---------------------------------------------------------------------------
# LLM provider enum
# ---------------------------------------------------------------------------


class ModelProvider(str, Enum):
    """Supported LLM providers."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"


# ---------------------------------------------------------------------------
# Configuration model
# ---------------------------------------------------------------------------


class AgentConfig(BaseModel):
    """Runtime configuration for an agent."""

    model_provider: ModelProvider = ModelProvider.OPENAI
    openai_api_key: Optional[str] = None
    anthropic_api_key: Optional[str] = None
    openai_model: str = "gpt-4o"
    anthropic_model: str = "claude-sonnet-4-20250514"
    temperature: float = 0.3
    max_tokens: int = 4096
    max_retries: int = 3
    retry_delay: float = 1.0
    timeout: float = 120.0


# ---------------------------------------------------------------------------
# Error wrapper decorator
# ---------------------------------------------------------------------------


def agent_error_handler(func):
    """Decorator that provides standardised error handling and logging for
    async agent methods.  Catches exceptions, logs them with context, and
    re-raises as ``AgentExecutionError`` so callers receive a consistent
    exception type.
    """

    @wraps(func)
    async def wrapper(self: "BaseAgent", *args: Any, **kwargs: Any) -> Any:
        method_name = func.__name__
        self.logger.info(
            "Agent %s: starting %s", self.name, method_name
        )
        start = time.monotonic()

        try:
            result = await func(self, *args, **kwargs)
            elapsed = time.monotonic() - start
            self.logger.info(
                "Agent %s: %s completed in %.2fs",
                self.name,
                method_name,
                elapsed,
            )
            return result

        except AgentExecutionError:
            raise  # Already wrapped – propagate as-is

        except Exception as exc:
            elapsed = time.monotonic() - start
            self.logger.error(
                "Agent %s: %s failed after %.2fs – %s: %s",
                self.name,
                method_name,
                elapsed,
                type(exc).__name__,
                exc,
                exc_info=True,
            )
            raise AgentExecutionError(
                agent=self.name,
                method=method_name,
                original_error=exc,
            ) from exc

    return wrapper


# ---------------------------------------------------------------------------
# Custom exception
# ---------------------------------------------------------------------------


class AgentExecutionError(Exception):
    """Raised when an agent method fails after exhausting retries."""

    def __init__(
        self,
        agent: str,
        method: str,
        original_error: Optional[Exception] = None,
        message: Optional[str] = None,
    ) -> None:
        self.agent = agent
        self.method = method
        self.original_error = original_error
        msg = message or (
            f"Agent '{agent}' failed in '{method}': {original_error}"
        )
        super().__init__(msg)


# ---------------------------------------------------------------------------
# Base agent
# ---------------------------------------------------------------------------


class BaseAgent(ABC):
    """Abstract base class for all VelaHire agents.

    Sub-classes *must* implement :meth:`execute`.  The base class provides:

    * Lazy LLM client initialization for OpenAI **and** Anthropic.
    * Structured Python logging scoped to the agent name.
    * A retry helper for LLM calls.
    """

    name: str = "BaseAgent"
    description: str = ""

    def __init__(self, config: Optional[AgentConfig] = None) -> None:
        self.config = config or AgentConfig()
        self.logger = logging.getLogger(f"velahire.agents.{self.name}")
        self._openai_client: Any = None
        self._anthropic_client: Any = None

    # ---- LLM clients (lazy) ------------------------------------------------

    @property
    def openai_client(self) -> Any:
        """Return a cached OpenAI async client, creating it on first access."""
        if self._openai_client is None:
            try:
                from openai import AsyncOpenAI
            except ImportError as exc:
                raise ImportError(
                    "openai package is required – pip install openai"
                ) from exc

            self._openai_client = AsyncOpenAI(
                api_key=self.config.openai_api_key,
                timeout=self.config.timeout,
                max_retries=self.config.max_retries,
            )
        return self._openai_client

    @property
    def anthropic_client(self) -> Any:
        """Return a cached Anthropic async client, creating it on first access."""
        if self._anthropic_client is None:
            try:
                from anthropic import AsyncAnthropic
            except ImportError as exc:
                raise ImportError(
                    "anthropic package is required – pip install anthropic"
                ) from exc

            self._anthropic_client = AsyncAnthropic(
                api_key=self.config.anthropic_api_key,
                timeout=self.config.timeout,
                max_retries=self.config.max_retries,
            )
        return self._anthropic_client

    # ---- LLM call helpers ---------------------------------------------------

    async def call_llm(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        response_format: Optional[dict[str, Any]] = None,
    ) -> str:
        """Unified LLM call that dispatches to the configured provider.

        Parameters
        ----------
        prompt:
            The user / main prompt.
        system_prompt:
            Optional system-level instructions.
        temperature:
            Sampling temperature override.
        max_tokens:
            Max tokens override.
        response_format:
            OpenAI-specific response format (e.g. ``{"type": "json_object"}``).

        Returns
        -------
        str
            The text content of the model response.
        """
        temp = temperature if temperature is not None else self.config.temperature
        tokens = max_tokens or self.config.max_tokens

        if self.config.model_provider == ModelProvider.OPENAI:
            return await self._call_openai(
                prompt, system_prompt, temp, tokens, response_format
            )
        return await self._call_anthropic(prompt, system_prompt, temp, tokens)

    async def _call_openai(
        self,
        prompt: str,
        system_prompt: Optional[str],
        temperature: float,
        max_tokens: int,
        response_format: Optional[dict[str, Any]],
    ) -> str:
        messages: list[dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        kwargs: dict[str, Any] = {
            "model": self.config.openai_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if response_format:
            kwargs["response_format"] = response_format

        response = await self.openai_client.chat.completions.create(**kwargs)
        return response.choices[0].message.content

    async def _call_anthropic(
        self,
        prompt: str,
        system_prompt: Optional[str],
        temperature: float,
        max_tokens: int,
    ) -> str:
        kwargs: dict[str, Any] = {
            "model": self.config.anthropic_model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if system_prompt:
            kwargs["system"] = system_prompt

        response = await self.anthropic_client.messages.create(**kwargs)
        return response.content[0].text

    # ---- Retry helper -------------------------------------------------------

    async def retry_with_backoff(
        self,
        coro_func,
        *args: Any,
        max_retries: Optional[int] = None,
        retry_delay: Optional[float] = None,
        **kwargs: Any,
    ) -> Any:
        """Execute an async callable with exponential back-off on failure.

        Parameters
        ----------
        coro_func:
            An async callable to invoke.
        max_retries:
            Override for ``config.max_retries``.
        retry_delay:
            Override for ``config.retry_delay``.
        """
        retries = max_retries or self.config.max_retries
        delay = retry_delay or self.config.retry_delay

        last_exc: Optional[Exception] = None
        for attempt in range(1, retries + 1):
            try:
                return await coro_func(*args, **kwargs)
            except Exception as exc:
                last_exc = exc
                if attempt < retries:
                    sleep_time = delay * (2 ** (attempt - 1))
                    self.logger.warning(
                        "Agent %s: attempt %d/%d failed (%s), retrying in %.1fs",
                        self.name,
                        attempt,
                        retries,
                        exc,
                        sleep_time,
                    )
                    await asyncio.sleep(sleep_time)

        raise AgentExecutionError(
            agent=self.name,
            method=coro_func.__name__,
            original_error=last_exc,
            message=(
                f"Agent '{self.name}' exhausted {retries} retries for "
                f"'{coro_func.__name__}': {last_exc}"
            ),
        )

    # ---- Abstract interface -------------------------------------------------

    @abstractmethod
    async def execute(self, *args: Any, **kwargs: Any) -> Any:
        """Run the agent's primary workflow.  Must be implemented by sub-classes."""
        ...

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} name={self.name!r}>"
