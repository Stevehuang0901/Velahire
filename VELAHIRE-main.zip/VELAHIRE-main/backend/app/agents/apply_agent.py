"""
Apply Agent – Automated job application form filling and submission.

Uses Playwright for browser automation with anti-detection measures
to submit job applications across various ATS platforms. Includes
LLM-powered semantic form field detection, OTP handling, and document uploads.
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
from typing import Any, Optional

from .base import AgentConfig, BaseAgent, agent_error_handler

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

FIELD_DETECTION_SYSTEM = (
    "You are a form-field detection engine for job application pages. "
    "Given a list of HTML form elements with their attributes, determine the "
    "semantic meaning of each field. Return a JSON object with a 'fields' key "
    "containing an array of objects:\n\n"
    '  {"fields": [{"selector": str, "semantic_type": str, "label": str, '
    '    "required": bool, "field_type": str, "options": [str] or null}]}\n\n'
    "Semantic types include: first_name, last_name, full_name, email, phone, "
    "address, city, state, zip, country, linkedin, portfolio, github, website, "
    "resume_upload, cover_letter_upload, cover_letter_text, salary_expectation, "
    "start_date, work_authorization, visa_sponsorship, years_experience, "
    "education_level, degree, institution, graduation_date, company_name, "
    "job_title, employment_dates, custom_question, consent_checkbox, "
    "gender, ethnicity, veteran_status, disability_status, referral_source, "
    "unknown.\n\n"
    "Be precise — correctly identifying field purpose is critical for "
    "accurate form filling."
)

FIELD_MAPPING_SYSTEM = (
    "You are a data-mapping engine. Given a set of detected form fields and "
    "candidate application data, determine the best value to fill into each "
    "field. Return a JSON object mapping field selectors to their values:\n\n"
    '  {"selector1": "value1", "selector2": "value2", ...}\n\n'
    "Rules:\n"
    "- Only use data from the candidate profile; never fabricate.\n"
    "- For dropdown/select fields, choose the closest matching option.\n"
    "- For checkboxes, return 'true' or 'false'.\n"
    "- For date fields, use the format shown in the placeholder.\n"
    "- Leave fields empty (empty string) if no suitable data exists.\n"
    "- For salary expectation, provide a reasonable range based on the role."
)


class ApplyAgent(BaseAgent):
    """Automates job application form filling and submission using
    Playwright browser automation with anti-detection measures."""

    name: str = "ApplyAgent"
    description: str = "Automated form filling, document upload, and application submission"

    def __init__(self, config: Optional[AgentConfig] = None) -> None:
        super().__init__(config)

    @agent_error_handler
    async def execute(
        self,
        match_data: dict[str, Any] | None = None,
        content: dict[str, Any] | None = None,
        credentials: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Full application pipeline: navigate, detect, fill, submit."""
        return await self.execute_application(
            match_data or kwargs.get("match_data", {}),
            content or kwargs.get("content", {}),
            credentials or kwargs.get("credentials", {}),
        )

    @agent_error_handler
    async def execute_application(
        self,
        match_data: dict[str, Any],
        content: dict[str, Any],
        credentials: dict[str, str],
    ) -> dict[str, Any]:
        """Execute the complete application process for a single job.

        Steps:
        1. Launch stealth browser with anti-detection
        2. Navigate to the application URL
        3. Detect the ATS platform
        4. Use the appropriate adapter or generic field detection
        5. Fill the form with candidate data
        6. Upload documents (resume, cover letter)
        7. Handle OTP if required
        8. Submit and capture confirmation

        Args:
            match_data: Dict with job info, profile, and application URL.
            content: Generated content (cover letter, tailored resume, etc.).
            credentials: Platform credentials for login-required forms.

        Returns:
            Dict with application status, confirmation ID, and any errors.
        """
        from app.utils.anti_detection import generate_browser_fingerprint, random_delay

        application_url = match_data.get("application_url", "")
        job = match_data.get("job", {})
        if not application_url:
            application_url = job.get("url", "")

        result: dict[str, Any] = {
            "success": False,
            "application_url": application_url,
            "platform": "unknown",
            "job_title": job.get("title", ""),
            "company": job.get("company", ""),
            "confirmation_id": None,
            "error": None,
            "documents_uploaded": False,
            "form_filled": False,
        }

        if not application_url:
            result["error"] = "No application URL provided"
            return result

        try:
            from playwright.async_api import async_playwright

            fingerprint = generate_browser_fingerprint()

            async with async_playwright() as pw:
                browser = await pw.chromium.launch(
                    headless=True,
                    args=[
                        "--disable-blink-features=AutomationControlled",
                        "--disable-dev-shm-usage",
                        "--no-sandbox",
                        f"--window-size={fingerprint['screenWidth']},{fingerprint['screenHeight']}",
                    ],
                )

                context = await browser.new_context(
                    user_agent=fingerprint["userAgent"],
                    viewport={
                        "width": fingerprint["screenWidth"],
                        "height": fingerprint["screenHeight"],
                    },
                    locale="en-US",
                    timezone_id=fingerprint["timezone"],
                )

                # Inject anti-detection scripts
                await context.add_init_script("""
                    Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                    Object.defineProperty(navigator, 'plugins', {
                        get: () => [1, 2, 3, 4, 5]
                    });
                    Object.defineProperty(navigator, 'languages', {
                        get: () => ['en-US', 'en']
                    });
                    window.chrome = {runtime: {}};
                """)

                page = await context.new_page()

                await random_delay(1.0, 3.0)
                await page.goto(application_url, wait_until="networkidle", timeout=60000)
                await random_delay(2.0, 4.0)

                platform = self._detect_platform(application_url, await page.content())
                result["platform"] = platform

                adapter = self._get_adapter(platform)

                if adapter:
                    from app.adapters.base import ApplicationData

                    app_data = self._build_application_data(match_data, content)
                    if credentials:
                        await adapter.login(credentials)
                    filled = await adapter.fill_application(page, app_data)
                    result["form_filled"] = filled
                    if not filled:
                        result["error"] = "Failed to fill application form"
                        return result
                    submit_result = await adapter.submit(page)
                    result.update(submit_result)
                    result["documents_uploaded"] = True
                else:
                    fields = await self.detect_form_fields(page)
                    if not fields:
                        result["error"] = "No form fields detected on page"
                        return result

                    data = self._merge_application_data(match_data, content)
                    filled = await self.fill_form(page, fields, data)
                    result["form_filled"] = filled
                    if not filled:
                        result["error"] = "Failed to fill form fields"
                        return result

                    documents: dict[str, str] = {}
                    if content.get("tailored_resume_path"):
                        documents["resume"] = content["tailored_resume_path"]
                    if content.get("cover_letter_path"):
                        documents["cover_letter"] = content["cover_letter_path"]
                    if documents:
                        result["documents_uploaded"] = await self.upload_documents(page, documents)

                    submit_btn = await page.query_selector(
                        "button[type='submit'], input[type='submit'], "
                        "button:has-text('Submit'), button:has-text('Apply')"
                    )
                    if submit_btn:
                        await random_delay(1.0, 2.5)
                        await submit_btn.click()
                        try:
                            await page.wait_for_load_state("networkidle", timeout=30000)
                        except Exception:
                            await page.wait_for_load_state("domcontentloaded", timeout=15000)
                        result["success"] = True
                    else:
                        result["error"] = "Submit button not found"

                await browser.close()

        except ImportError:
            result["error"] = (
                "playwright is not installed. "
                "Install with: pip install playwright && playwright install"
            )
        except Exception as exc:
            logger.error("Application execution failed: %s", exc, exc_info=True)
            result["error"] = str(exc)

        return result

    @agent_error_handler
    async def detect_form_fields(self, page: Any) -> list[dict]:
        """Detect and semantically classify form fields on the current page.

        Extracts all visible form elements from the DOM, sends their
        attributes to the LLM for semantic classification, and returns
        a structured list of detected fields.

        Args:
            page: Playwright page object.

        Returns:
            List of dicts with field info (selector, semantic_type, label, etc.).
        """
        elements_js = """() => {
            const fields = [];
            const inputs = document.querySelectorAll(
                'input:not([type="hidden"]):not([type="submit"]):not([type="button"]), '
                + 'select, textarea, input[type="file"]'
            );
            inputs.forEach((el, idx) => {
                const id = el.id || '';
                const name = el.name || '';
                const type = el.type || el.tagName.toLowerCase();
                const placeholder = el.placeholder || '';
                const required = el.required || false;
                const ariaLabel = el.getAttribute('aria-label') || '';
                const autocomplete = el.getAttribute('autocomplete') || '';
                let label = '';
                if (id) {
                    const labelEl = document.querySelector('label[for="' + id + '"]');
                    if (labelEl) label = labelEl.innerText.trim();
                }
                if (!label) {
                    const parent = el.closest('div, fieldset, section');
                    if (parent) {
                        const labelEl = parent.querySelector('label');
                        if (labelEl) label = labelEl.innerText.trim();
                    }
                }
                let options = null;
                if (el.tagName === 'SELECT') {
                    options = Array.from(el.options).map(o => o.text.trim()).filter(Boolean);
                }
                const selector = id ? '#' + id : name ? '[name="' + name + '"]' : '[data-field-idx="' + idx + '"]';
                fields.push({selector, id, name, type, placeholder, required, label, ariaLabel, autocomplete, options});
            });
            return fields;
        }"""

        raw_fields = await page.evaluate(elements_js)
        if not raw_fields:
            return []

        prompt = (
            "Classify each form field by its semantic purpose:\n\n"
            f"{json.dumps(raw_fields, indent=2)}\n\n"
            "Return a JSON object with a 'fields' key."
        )

        response = await self.call_llm(
            prompt=prompt,
            system_prompt=FIELD_DETECTION_SYSTEM,
            response_format={"type": "json_object"},
        )
        parsed = json.loads(response)
        if isinstance(parsed, dict):
            parsed = parsed.get("fields", parsed.get("result", []))
        return parsed if isinstance(parsed, list) else []

    @agent_error_handler
    async def fill_form(self, page: Any, fields: list[dict], data: dict) -> bool:
        """Fill form fields using LLM-guided data mapping.

        Args:
            page: Playwright page object.
            fields: Detected form fields from detect_form_fields().
            data: Candidate application data dict.

        Returns:
            True if at least some fields were filled successfully.
        """
        from app.utils.anti_detection import random_delay, simulate_human_typing

        prompt = (
            "Map candidate data to these form fields:\n\n"
            f"FIELDS:\n{json.dumps(fields, indent=2)}\n\n"
            f"CANDIDATE DATA:\n{json.dumps(data, indent=2)[:4000]}"
        )

        response = await self.call_llm(
            prompt=prompt,
            system_prompt=FIELD_MAPPING_SYSTEM,
            response_format={"type": "json_object"},
        )
        mapping = json.loads(response)
        filled_count = 0

        for selector, value in mapping.items():
            if not value or value == "":
                continue
            try:
                element = await page.query_selector(selector)
                if not element:
                    continue
                tag_name = await element.evaluate("el => el.tagName.toLowerCase()")
                input_type = await element.evaluate("el => el.type ? el.type.toLowerCase() : ''")

                if tag_name == "select":
                    await page.select_option(selector, label=str(value))
                elif input_type == "checkbox":
                    is_checked = await element.is_checked()
                    should_check = str(value).lower() in ("true", "yes", "1")
                    if should_check and not is_checked:
                        await element.check()
                    elif not should_check and is_checked:
                        await element.uncheck()
                elif input_type == "radio":
                    await element.click()
                elif input_type == "file":
                    await element.set_input_files(str(value))
                else:
                    await element.click()
                    await element.fill("")
                    await simulate_human_typing(page, selector, str(value))
                filled_count += 1
                await random_delay(0.2, 0.8)
            except Exception as exc:
                logger.warning("Failed to fill field %s: %s", selector, exc)

        self.logger.info("Filled %d/%d form fields", filled_count, len(mapping))
        return filled_count > 0

    @agent_error_handler
    async def handle_otp(self, email_service: Any, timeout: int = 120) -> str:
        """Wait for and extract an OTP code from an incoming email.

        Polls the email service for new messages containing OTP codes,
        using regex and LLM fallback to extract the code.

        Args:
            email_service: Email client with async get_recent_messages() method.
            timeout: Maximum seconds to wait for the OTP email.

        Returns:
            The extracted OTP code string.

        Raises:
            TimeoutError: If no OTP email arrives within the timeout.
        """
        import re

        start = asyncio.get_event_loop().time()
        poll_interval = 5

        while (asyncio.get_event_loop().time() - start) < timeout:
            messages = await email_service.get_recent_messages(limit=5)
            for msg in messages:
                subject = msg.get("subject", "").lower()
                body = msg.get("body", "")
                otp_keywords = ["verification", "verify", "code", "otp", "one-time", "confirm", "security code"]
                if not any(kw in subject for kw in otp_keywords):
                    continue

                patterns = [r"code[:\s]+(\d{4,8})", r"OTP[:\s]+(\d{4,8})", r"\b(\d{6})\b"]
                for pattern in patterns:
                    match = re.search(pattern, body, re.IGNORECASE)
                    if match:
                        return match.group(1)

                response = await self.call_llm(
                    prompt=f"Extract the OTP/verification code. Return ONLY the code.\n\nSubject: {subject}\nBody: {body[:2000]}",
                    temperature=0.0, max_tokens=20,
                )
                code = response.strip()
                if code and code.isdigit():
                    return code

            await asyncio.sleep(poll_interval)

        raise TimeoutError(f"No OTP email received within {timeout} seconds")

    @agent_error_handler
    async def upload_documents(self, page: Any, documents: dict[str, str]) -> bool:
        """Upload documents (resume, cover letter) to file input fields.

        Args:
            page: Playwright page object.
            documents: Dict mapping document type to file path.

        Returns:
            True if at least one document was uploaded.
        """
        from app.utils.anti_detection import random_delay

        file_inputs = await page.query_selector_all("input[type='file']")
        uploaded = 0

        for file_input in file_inputs:
            field_id = await file_input.get_attribute("id") or ""
            field_name = await file_input.get_attribute("name") or ""
            aria_label = await file_input.get_attribute("aria-label") or ""
            label_text = ""
            if field_id:
                label_el = await page.query_selector(f"label[for='{field_id}']")
                if label_el:
                    label_text = (await label_el.inner_text()).strip().lower()

            context_text = f"{field_id} {field_name} {label_text} {aria_label}".lower()

            doc_path: str | None = None
            if any(kw in context_text for kw in ("resume", "cv", "curriculum")):
                doc_path = documents.get("resume")
            elif any(kw in context_text for kw in ("cover", "letter", "motivation")):
                doc_path = documents.get("cover_letter")
            elif uploaded == 0 and "resume" in documents:
                doc_path = documents.get("resume")

            if doc_path:
                try:
                    await file_input.set_input_files(doc_path)
                    uploaded += 1
                    await random_delay(1.0, 3.0)
                except Exception as exc:
                    self.logger.warning("Failed to upload to %s: %s", context_text.strip(), exc)

        return uploaded > 0

    # -- Internal helpers -----------------------------------------------------

    @staticmethod
    def _detect_platform(url: str, page_content: str = "") -> str:
        """Detect the ATS platform from the URL or page content."""
        url_lower = url.lower()
        platform_patterns = {
            "workday": ["myworkday.com", "workday"],
            "greenhouse": ["greenhouse.io", "boards.greenhouse"],
            "lever": ["lever.co", "jobs.lever"],
            "icims": ["icims"],
            "smart_recruiters": ["smartrecruiters"],
            "taleo": ["taleo"],
            "successfactors": ["successfactors"],
        }
        for platform, patterns in platform_patterns.items():
            if any(p in url_lower for p in patterns):
                return platform
        content_lower = page_content.lower()[:5000]
        for platform, patterns in platform_patterns.items():
            if any(p in content_lower for p in patterns):
                return platform
        return "generic"

    @staticmethod
    def _get_adapter(platform: str) -> Any:
        """Get the platform-specific adapter, or None for generic."""
        try:
            if platform == "workday":
                from app.adapters.workday import WorkdayAdapter
                return WorkdayAdapter()
            elif platform == "greenhouse":
                from app.adapters.greenhouse import GreenhouseAdapter
                return GreenhouseAdapter()
            elif platform == "lever":
                from app.adapters.lever import LeverAdapter
                return LeverAdapter()
        except ImportError:
            pass
        return None

    @staticmethod
    def _build_application_data(match_data: dict[str, Any], content: dict[str, Any]) -> Any:
        """Build an ApplicationData object from match data and content."""
        from app.adapters.base import ApplicationData

        profile = match_data.get("profile", {})
        contact = profile.get("contact", {})
        name_parts = contact.get("full_name", "").split(" ", 1)

        return ApplicationData(
            full_name=contact.get("full_name", ""),
            first_name=name_parts[0] if name_parts else "",
            last_name=name_parts[1] if len(name_parts) > 1 else "",
            email=contact.get("email", ""),
            phone=contact.get("phone", ""),
            resume_path=content.get("tailored_resume_path", ""),
            cover_letter=content.get("cover_letter", ""),
            linkedin_url=contact.get("linkedin", ""),
            portfolio_url=contact.get("portfolio", ""),
            work_authorization=match_data.get("work_authorization", ""),
            salary_expectation=match_data.get("salary_expectation", ""),
            start_date=match_data.get("start_date", ""),
            custom_answers=content.get("open_question_answers", {}),
        )

    @staticmethod
    def _merge_application_data(match_data: dict[str, Any], content: dict[str, Any]) -> dict[str, Any]:
        """Merge match data and content into a flat dict for form filling."""
        profile = match_data.get("profile", {})
        contact = profile.get("contact", {})
        job = match_data.get("job", {})
        name_parts = contact.get("full_name", "").split(" ", 1)
        return {
            "full_name": contact.get("full_name", ""),
            "first_name": name_parts[0] if name_parts else "",
            "last_name": name_parts[1] if len(name_parts) > 1 else "",
            "email": contact.get("email", ""),
            "phone": contact.get("phone", ""),
            "linkedin": contact.get("linkedin", ""),
            "portfolio": contact.get("portfolio", ""),
            "github": contact.get("github", ""),
            "location": contact.get("location", ""),
            "summary": profile.get("summary", ""),
            "skills": profile.get("skills", {}),
            "experience": profile.get("experience", []),
            "education": profile.get("education", []),
            "cover_letter": content.get("cover_letter", ""),
            "work_authorization": match_data.get("work_authorization", ""),
            "salary_expectation": match_data.get("salary_expectation", ""),
            "start_date": match_data.get("start_date", ""),
            "open_question_answers": content.get("open_question_answers", {}),
            "job_title": job.get("title", ""),
            "company": job.get("company", ""),
        }
