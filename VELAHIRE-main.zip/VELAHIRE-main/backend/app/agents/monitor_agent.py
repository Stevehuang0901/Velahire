"""
Monitor Agent – Application status tracking and email monitoring.

Monitors user inboxes for application-related emails, classifies them,
updates application statuses, generates weekly reports, and suggests
follow-up actions.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from .base import AgentConfig, BaseAgent, agent_error_handler

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

EMAIL_CLASSIFY_SYSTEM = (
    "You are an email classification engine for job applications. "
    "Classify the email and extract key information. Return a JSON object:\n\n"
    '  "classification": str – one of: interview_invite, rejection, offer, '
    "follow_up, assessment, reference_check, background_check, onboarding, "
    "otp, acknowledgement, general, spam\n"
    '  "confidence": float (0-1)\n'
    '  "company": str or null\n'
    '  "role": str or null\n'
    '  "action_required": bool\n'
    '  "action_description": str or null\n'
    '  "deadline": str (ISO date) or null\n'
    '  "sentiment": str (positive/neutral/negative)\n'
    '  "key_details": [str] – important points from the email\n'
    '  "suggested_response": str or null – brief response suggestion\n\n'
    "Be thorough — even subtle cues like 'we appreciate your interest' "
    "can indicate a rejection."
)

WEEKLY_REPORT_SYSTEM = (
    "You are a career analytics assistant. Given a user's application "
    "activity data for the week, generate a comprehensive weekly report. "
    "Return a JSON object:\n\n"
    '  "summary": str – 2-3 sentence overview of the week\n'
    '  "statistics": {applications_sent, responses_received, interviews_scheduled, '
    "rejections, pending}\n"
    '  "highlights": [str] – notable achievements or developments\n'
    '  "concerns": [str] – areas needing attention\n'
    '  "recommendations": [str] – actionable suggestions for next week\n'
    '  "response_rate": float (percentage)\n'
    '  "average_response_time_days": float or null\n'
    '  "top_performing_skills": [str] – skills getting most traction\n'
    '  "suggested_adjustments": [str] – resume/approach tweaks\n'
)

FOLLOW_UP_SYSTEM = (
    "You are a professional follow-up advisor. Given an application's "
    "current status and timeline, suggest an appropriate follow-up action. "
    "Return a JSON object:\n\n"
    '  "should_follow_up": bool\n'
    '  "reason": str\n'
    '  "suggested_action": str – specific action to take\n'
    '  "follow_up_template": str – draft follow-up email text\n'
    '  "best_timing": str – when to send the follow-up\n'
    '  "tone": str – recommended tone for the follow-up\n'
    '  "do_not_follow_up_reasons": [str] or null\n'
)


class MonitorAgent(BaseAgent):
    """Monitors application statuses, classifies emails, generates reports,
    and suggests follow-up actions."""

    name: str = "MonitorAgent"
    description: str = "Status tracking, email monitoring, and report generation"

    def __init__(self, config: Optional[AgentConfig] = None) -> None:
        super().__init__(config)

    @agent_error_handler
    async def execute(
        self,
        user_id: str | None = None,
        task: str = "monitor",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run monitoring pipeline."""
        user_id = user_id or kwargs.get("user_id", "")
        if task == "monitor":
            emails = await self.monitor_inbox(user_id)
            return {"emails_processed": len(emails), "classified_emails": emails}
        elif task == "report":
            return await self.generate_weekly_report(user_id)
        return {}

    @agent_error_handler
    async def monitor_inbox(self, user_id: str) -> list[dict]:
        """Monitor the user's inbox for application-related emails.

        In production this connects via OAuth to Gmail/Outlook, fetches
        recent unread messages, classifies them, and updates application
        statuses accordingly.

        Args:
            user_id: The user's UUID string.

        Returns:
            List of classified email dicts with status updates applied.
        """
        classified: list[dict[str, Any]] = []

        # Production implementation would:
        # 1. Retrieve user's OAuth tokens from the database
        # 2. Connect to Gmail/Outlook API
        # 3. Fetch unread messages from the last N hours
        # 4. Filter for application-related emails
        # 5. Classify each email using classify_email()
        # 6. Match to existing applications via company/role
        # 7. Update statuses via update_status()

        self.logger.info("Monitoring inbox for user %s", user_id)
        return classified

    @agent_error_handler
    async def classify_email(self, subject: str, body: str) -> dict:
        """Classify an email related to job applications.

        Uses the LLM to determine whether the email is an interview invite,
        rejection, offer, or other application-related communication.

        Args:
            subject: Email subject line.
            body: Email body text.

        Returns:
            Classification dict with type, confidence, action items, etc.
        """
        prompt = (
            f"Classify this job-application-related email:\n\n"
            f"Subject: {subject}\n\n"
            f"Body:\n{body[:3000]}"
        )

        response = await self.call_llm(
            prompt=prompt,
            system_prompt=EMAIL_CLASSIFY_SYSTEM,
            response_format={"type": "json_object"},
            temperature=0.2,
        )
        return json.loads(response)

    @agent_error_handler
    async def update_status(self, application_id: str, status: str) -> bool:
        """Update an application's status in the database.

        Args:
            application_id: UUID of the application record.
            status: New status string (must be a valid ApplicationStatus).

        Returns:
            True if the update succeeded, False otherwise.
        """
        from uuid import UUID

        from sqlalchemy import update

        from app.core.database import async_session_factory
        from app.models.application import Application, ApplicationStatus

        try:
            new_status = ApplicationStatus(status)
        except ValueError:
            self.logger.error("Invalid application status: %s", status)
            return False

        try:
            async with async_session_factory() as session:
                await session.execute(
                    update(Application)
                    .where(Application.id == UUID(application_id))
                    .values(status=new_status)
                )
                await session.commit()
            self.logger.info("Updated application %s to %s", application_id, status)
            return True
        except Exception as exc:
            self.logger.error("Failed to update application %s: %s", application_id, exc)
            return False

    @agent_error_handler
    async def generate_weekly_report(self, user_id: str) -> dict:
        """Generate a comprehensive weekly activity report.

        Aggregates application data from the past 7 days into an
        actionable report with statistics and recommendations.

        Args:
            user_id: The user's UUID string.

        Returns:
            Weekly report dict with statistics, highlights, and recommendations.
        """
        now = datetime.now(timezone.utc)
        week_ago = now - timedelta(days=7)

        stats: dict[str, Any] = {
            "user_id": user_id,
            "period": "weekly",
            "period_start": week_ago.isoformat(),
            "period_end": now.isoformat(),
            "applications_sent": 0,
            "responses_received": 0,
            "interviews_scheduled": 0,
            "rejections": 0,
            "offers": 0,
            "pending": 0,
        }

        try:
            from uuid import UUID

            from sqlalchemy import func, select

            from app.core.database import async_session_factory
            from app.models.application import Application, ApplicationStatus
            from app.models.match import Match

            async with async_session_factory() as session:
                result = await session.execute(
                    select(Application.status, func.count(Application.id))
                    .join(Match, Application.match_id == Match.id)
                    .where(Match.user_id == UUID(user_id), Application.created_at >= week_ago)
                    .group_by(Application.status)
                )
                for app_status, count in result:
                    if app_status == ApplicationStatus.SUBMITTED:
                        stats["applications_sent"] = count
                    elif app_status == ApplicationStatus.INTERVIEWING:
                        stats["interviews_scheduled"] = count
                    elif app_status == ApplicationStatus.REJECTED:
                        stats["rejections"] = count
                    elif app_status == ApplicationStatus.OFFER:
                        stats["offers"] = count
                    elif app_status in (ApplicationStatus.PENDING, ApplicationStatus.ACKNOWLEDGED):
                        stats["pending"] += count

                stats["responses_received"] = (
                    stats["interviews_scheduled"] + stats["rejections"] + stats["offers"]
                )
        except Exception as exc:
            self.logger.warning("Failed to fetch stats from DB: %s", exc)

        prompt = f"Generate a weekly job search report from this data:\n\n{json.dumps(stats, indent=2)}"

        response = await self.call_llm(
            prompt=prompt,
            system_prompt=WEEKLY_REPORT_SYSTEM,
            response_format={"type": "json_object"},
            temperature=0.5,
        )
        report = json.loads(response)
        report["raw_statistics"] = stats
        return report

    @agent_error_handler
    async def suggest_follow_up(self, application: dict) -> str:
        """Suggest a follow-up action for a specific application.

        Args:
            application: Application dict with status, applied_at, company,
                         job info, and interaction history.

        Returns:
            Follow-up suggestion string, or reason why no follow-up is needed.
        """
        prompt = (
            f"Suggest a follow-up action for this job application:\n\n"
            f"{json.dumps(application, indent=2, default=str)}"
        )

        response = await self.call_llm(
            prompt=prompt,
            system_prompt=FOLLOW_UP_SYSTEM,
            response_format={"type": "json_object"},
            temperature=0.4,
        )
        result = json.loads(response)

        if result.get("should_follow_up"):
            return result.get("follow_up_template", result.get("suggested_action", ""))
        return result.get("reason", "No follow-up recommended at this time.")
