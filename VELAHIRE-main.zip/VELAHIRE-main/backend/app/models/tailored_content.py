"""TailoredContent ORM model -- AI-generated materials for a specific match."""

import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class TailoredContent(Base):
    __tablename__ = "tailored_contents"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    match_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("matches.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )
    tailored_cv_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    cover_letter: Mapped[str | None] = mapped_column(Text, nullable=True)
    background_statement: Mapped[str | None] = mapped_column(Text, nullable=True)
    open_question_answers: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    style_tone: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False
    )

    # Relationships
    match = relationship("Match", back_populates="tailored_content")

    def __repr__(self) -> str:
        return f"<TailoredContent match={self.match_id}>"
