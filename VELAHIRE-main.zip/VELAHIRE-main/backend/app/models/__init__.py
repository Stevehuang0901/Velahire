"""Import all ORM models so Alembic and SQLAlchemy can discover them."""

from app.models.user import User
from app.models.resume import Resume
from app.models.profile import Profile
from app.models.job import Job
from app.models.match import Match
from app.models.tailored_content import TailoredContent
from app.models.application import Application
from app.models.email_tracking import EmailTracking

__all__ = [
    "User",
    "Resume",
    "Profile",
    "Job",
    "Match",
    "TailoredContent",
    "Application",
    "EmailTracking",
]
