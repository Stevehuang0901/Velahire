"""Redis-based rate limiting middleware."""
import time
import logging
from typing import Optional

from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

PLAN_LIMITS = {
    "free": {"daily": 10, "weekly": 50},
    "pro": {"daily": 100, "weekly": 500},
    "premium": {"daily": 1000, "weekly": 5000},
    "enterprise": {"daily": 10000, "weekly": 50000},
}


class RateLimiterMiddleware(BaseHTTPMiddleware):
    """Rate limiting middleware using Redis."""

    def __init__(self, app, redis_client=None):
        super().__init__(app)
        self.redis = redis_client

    async def dispatch(self, request: Request, call_next):
        if not self.redis:
            return await call_next(request)

        client_ip = request.client.host if request.client else "unknown"
        key = f"rate_limit:{client_ip}:{int(time.time()) // 60}"

        try:
            current = await self.redis.incr(key)
            if current == 1:
                await self.redis.expire(key, 60)
            if current > 100:
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
        except HTTPException:
            raise
        except Exception:
            pass

        return await call_next(request)


async def check_application_limit(
    user_id: str, plan: str, redis_client=None
) -> bool:
    """Check if user has exceeded their application limit."""
    if not redis_client:
        return True

    limits = PLAN_LIMITS.get(plan, PLAN_LIMITS["free"])
    daily_key = f"apply_limit:daily:{user_id}"

    try:
        count = await redis_client.get(daily_key)
        if count and int(count) >= limits["daily"]:
            return False
        return True
    except Exception:
        return True
