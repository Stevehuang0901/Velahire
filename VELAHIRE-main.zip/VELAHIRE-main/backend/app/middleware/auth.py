"""JWT authentication middleware and dependency injection helpers.

Provides middleware for request-level auth state injection and a
``get_current_user`` dependency function for route-level protection.
"""

from typing import Optional

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import Response

from app.core.config import settings
from app.core.security import verify_token

security = HTTPBearer(auto_error=False)


# ---------------------------------------------------------------------------
# Token extraction and verification
# ---------------------------------------------------------------------------


async def get_current_user_from_token(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> dict:
    """Extract and verify user identity from a JWT bearer token.

    This is a lightweight dependency that returns the raw JWT payload
    (not a full User ORM object). Use ``app.api.deps.get_current_user``
    for full user object resolution with DB lookup.

    Raises:
        HTTPException 401: If the token is missing, invalid, or expired.
    """
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        payload = verify_token(credentials.credentials)
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token missing subject claim",
        )

    return payload


# ---------------------------------------------------------------------------
# Plan-tier access control
# ---------------------------------------------------------------------------


def require_plan(allowed_plans: list[str]):
    """Decorator factory to restrict endpoint access by subscription plan.

    Usage::

        @router.get("/premium-feature")
        @require_plan(["pro", "premium", "enterprise"])
        async def premium_endpoint(current_user: User = Depends(get_current_user)):
            ...

    Raises:
        HTTPException 403: If the user's plan is not in the allowed list.
    """
    from functools import wraps

    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            current_user = kwargs.get("current_user")
            if current_user is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Authentication required",
                )
            user_plan = getattr(current_user, "plan", None)
            if user_plan is not None:
                plan_value = user_plan.value if hasattr(user_plan, "value") else str(user_plan)
                if plan_value not in allowed_plans:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail=(
                            f"This feature requires one of these plans: "
                            f"{', '.join(allowed_plans)}. "
                            f"Your current plan: {plan_value}"
                        ),
                    )
            return await func(*args, **kwargs)
        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# Auth state middleware
# ---------------------------------------------------------------------------


class AuthStateMiddleware(BaseHTTPMiddleware):
    """Middleware that extracts JWT claims from the Authorization header and
    attaches them to ``request.state`` for downstream use by rate limiters
    and logging.

    This middleware does **not** reject unauthenticated requests -- that
    responsibility belongs to the route-level ``get_current_user`` dependency.
    """

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        request.state.user_id = None
        request.state.user_plan = "free"

        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
            try:
                payload = verify_token(token)
                request.state.user_id = payload.get("sub")
                request.state.user_plan = payload.get("plan", "free")
            except (JWTError, Exception):
                pass  # Allow request through; auth enforced at route level

        response = await call_next(request)
        return response
