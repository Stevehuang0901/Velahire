"""Security utilities: JWT tokens, password hashing, AES-256 encryption."""

from datetime import datetime, timedelta, timezone
from typing import Optional

from cryptography.fernet import Fernet
from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings

# ---------------------------------------------------------------------------
# Password hashing
# ---------------------------------------------------------------------------

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """Return a bcrypt hash of the given plain-text password."""
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    """Verify a plain-text password against its bcrypt hash."""
    return pwd_context.verify(plain, hashed)


# ---------------------------------------------------------------------------
# JWT token helpers
# ---------------------------------------------------------------------------


def create_access_token(data: dict, expires_delta: timedelta = None) -> str:
    """Create a signed JWT access token.

    Args:
        data: Claims to encode in the token (must include 'sub').
        expires_delta: Custom expiration. Falls back to ACCESS_TOKEN_EXPIRE_MINUTES.

    Returns:
        Encoded JWT string.
    """
    to_encode = data.copy()
    now = datetime.now(timezone.utc)
    expire = now + (expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"iat": now, "exp": expire})
    return jwt.encode(to_encode, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)


def verify_token(token: str) -> dict:
    """Decode and verify a JWT token.

    Args:
        token: The encoded JWT string.

    Returns:
        Decoded payload as a dictionary.

    Raises:
        JWTError: If the token is invalid or expired.
    """
    return jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])


# ---------------------------------------------------------------------------
# AES-256 encryption / decryption using Fernet (symmetric)
# ---------------------------------------------------------------------------

def _get_fernet() -> Fernet:
    """Build a Fernet instance from the configured ENCRYPTION_KEY.

    Fernet requires a 32-byte url-safe base64-encoded key. We derive one
    by padding/truncating the configured key to 32 bytes, then base64-encoding.
    """
    import base64
    raw = settings.ENCRYPTION_KEY.encode("utf-8")
    # Ensure exactly 32 bytes for Fernet's base64 requirement
    key_bytes = raw.ljust(32, b"\0")[:32]
    fernet_key = base64.urlsafe_b64encode(key_bytes)
    return Fernet(fernet_key)


def encrypt_sensitive_data(data: str) -> str:
    """Encrypt a plaintext string with AES-256 (Fernet) and return the ciphertext.

    Args:
        data: The plaintext string to encrypt.

    Returns:
        Encrypted string (Fernet token, url-safe base64 encoded).
    """
    f = _get_fernet()
    return f.encrypt(data.encode("utf-8")).decode("utf-8")


def decrypt_sensitive_data(encrypted: str) -> str:
    """Decrypt a Fernet-encrypted string back to plaintext.

    Args:
        encrypted: The Fernet token string to decrypt.

    Returns:
        Decrypted plaintext string.

    Raises:
        cryptography.fernet.InvalidToken: If the token is invalid or tampered.
    """
    f = _get_fernet()
    return f.decrypt(encrypted.encode("utf-8")).decode("utf-8")
