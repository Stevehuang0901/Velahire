"""Celery worker tasks wrapping AgentOrchestrator methods.

Each task creates a fresh orchestrator instance, runs the corresponding
async pipeline inside an event loop, and returns the result as JSON-
serialisable data.
"""

import asyncio
import logging
from typing import Any

from app.tasks.celery_app import celery_app

logger = logging.getLogger(__name__)


def _run_async(coro: Any) -> Any:
    """Run an async coroutine in a new event loop (safe for Celery workers)."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


def _get_orchestrator():
    """Create a fresh AgentOrchestrator instance."""
    from app.agents.orchestrator import AgentOrchestrator
    return AgentOrchestrator()


# ---------------------------------------------------------------------------
# Tasks
# ---------------------------------------------------------------------------


@celery_app.task(name="parse_resume", bind=True, max_retries=3)
def parse_resume_task(self, user_id: str, file_path: str, file_type: str = "pdf") -> dict:
    """Parse an uploaded resume in the background.

    Args:
        user_id: The user's UUID string.
        file_path: Path to the uploaded file on disk or S3 key.
        file_type: File type (pdf, docx, txt).

    Returns:
        Dict with parsed data, profile, ATS score, and career analysis.
    """
    logger.info("Task parse_resume started for user %s: %s", user_id, file_path)
    try:
        with open(file_path, "rb") as f:
            file_content = f.read()

        orchestrator = _get_orchestrator()
        result = _run_async(
            orchestrator.process_resume_upload(user_id, file_content, file_type)
        )
        logger.info("Task parse_resume completed for user %s", user_id)
        return result
    except Exception as exc:
        logger.error("Task parse_resume failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=60 * (2 ** self.request.retries))


@celery_app.task(name="match_jobs", bind=True, max_retries=3)
def match_jobs_task(self, user_id: str) -> dict:
    """Match jobs for a user in the background.

    Args:
        user_id: The user's UUID string.

    Returns:
        Dict with matched and ranked jobs.
    """
    logger.info("Task match_jobs started for user %s", user_id)
    try:
        orchestrator = _get_orchestrator()
        result = _run_async(orchestrator.process_job_matching(user_id))
        logger.info("Task match_jobs completed: %d matches", len(result))
        return {"status": "completed", "user_id": user_id, "matches": len(result), "data": result}
    except Exception as exc:
        logger.error("Task match_jobs failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=60 * (2 ** self.request.retries))


@celery_app.task(name="generate_content", bind=True, max_retries=3)
def generate_content_task(self, match_id: str) -> dict:
    """Generate tailored content (cover letter, resume, etc.) for a match.

    Args:
        match_id: UUID of the match record.

    Returns:
        Dict with generated content (cover letter, tailored resume, etc.).
    """
    logger.info("Task generate_content started for match %s", match_id)
    try:
        orchestrator = _get_orchestrator()
        result = _run_async(orchestrator.process_content_generation(match_id=match_id))
        logger.info("Task generate_content completed for match %s", match_id)
        return result
    except Exception as exc:
        logger.error("Task generate_content failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=60 * (2 ** self.request.retries))


@celery_app.task(name="apply_to_job", bind=True, max_retries=2)
def apply_to_job_task(self, match_id: str, mode: str = "copilot") -> dict:
    """Execute a job application for a specific match.

    Args:
        match_id: UUID of the match record.
        mode: Application mode ('copilot' or 'autopilot').

    Returns:
        Dict with application result.
    """
    logger.info("Task apply_to_job started for match %s (mode=%s)", match_id, mode)
    try:
        orchestrator = _get_orchestrator()
        result = _run_async(
            orchestrator.process_application(match_id=match_id, mode=mode)
        )
        logger.info("Task apply_to_job completed for match %s", match_id)
        return result
    except Exception as exc:
        logger.error("Task apply_to_job failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=120 * (2 ** self.request.retries))


@celery_app.task(name="monitor_emails", bind=True, max_retries=2)
def monitor_emails_task(self, user_id: str = "") -> dict:
    """Monitor a user's email inbox for application responses.

    Args:
        user_id: The user's UUID string. If empty, monitors all active users.

    Returns:
        Dict with monitoring results.
    """
    logger.info("Task monitor_emails started for user %s", user_id or "all")
    try:
        orchestrator = _get_orchestrator()
        result = _run_async(orchestrator.monitor_agent.monitor_inbox(user_id))
        logger.info("Task monitor_emails completed: %d emails processed", len(result))
        return {"status": "completed", "user_id": user_id, "new_emails": len(result), "data": result}
    except Exception as exc:
        logger.error("Task monitor_emails failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=300)


@celery_app.task(name="weekly_report", bind=True, max_retries=2)
def generate_weekly_report_task(self, user_id: str) -> dict:
    """Generate a weekly activity report for a user.

    Args:
        user_id: The user's UUID string.

    Returns:
        Dict with the weekly report.
    """
    logger.info("Task weekly_report started for user %s", user_id)
    try:
        orchestrator = _get_orchestrator()
        result = _run_async(orchestrator.monitor_agent.generate_weekly_report(user_id))
        logger.info("Task weekly_report completed for user %s", user_id)
        return result
    except Exception as exc:
        logger.error("Task weekly_report failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=300)


@celery_app.task(name="bulk_apply", bind=True, max_retries=1)
def bulk_apply_task(self, user_id: str, match_ids: list[str], mode: str = "copilot") -> dict:
    """Apply to multiple jobs in bulk.

    Args:
        user_id: The user's UUID string.
        match_ids: List of match UUIDs to apply to.
        mode: Application mode ('copilot' or 'autopilot').

    Returns:
        Dict with results for each application.
    """
    logger.info("Task bulk_apply started for user %s: %d jobs", user_id, len(match_ids))
    try:
        orchestrator = _get_orchestrator()
        results = _run_async(
            orchestrator.process_bulk_apply(match_ids=match_ids, mode=mode)
        )
        successful = sum(1 for r in results if r.get("success", False))
        logger.info(
            "Task bulk_apply completed: %d/%d successful", successful, len(match_ids)
        )
        return {
            "status": "completed",
            "user_id": user_id,
            "total": len(match_ids),
            "successful": successful,
            "results": results,
        }
    except Exception as exc:
        logger.error("Task bulk_apply failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=300)
