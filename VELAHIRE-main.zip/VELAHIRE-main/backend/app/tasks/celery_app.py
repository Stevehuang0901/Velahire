"""Celery application configuration for VelaHire background tasks."""

from celery import Celery

from app.core.config import settings

celery_app = Celery(
    "velahire",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=["app.tasks.worker"],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_soft_time_limit=300,
    task_time_limit=600,
    task_routes={
        "parse_resume": {"queue": "ai"},
        "match_jobs": {"queue": "ai"},
        "generate_content": {"queue": "ai"},
        "apply_to_job": {"queue": "default"},
        "monitor_emails": {"queue": "emails"},
        "weekly_report": {"queue": "default"},
        "bulk_apply": {"queue": "default"},
    },
    beat_schedule={
        "monitor-emails-every-30-min": {
            "task": "monitor_emails",
            "schedule": 1800.0,
            "args": [],
        },
        "weekly-reports-every-monday": {
            "task": "weekly_report",
            "schedule": {
                "crontab": {"hour": 9, "minute": 0, "day_of_week": 1},
            },
        },
    },
)
