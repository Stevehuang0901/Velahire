"""Salary intelligence router: insights, comparison, market trends."""

import uuid
from typing import Annotated, Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.job import Job
from app.models.user import User
from app.schemas.interview import (
    MarketTrendsResponse,
    SalaryCompareResponse,
    SalaryInsightResponse,
)

router = APIRouter(prefix="/salary", tags=["Salary Intelligence"])


@router.get("/insight/{job_id}", response_model=SalaryInsightResponse)
async def get_salary_insight(
    job_id: uuid.UUID,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict[str, Any]:
    """Get salary insights for a specific job.

    Returns comprehensive salary intelligence including salary range,
    median, percentiles, data source attribution, and actionable
    negotiation tips for the specified job posting.

    Raises:
        HTTPException 404: If the job does not exist.
    """
    result = await db.execute(select(Job).where(Job.id == job_id))
    job = result.scalar_one_or_none()
    if job is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found",
        )

    # TODO: Call salary intelligence service for enriched data
    # insight = await salary_service.get_insight(job)

    salary_min = job.salary_min or 0.0
    salary_max = job.salary_max or 0.0
    salary_median = (salary_min + salary_max) / 2 if salary_min and salary_max else 0.0

    return {
        "job_title": job.title,
        "company": job.company,
        "salary_range_min": salary_min,
        "salary_range_max": salary_max,
        "salary_median": salary_median,
        "currency": job.salary_currency or "USD",
        "percentile_25": salary_min,
        "percentile_75": salary_max,
        "data_source": "job_posting",
        "negotiation_tips": [],
    }


@router.get("/compare", response_model=SalaryCompareResponse)
async def compare_salaries(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    job_titles: str = Query(description="Comma-separated list of job titles to compare"),
    locations: Optional[str] = Query(default=None, description="Comma-separated list of locations"),
) -> dict[str, Any]:
    """Compare salary data across roles and locations.

    Accepts a comma-separated list of job titles and optional locations,
    returning a side-by-side comparison of salary ranges, medians, and
    market demand for each combination.

    Raises:
        HTTPException 400: If no job titles are provided.
    """
    titles = [t.strip() for t in job_titles.split(",") if t.strip()]
    locs = [loc.strip() for loc in locations.split(",") if loc.strip()] if locations else []

    if not titles:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one job title is required",
        )

    # TODO: Call salary comparison service for real data
    # comparisons = await salary_service.compare(titles, locs)

    comparisons: list[dict[str, Any]] = []
    for title in titles:
        comparison: dict[str, Any] = {
            "job_title": title,
            "salary_range_min": 0.0,
            "salary_range_max": 0.0,
            "salary_median": 0.0,
            "currency": "USD",
            "demand_level": "unknown",
        }
        if locs:
            comparison["locations"] = {
                loc: {
                    "salary_range_min": 0.0,
                    "salary_range_max": 0.0,
                    "salary_median": 0.0,
                }
                for loc in locs
            }
        comparisons.append(comparison)

    return {"comparisons": comparisons}


@router.get("/market-trends", response_model=MarketTrendsResponse)
async def get_market_trends(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    role: str = Query(description="Job role to analyze salary trends for"),
    location: Optional[str] = Query(default=None, description="Location filter for trends"),
) -> dict[str, Any]:
    """Get salary market trends over time.

    Returns historical salary trend data for a given role and optional
    location, including quarter-over-quarter changes and a narrative
    summary of current market conditions.
    """
    # TODO: Call market trends service for real data
    # trends = await salary_service.get_trends(role, location)

    return {
        "role": role,
        "location": location,
        "trend_data": [],
        "summary": "",
    }
