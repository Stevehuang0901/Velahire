"""Dashboard router: overview, funnel, timeline, analytics, weekly report."""

from datetime import datetime, timedelta, timezone
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.application import Application, ApplicationStatus
from app.models.match import Match
from app.models.resume import Resume
from app.models.user import User

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/overview", response_model=dict)
async def get_dashboard_overview(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict[str, Any]:
    """Get dashboard overview data.

    Returns a high-level summary of the user's job search activity
    including total matches, applications, interviews, offers, active
    resumes, and overall ATS score average.
    """
    # Count matches
    matches_count = (await db.execute(
        select(func.count()).select_from(Match).where(Match.user_id == current_user.id)
    )).scalar() or 0

    # Average ATS score
    avg_score = (await db.execute(
        select(func.avg(Match.ats_score)).where(Match.user_id == current_user.id)
    )).scalar() or 0.0

    # Application status breakdown
    status_rows = (await db.execute(
        select(Application.status, func.count())
        .join(Match, Application.match_id == Match.id)
        .where(Match.user_id == current_user.id)
        .group_by(Application.status)
    )).all()
    status_counts = {row[0].value: row[1] for row in status_rows}

    total_applications = sum(status_counts.values())
    total_interviews = status_counts.get("interviewing", 0)
    total_offers = status_counts.get("offer", 0)

    # Count resumes
    total_resumes = (await db.execute(
        select(func.count()).select_from(Resume).where(Resume.user_id == current_user.id)
    )).scalar() or 0

    return {
        "total_matches": matches_count,
        "total_applications": total_applications,
        "total_interviews": total_interviews,
        "total_offers": total_offers,
        "total_resumes": total_resumes,
        "avg_ats_score": round(float(avg_score), 1),
        "status_breakdown": status_counts,
    }


@router.get("/funnel", response_model=dict)
async def get_application_funnel(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict[str, Any]:
    """Get application funnel data.

    Returns the conversion funnel from matches through applications,
    acknowledgments, interviews, and offers. Each stage shows the count
    and conversion rate from the previous stage.
    """
    total_matches = (await db.execute(
        select(func.count()).select_from(Match).where(Match.user_id == current_user.id)
    )).scalar() or 0

    status_rows = (await db.execute(
        select(Application.status, func.count())
        .join(Match, Application.match_id == Match.id)
        .where(Match.user_id == current_user.id)
        .group_by(Application.status)
    )).all()
    status_counts = {row[0].value: row[1] for row in status_rows}

    total_applied = sum(status_counts.values())
    acknowledged = status_counts.get("acknowledged", 0)
    interviewing = status_counts.get("interviewing", 0)
    offers = status_counts.get("offer", 0)

    funnel = [
        {
            "stage": "Matched",
            "count": total_matches,
            "conversion_rate": 100.0,
        },
        {
            "stage": "Applied",
            "count": total_applied,
            "conversion_rate": (total_applied / total_matches * 100) if total_matches > 0 else 0.0,
        },
        {
            "stage": "Acknowledged",
            "count": acknowledged,
            "conversion_rate": (acknowledged / total_applied * 100) if total_applied > 0 else 0.0,
        },
        {
            "stage": "Interviewing",
            "count": interviewing,
            "conversion_rate": (interviewing / acknowledged * 100) if acknowledged > 0 else 0.0,
        },
        {
            "stage": "Offer",
            "count": offers,
            "conversion_rate": (offers / interviewing * 100) if interviewing > 0 else 0.0,
        },
    ]

    return {"funnel": funnel}


@router.get("/timeline", response_model=dict)
async def get_application_timeline(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    days: int = Query(default=30, ge=7, le=365, description="Number of days to include in timeline"),
) -> dict[str, Any]:
    """Get application timeline data.

    Returns a day-by-day breakdown of application activity over the
    specified number of days, showing new applications submitted per day.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)

    result = await db.execute(
        select(
            func.date(Application.created_at).label("date"),
            func.count().label("count"),
        )
        .join(Match, Application.match_id == Match.id)
        .where(Match.user_id == current_user.id, Application.created_at >= cutoff)
        .group_by(func.date(Application.created_at))
        .order_by(func.date(Application.created_at))
    )
    daily_counts = [{"date": str(row.date), "applications": row.count} for row in result.all()]

    return {
        "period_days": days,
        "timeline": daily_counts,
    }


@router.get("/analytics", response_model=dict)
async def get_detailed_analytics(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict[str, Any]:
    """Get detailed analytics data.

    Returns comprehensive analytics including response time averages,
    success rates by job source, ATS score distribution, and performance
    metrics from the user's application history.
    """
    result = await db.execute(
        select(Application)
        .join(Match, Application.match_id == Match.id)
        .where(Match.user_id == current_user.id)
        .options(
            selectinload(Application.match).selectinload(Match.job)
        )
    )
    applications = list(result.scalars().all())

    by_source: dict[str, int] = {}
    score_distribution: list[float] = []
    response_times: list[float] = []

    for app in applications:
        if app.match and app.match.job:
            source = app.match.job.source.value if hasattr(app.match.job.source, "value") else str(app.match.job.source)
            by_source[source] = by_source.get(source, 0) + 1

        if app.match and app.match.ats_score is not None:
            score_distribution.append(app.match.ats_score)

        if app.applied_at and app.created_at:
            delta_hours = (app.applied_at - app.created_at).total_seconds() / 3600
            response_times.append(delta_hours)

    avg_response_time = sum(response_times) / len(response_times) if response_times else 0.0
    avg_score = sum(score_distribution) / len(score_distribution) if score_distribution else 0.0

    return {
        "total_applications": len(applications),
        "by_source": by_source,
        "avg_ats_score": round(avg_score, 1),
        "avg_time_to_apply_hours": round(avg_response_time, 1),
        "score_distribution": {
            "0-25": len([s for s in score_distribution if s <= 25]),
            "26-50": len([s for s in score_distribution if 25 < s <= 50]),
            "51-75": len([s for s in score_distribution if 50 < s <= 75]),
            "76-100": len([s for s in score_distribution if s > 75]),
        },
    }


@router.get("/weekly-report", response_model=dict)
async def get_weekly_report(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict[str, Any]:
    """Get weekly summary report.

    Returns a summary of the past week's activity including new
    applications, new matches, status changes, and recommended
    actions for the upcoming week.
    """
    one_week_ago = datetime.now(timezone.utc) - timedelta(days=7)

    # New applications this week
    new_apps = (await db.execute(
        select(func.count())
        .select_from(Application)
        .join(Match, Application.match_id == Match.id)
        .where(Match.user_id == current_user.id, Application.created_at >= one_week_ago)
    )).scalar() or 0

    # New matches this week
    new_matches = (await db.execute(
        select(func.count())
        .select_from(Match)
        .where(Match.user_id == current_user.id, Match.created_at >= one_week_ago)
    )).scalar() or 0

    # Status breakdown for this week's applications
    status_rows = (await db.execute(
        select(Application.status, func.count())
        .join(Match, Application.match_id == Match.id)
        .where(Match.user_id == current_user.id, Application.created_at >= one_week_ago)
        .group_by(Application.status)
    )).all()
    status_updates = {row[0].value: row[1] for row in status_rows}

    return {
        "period_start": one_week_ago.isoformat(),
        "period_end": datetime.now(timezone.utc).isoformat(),
        "new_matches": new_matches,
        "new_applications": new_apps,
        "status_updates": status_updates,
        "highlights": [],
        "recommended_actions": [],
    }
