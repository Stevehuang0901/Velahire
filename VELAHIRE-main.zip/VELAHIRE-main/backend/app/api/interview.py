"""Interview preparation router: prep materials, mock interviews, questions, feedback."""

import uuid
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.job import Job
from app.models.match import Match
from app.models.user import User
from app.schemas.interview import (
    InterviewFeedbackRequest,
    InterviewFeedbackResponse,
    InterviewPrepRequest,
    InterviewPrepResponse,
    MockInterviewRequest,
    MockInterviewResponse,
)

router = APIRouter(prefix="/interview", tags=["Interview"])


@router.post("/prep/{match_id}", response_model=InterviewPrepResponse)
async def generate_interview_prep(
    match_id: uuid.UUID,
    payload: InterviewPrepRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict[str, Any]:
    """Generate interview preparation materials for a matched job.

    Produces a comprehensive preparation package including company
    information, role analysis, common interview questions with
    STAR-format example answers, recent company news, and competitor
    analysis tailored to the specific role.

    Raises:
        HTTPException 404: If the match does not exist or belongs to another user.
    """
    result = await db.execute(
        select(Match)
        .options(selectinload(Match.job))
        .where(Match.id == match_id, Match.user_id == current_user.id)
    )
    match = result.scalar_one_or_none()
    if match is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Match not found",
        )

    job = match.job

    # TODO: Call AI interview prep service
    # prep = await ai_service.generate_interview_prep(
    #     user=current_user, job=job, focus_areas=payload.focus_areas
    # )

    return {
        "company_info": {
            "name": job.company,
            "industry": job.industry or "",
            "size": job.company_size or "",
        },
        "role_analysis": {
            "title": job.title,
            "required_skills": job.required_skills or [],
            "key_responsibilities": [],
        },
        "common_questions": [],
        "star_examples": [],
        "company_news": [],
        "competitors": [],
    }


@router.post("/mock-interview", response_model=MockInterviewResponse)
async def start_mock_interview(
    payload: MockInterviewRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict[str, Any]:
    """Start a mock interview session.

    Creates a new mock interview session with AI-generated questions
    tailored to the specified job title, company, and interview type.
    Returns a session ID that can be used to submit answers and
    receive feedback.
    """
    # TODO: Call AI mock interview service to generate questions
    # session = await ai_service.create_mock_interview(
    #     job_title=payload.job_title,
    #     company=payload.company,
    #     interview_type=payload.interview_type,
    #     num_questions=payload.num_questions,
    # )

    session_id = str(uuid.uuid4())

    return {
        "questions": [],
        "session_id": session_id,
    }


@router.get("/questions/{job_id}", response_model=list[dict])
async def get_interview_questions(
    job_id: uuid.UUID,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> list[dict[str, Any]]:
    """Get common interview questions for a specific job.

    Returns a curated list of interview questions based on the job's
    title, required skills, and industry. Each question includes
    the category, difficulty level, and a suggested approach.

    Raises:
        HTTPException 404: If the job does not exist.
    """
    result = await db.execute(select(Job).where(Job.id == job_id))
    job = result.scalar_one_or_none()
    if job is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found",
        )

    # TODO: Call AI question generation service
    # questions = await ai_service.generate_interview_questions(job)

    return []


@router.post("/feedback", response_model=InterviewFeedbackResponse)
async def submit_interview_feedback(
    payload: InterviewFeedbackRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict[str, Any]:
    """Submit mock interview answers for AI feedback.

    Analyzes the user's answers to mock interview questions and provides
    detailed feedback including an overall score, per-question analysis,
    identified strengths, areas for improvement, and a recommendation.

    Raises:
        HTTPException 400: If no answers are provided.
    """
    if not payload.answers:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one answer is required",
        )

    # TODO: Validate session_id exists and belongs to the user
    # TODO: Call AI feedback service
    # feedback = await ai_service.analyze_interview_answers(
    #     session_id=payload.session_id, answers=payload.answers
    # )

    return {
        "overall_score": 0.0,
        "per_question_feedback": [],
        "strengths": [],
        "improvements": [],
        "recommendation": "",
    }
