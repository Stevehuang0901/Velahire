"""Resume management router: upload, list, score, optimize, career path."""

import os
import uuid
from typing import Annotated

import aiofiles
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.config import settings
from app.core.database import get_db
from app.models.resume import Resume
from app.models.user import User
from app.schemas.resume import (
    CareerPathResponse,
    ResumeListResponse,
    ResumeOptimizeRequest,
    ResumeScoreResponse,
    ResumeUploadResponse,
)

router = APIRouter(prefix="/resume", tags=["Resume"])

ALLOWED_CONTENT_TYPES = {
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/msword",
    "text/plain",
}


@router.post("/upload", response_model=ResumeUploadResponse, status_code=status.HTTP_201_CREATED)
async def upload_resume(
    file: UploadFile = File(..., description="Resume file (PDF, DOCX, DOC, TXT)"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> Resume:
    """Upload a resume file for parsing and ATS scoring.

    Accepts PDF, DOCX, DOC, or TXT files up to the configured maximum size.
    The resume is saved to storage and parsing is triggered to populate
    the parsed JSON and compute an initial ATS score.

    Raises:
        HTTPException 400: If the file type is not supported.
        HTTPException 413: If the file exceeds the maximum upload size.
    """
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file type '{file.content_type}'. Upload PDF, DOCX, DOC, or TXT.",
        )

    contents = await file.read()
    max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
    if len(contents) > max_bytes:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File exceeds maximum size of {settings.MAX_UPLOAD_SIZE_MB} MB",
        )

    # Save to disk
    upload_dir = os.path.join(settings.UPLOAD_DIR, str(current_user.id))
    os.makedirs(upload_dir, exist_ok=True)

    file_ext = os.path.splitext(file.filename or "resume")[1]
    stored_name = f"{uuid.uuid4().hex}{file_ext}"
    file_path = os.path.join(upload_dir, stored_name)

    async with aiofiles.open(file_path, "wb") as f:
        await f.write(contents)

    resume = Resume(
        user_id=current_user.id,
        filename=file.filename or "resume",
        raw_file_path=file_path,
        version_name=os.path.splitext(file.filename or "resume")[0],
    )
    db.add(resume)
    await db.flush()
    await db.refresh(resume)

    # TODO: Trigger async parsing task (Celery) to populate parsed_json and ats_score
    # e.g., parse_resume_task.delay(str(resume.id))

    return resume


@router.get("/list", response_model=ResumeListResponse)
async def list_resumes(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """List all resumes for the current user.

    Returns a list of all uploaded resumes with their metadata,
    ordered by creation date descending.
    """
    count_result = await db.execute(
        select(func.count()).select_from(Resume).where(Resume.user_id == current_user.id)
    )
    total = count_result.scalar() or 0

    result = await db.execute(
        select(Resume)
        .where(Resume.user_id == current_user.id)
        .order_by(Resume.created_at.desc())
    )
    resumes = list(result.scalars().all())

    return {"resumes": resumes, "total": total}


@router.get("/career-path", response_model=CareerPathResponse)
async def get_career_path(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """Get AI-generated career path analysis.

    Analyzes the user's resume history, skills, and experience to generate
    personalized career path recommendations, skill gap analysis, and
    certification suggestions.

    Raises:
        HTTPException 422: If the user has no parsed resumes to analyze.
    """
    result = await db.execute(
        select(Resume)
        .where(Resume.user_id == current_user.id, Resume.parsed_json.isnot(None))
        .order_by(Resume.is_primary.desc(), Resume.created_at.desc())
        .limit(1)
    )
    resume = result.scalar_one_or_none()
    if resume is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="No parsed resumes found. Upload a resume before requesting career path analysis.",
        )

    # TODO: Call AI career path analysis service
    # career_path = await ai_service.analyze_career_path(resume.parsed_json)

    return {
        "current_role": "",
        "suggested_paths": [],
        "skill_gaps": [],
        "recommended_certifications": [],
        "timeline_estimate": "",
    }


@router.get("/score/{resume_id}", response_model=ResumeScoreResponse)
async def get_resume_score(
    resume_id: uuid.UUID,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """Get detailed ATS score breakdown for a resume.

    Provides granular scoring across formatting, keyword density,
    quantification usage, and layout metrics, along with actionable
    suggestions for improvement and industry comparison data.

    Raises:
        HTTPException 404: If the resume does not exist or belongs to another user.
        HTTPException 422: If the resume has not been scored yet.
    """
    result = await db.execute(
        select(Resume).where(Resume.id == resume_id, Resume.user_id == current_user.id)
    )
    resume = result.scalar_one_or_none()
    if resume is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resume not found",
        )

    if resume.ats_score is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Resume has not been scored yet. Please wait for processing to complete.",
        )

    # TODO: Retrieve detailed scoring breakdown from AI service
    return {
        "score": resume.ats_score,
        "formatting_score": 0.0,
        "keyword_density": 0.0,
        "quantification_score": 0.0,
        "layout_score": 0.0,
        "suggestions": [],
        "industry_comparison": {},
    }


@router.get("/{resume_id}", response_model=ResumeUploadResponse)
async def get_resume(
    resume_id: uuid.UUID,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> Resume:
    """Get a specific resume by ID.

    Returns the full resume record including parsed content and ATS score.

    Raises:
        HTTPException 404: If the resume does not exist or belongs to another user.
    """
    result = await db.execute(
        select(Resume).where(Resume.id == resume_id, Resume.user_id == current_user.id)
    )
    resume = result.scalar_one_or_none()
    if resume is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resume not found",
        )
    return resume


@router.post("/{resume_id}/optimize", response_model=ResumeUploadResponse)
async def optimize_resume(
    resume_id: uuid.UUID,
    payload: ResumeOptimizeRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> Resume:
    """AI-optimize a resume for better ATS scores.

    Uses AI to rewrite and restructure the resume content based on
    target job title, keywords, and preferred style. Updates the
    resume's parsed JSON with the optimized content.

    Raises:
        HTTPException 404: If the resume does not exist or belongs to another user.
        HTTPException 422: If the resume has not been parsed yet.
    """
    result = await db.execute(
        select(Resume).where(Resume.id == resume_id, Resume.user_id == current_user.id)
    )
    resume = result.scalar_one_or_none()
    if resume is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resume not found",
        )

    if resume.parsed_json is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Resume has not been parsed yet. Please wait for processing to complete.",
        )

    # TODO: Call AI optimization service
    # optimized = await ai_service.optimize_resume(resume.parsed_json, payload)
    # resume.parsed_json = optimized
    # await db.flush()
    # await db.refresh(resume)

    return resume


@router.delete("/{resume_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_resume(
    resume_id: uuid.UUID,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> None:
    """Delete a resume.

    Permanently removes the resume record and its associated file
    from storage.

    Raises:
        HTTPException 404: If the resume does not exist or belongs to another user.
    """
    result = await db.execute(
        select(Resume).where(Resume.id == resume_id, Resume.user_id == current_user.id)
    )
    resume = result.scalar_one_or_none()
    if resume is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resume not found",
        )

    # Remove file from disk if it exists
    if os.path.exists(resume.raw_file_path):
        os.remove(resume.raw_file_path)

    await db.delete(resume)
    await db.flush()
