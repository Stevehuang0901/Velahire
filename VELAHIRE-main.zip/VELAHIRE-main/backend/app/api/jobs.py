"""Jobs router: matching, searching, tailoring, recommendations, market analysis."""

import uuid
from typing import Annotated, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.job import Job
from app.models.match import Match
from app.models.user import User
from app.schemas.job import (
    JobListResponse,
    JobMatchResponse,
    JobResponse,
    JobTailorRequest,
    MarketAnalysisResponse,
)

router = APIRouter(prefix="/jobs", tags=["Jobs"])


def _build_match_response(match: Match) -> dict:
    """Build a JobMatchResponse dict from a Match ORM object."""
    keyword_matches = match.keyword_matches or {}
    return {
        "job": match.job,
        "match_id": match.id,
        "ats_score": match.ats_score or 0.0,
        "skill_matches": keyword_matches.get("matched_skills", []),
        "missing_skills": keyword_matches.get("missing_skills", []),
        "keyword_analysis": keyword_matches,
        "status": match.status.value if hasattr(match.status, "value") else str(match.status),
    }


@router.get("/match", response_model=list[JobMatchResponse])
async def get_matched_jobs(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    page: int = Query(default=1, ge=1, description="Page number"),
    limit: int = Query(default=20, ge=1, le=100, description="Results per page"),
) -> list[dict]:
    """Get matched jobs for the current user with ATS scores.

    Returns jobs that have been matched to the user's profile, sorted by
    ATS score descending. Each match includes skill analysis and keyword
    matching details.
    """
    offset = (page - 1) * limit

    result = await db.execute(
        select(Match)
        .options(selectinload(Match.job))
        .where(Match.user_id == current_user.id)
        .order_by(Match.ats_score.desc().nullslast())
        .offset(offset)
        .limit(limit)
    )
    matches = result.scalars().all()

    return [_build_match_response(m) for m in matches]


@router.get("/search", response_model=JobListResponse)
async def search_jobs(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    keyword: Optional[str] = Query(default=None, description="Search keyword for title or company"),
    location: Optional[str] = Query(default=None, description="Location filter"),
    remote: Optional[bool] = Query(default=None, description="Remote jobs only"),
    salary_min: Optional[float] = Query(default=None, ge=0, description="Minimum salary"),
    salary_max: Optional[float] = Query(default=None, ge=0, description="Maximum salary"),
    company_size: Optional[str] = Query(default=None, description="Company size filter"),
    industry: Optional[str] = Query(default=None, description="Industry filter"),
    page: int = Query(default=1, ge=1, description="Page number"),
    limit: int = Query(default=20, ge=1, le=100, description="Results per page"),
) -> dict:
    """Search jobs with filters.

    Performs a filtered search across all available job listings. Supports
    keyword search on title and company, location, remote status, salary
    range, company size, and industry filters with pagination.
    """
    stmt = select(Job)
    conditions = []

    if keyword:
        pattern = f"%{keyword}%"
        conditions.append(Job.title.ilike(pattern) | Job.company.ilike(pattern))
    if location:
        conditions.append(Job.location.ilike(f"%{location}%"))
    if remote is not None:
        conditions.append(Job.is_remote == remote)
    if salary_min is not None:
        conditions.append(Job.salary_max >= salary_min)
    if salary_max is not None:
        conditions.append(Job.salary_min <= salary_max)
    if company_size:
        conditions.append(Job.company_size == company_size)
    if industry:
        conditions.append(Job.industry.ilike(f"%{industry}%"))

    if conditions:
        stmt = stmt.where(and_(*conditions))

    # Count total results
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = (await db.execute(count_stmt)).scalar() or 0

    # Paginate
    offset = (page - 1) * limit
    stmt = stmt.order_by(Job.posted_at.desc().nullslast()).offset(offset).limit(limit)
    result = await db.execute(stmt)
    jobs = list(result.scalars().all())

    return {"jobs": jobs, "total": total, "page": page}


@router.get("/recommendations", response_model=list[JobMatchResponse])
async def get_recommendations(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    limit: int = Query(default=10, ge=1, le=50, description="Number of recommendations"),
) -> list[dict]:
    """Get AI-powered job recommendations.

    Analyzes the user's profile, resume, and application history to
    suggest new job opportunities that closely match their skills and
    career goals. Results are sorted by relevance score.
    """
    # TODO: Replace with AI recommendation engine call
    # recommendations = await ai_service.recommend_jobs(current_user, limit)

    result = await db.execute(
        select(Match)
        .options(selectinload(Match.job))
        .where(Match.user_id == current_user.id)
        .order_by(Match.ats_score.desc().nullslast())
        .limit(limit)
    )
    matches = result.scalars().all()

    return [_build_match_response(m) for m in matches]


@router.get("/market-analysis", response_model=MarketAnalysisResponse)
async def get_market_analysis(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    role: str = Query(description="Target role for market analysis"),
    location: Optional[str] = Query(default=None, description="Location for analysis"),
) -> dict:
    """Get market trends and analysis for a given role.

    Provides demand trends, average salary data, top required skills,
    leading companies hiring, and geographic hotspots for the
    specified role and optional location.
    """
    # TODO: Call market analysis service
    # analysis = await market_service.analyze(role, location)

    return {
        "role": role,
        "demand_trend": "stable",
        "avg_salary": 0.0,
        "top_skills": [],
        "top_companies": [],
        "geographic_hotspots": [],
        "outlook": "",
    }


@router.get("/{job_id}", response_model=JobResponse)
async def get_job(
    job_id: uuid.UUID,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> Job:
    """Get detailed information for a specific job.

    Returns the full job listing including description, requirements,
    salary information, and company details.

    Raises:
        HTTPException 404: If the job does not exist.
    """
    result = await db.execute(select(Job).where(Job.id == job_id))
    job = result.scalar_one_or_none()
    if job is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found",
        )
    return job


@router.post("/{job_id}/tailor", response_model=dict)
async def tailor_content_for_job(
    job_id: uuid.UUID,
    payload: JobTailorRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """Generate tailored application content for a specific job.

    Uses AI to create a customized cover letter, resume highlights, and
    responses to open questions based on the user's profile and the
    job requirements.

    Raises:
        HTTPException 404: If the job does not exist.
    """
    result = await db.execute(select(Job).where(Job.id == job_id))
    job = result.scalar_one_or_none()
    if job is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found",
        )

    # Find or create a match for this user-job pair
    match_result = await db.execute(
        select(Match).where(Match.user_id == current_user.id, Match.job_id == job_id)
    )
    match = match_result.scalar_one_or_none()
    if match is None:
        match = Match(user_id=current_user.id, job_id=job_id, status="tailoring")
        db.add(match)
        await db.flush()

    # TODO: Call AI tailoring service
    # tailored = await ai_service.tailor_content(current_user, job, payload)

    return {
        "match_id": str(match.id),
        "job_id": str(job_id),
        "cover_letter": "",
        "resume_highlights": [],
        "open_question_answers": [],
        "status": "ready",
    }
