"""Applications router: apply, list, status, retry, stats, bulk apply."""

import uuid
from typing import Annotated, Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.application import Application, ApplicationStatus
from app.models.match import Match
from app.models.user import User
from app.schemas.application import (
    ApplicationCreate,
    ApplicationResponse,
    BulkApplyRequest,
    BulkApplyResponse,
    DashboardStats,
)

router = APIRouter(prefix="/applications", tags=["Applications"])


@router.post("/apply/{match_id}", response_model=ApplicationResponse, status_code=status.HTTP_201_CREATED)
async def apply_to_job(
    match_id: uuid.UUID,
    payload: ApplicationCreate,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> Application:
    """Start a job application for a matched job.

    Initiates the application process in either copilot mode (user-guided)
    or autopilot mode (fully automated). The application is created with
    PENDING status and processed asynchronously.

    Raises:
        HTTPException 404: If the match does not exist or belongs to another user.
        HTTPException 409: If an application for this match already exists.
    """
    result = await db.execute(
        select(Match).where(Match.id == match_id, Match.user_id == current_user.id)
    )
    match = result.scalar_one_or_none()
    if match is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Match not found",
        )

    existing = await db.execute(
        select(Application).where(Application.match_id == match_id)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="An application for this match already exists",
        )

    application = Application(
        match_id=match_id,
        status=ApplicationStatus.PENDING,
    )
    db.add(application)
    match.status = "applying"
    await db.flush()
    await db.refresh(application)

    # TODO: Dispatch application task based on mode
    # if payload.mode == "autopilot":
    #     submit_application_task.delay(str(application.id))

    return application


@router.get("/list", response_model=list[ApplicationResponse])
async def list_applications(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    status_filter: Optional[str] = Query(default=None, alias="status", description="Filter by application status"),
    page: int = Query(default=1, ge=1, description="Page number"),
    limit: int = Query(default=20, ge=1, le=100, description="Results per page"),
) -> list[Application]:
    """List all applications with optional pagination and status filter.

    Returns the user's applications ordered by creation date descending.
    Supports filtering by application status.

    Raises:
        HTTPException 400: If an invalid status filter value is provided.
    """
    stmt = (
        select(Application)
        .join(Match, Application.match_id == Match.id)
        .where(Match.user_id == current_user.id)
    )

    if status_filter:
        try:
            app_status = ApplicationStatus(status_filter)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid status '{status_filter}'. Valid values: {[s.value for s in ApplicationStatus]}",
            )
        stmt = stmt.where(Application.status == app_status)

    offset = (page - 1) * limit
    stmt = stmt.order_by(Application.created_at.desc()).offset(offset).limit(limit)

    result = await db.execute(stmt)
    return list(result.scalars().all())


@router.get("/{application_id}/status", response_model=ApplicationResponse)
async def get_application_status(
    application_id: uuid.UUID,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> Application:
    """Get the current status of a specific application.

    Returns the full application record including status, timestamps,
    platform response, and retry count.

    Raises:
        HTTPException 404: If the application does not exist or belongs to another user.
    """
    result = await db.execute(
        select(Application)
        .join(Match, Application.match_id == Match.id)
        .where(Application.id == application_id, Match.user_id == current_user.id)
    )
    application = result.scalar_one_or_none()
    if application is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Application not found",
        )
    return application


@router.post("/{application_id}/retry", response_model=ApplicationResponse)
async def retry_application(
    application_id: uuid.UUID,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> Application:
    """Retry a failed application.

    Resets a failed application's status to PENDING and increments the
    retry counter. The application will be reprocessed asynchronously.

    Raises:
        HTTPException 404: If the application does not exist or belongs to another user.
        HTTPException 400: If the application is not in a failed state.
    """
    result = await db.execute(
        select(Application)
        .join(Match, Application.match_id == Match.id)
        .where(Application.id == application_id, Match.user_id == current_user.id)
    )
    application = result.scalar_one_or_none()
    if application is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Application not found",
        )

    if application.status != ApplicationStatus.FAILED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cannot retry application with status '{application.status.value}'. Only failed applications can be retried.",
        )

    application.status = ApplicationStatus.PENDING
    application.retry_count += 1
    application.error_log = None
    await db.flush()
    await db.refresh(application)

    # TODO: Dispatch retry task
    # submit_application_task.delay(str(application.id))

    return application


@router.get("/stats", response_model=DashboardStats)
async def get_application_stats(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """Get dashboard statistics for the user's applications.

    Returns aggregated metrics including total applications, response rate,
    interview rate, offer rate, status breakdown, platform breakdown,
    and weekly trend data.
    """
    result = await db.execute(
        select(Application)
        .join(Match, Application.match_id == Match.id)
        .where(Match.user_id == current_user.id)
    )
    applications = list(result.scalars().all())

    total = len(applications)
    by_status: dict[str, int] = {}
    by_platform: dict[str, int] = {}
    responded = 0
    interviewing = 0
    offers = 0

    for app in applications:
        status_val = app.status.value if hasattr(app.status, "value") else str(app.status)
        by_status[status_val] = by_status.get(status_val, 0) + 1

        platform = app.platform_account_id or "direct"
        by_platform[platform] = by_platform.get(platform, 0) + 1

        if status_val in ("acknowledged", "interviewing", "offer", "rejected"):
            responded += 1
        if status_val == "interviewing":
            interviewing += 1
        if status_val == "offer":
            offers += 1

    return {
        "total_applied": total,
        "response_rate": round((responded / total * 100) if total > 0 else 0.0, 1),
        "interview_rate": round((interviewing / total * 100) if total > 0 else 0.0, 1),
        "offer_rate": round((offers / total * 100) if total > 0 else 0.0, 1),
        "by_status": by_status,
        "by_platform": by_platform,
        "weekly_trend": [],
    }


@router.post("/bulk-apply", response_model=BulkApplyResponse)
async def bulk_apply(
    payload: BulkApplyRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """Apply to multiple jobs in a single request.

    Accepts a list of match IDs and creates application records for each.
    Returns a summary of submitted and failed applications with details.

    Raises:
        HTTPException 400: If no match IDs are provided.
    """
    if not payload.match_ids:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one match_id is required",
        )

    submitted = 0
    failed = 0
    details: list[dict[str, Any]] = []

    for match_id in payload.match_ids:
        # Verify match belongs to user
        match_result = await db.execute(
            select(Match).where(Match.id == match_id, Match.user_id == current_user.id)
        )
        match = match_result.scalar_one_or_none()
        if match is None:
            failed += 1
            details.append({"match_id": str(match_id), "status": "failed", "reason": "Match not found"})
            continue

        # Check for existing application
        existing_result = await db.execute(
            select(Application).where(Application.match_id == match_id)
        )
        if existing_result.scalar_one_or_none():
            failed += 1
            details.append({"match_id": str(match_id), "status": "failed", "reason": "Application already exists"})
            continue

        application = Application(
            match_id=match_id,
            status=ApplicationStatus.PENDING,
        )
        db.add(application)
        match.status = "applying"
        submitted += 1
        details.append({"match_id": str(match_id), "status": "submitted"})

    await db.flush()

    # TODO: Dispatch bulk application tasks

    return {"submitted": submitted, "failed": failed, "details": details}
