"""Authentication router: registration, login, OAuth, token refresh."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.security import (
    create_access_token,
    hash_password,
    verify_password,
    verify_token,
)
from app.models.user import User
from app.schemas.user import (
    OAuthRequest,
    RefreshTokenRequest,
    TokenResponse,
    UserCreate,
    UserLogin,
    UserResponse,
)
from app.api.deps import get_current_user

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _build_token_response(user: User) -> dict:
    """Build a TokenResponse dict for the given user."""
    return {
        "access_token": create_access_token({"sub": str(user.id)}),
        "token_type": "bearer",
        "user": UserResponse.model_validate(user),
    }


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(
    payload: UserCreate,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """Register a new user account.

    Creates a new user with the provided email, password, and full name.
    Returns JWT access token and user details upon successful registration.

    Raises:
        HTTPException 409: If a user with the provided email already exists.
    """
    existing = await db.execute(select(User).where(User.email == payload.email))
    if existing.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this email already exists",
        )

    user = User(
        email=payload.email,
        hashed_password=hash_password(payload.password),
        full_name=payload.full_name,
    )
    db.add(user)
    await db.flush()
    await db.refresh(user)
    return _build_token_response(user)


@router.post("/login", response_model=TokenResponse)
async def login(
    payload: UserLogin,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """Authenticate with email and password.

    Validates the user's credentials and returns a JWT access token
    along with the authenticated user's profile information.

    Raises:
        HTTPException 401: If the email or password is incorrect.
        HTTPException 403: If the user account is deactivated.
    """
    result = await db.execute(select(User).where(User.email == payload.email))
    user = result.scalar_one_or_none()

    if user is None or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is deactivated",
        )

    return _build_token_response(user)


@router.post("/oauth/google", response_model=TokenResponse)
async def oauth_google(
    payload: OAuthRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """Handle Google OAuth callback.

    Exchanges a Google OAuth authorization code for VelaHire JWT tokens.
    If the user does not exist, a new account is created automatically.

    Raises:
        HTTPException 501: If Google OAuth is not yet configured.
        HTTPException 400: If the authorization code is invalid.
    """
    if not settings.GOOGLE_CLIENT_ID or not settings.GOOGLE_CLIENT_SECRET:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="Google OAuth integration pending configuration",
        )

    # TODO: Exchange authorization code with Google's token endpoint via httpx
    # 1. POST to https://oauth2.googleapis.com/token with code + client credentials
    # 2. Decode the id_token to extract email, name, sub
    # 3. Find or create the user
    # 4. Return _build_token_response(user)
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Google OAuth token exchange not yet implemented",
    )


@router.post("/oauth/outlook", response_model=TokenResponse)
async def oauth_outlook(
    payload: OAuthRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """Handle Outlook/Microsoft OAuth callback.

    Exchanges a Microsoft OAuth authorization code for VelaHire JWT tokens.
    If the user does not exist, a new account is created automatically.

    Raises:
        HTTPException 501: If Outlook OAuth is not yet configured.
        HTTPException 400: If the authorization code is invalid.
    """
    if not settings.OUTLOOK_CLIENT_ID or not settings.OUTLOOK_CLIENT_SECRET:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="Outlook OAuth integration pending configuration",
        )

    # TODO: Exchange authorization code with Microsoft's token endpoint via httpx
    # 1. POST to https://login.microsoftonline.com/common/oauth2/v2.0/token
    # 2. Decode the id_token to extract email, name, oid
    # 3. Find or create the user
    # 4. Return _build_token_response(user)
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Outlook OAuth token exchange not yet implemented",
    )


@router.post("/refresh-token", response_model=TokenResponse)
async def refresh_token(
    payload: RefreshTokenRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """Refresh JWT access token.

    Accepts a valid refresh token and returns a new access token
    along with the user's profile information.

    Raises:
        HTTPException 401: If the refresh token is invalid, expired, or
            belongs to a non-existent/inactive user.
    """
    try:
        claims = verify_token(payload.refresh_token)
        if claims.get("type") != "refresh":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token type",
            )
        user_id = claims["sub"]
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token",
        ) from exc

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user is None or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
        )

    return _build_token_response(user)


@router.get("/me", response_model=UserResponse)
async def get_me(
    current_user: Annotated[User, Depends(get_current_user)],
) -> User:
    """Get current authenticated user.

    Returns the profile of the currently authenticated user based on
    the JWT bearer token provided in the Authorization header.
    """
    return current_user
