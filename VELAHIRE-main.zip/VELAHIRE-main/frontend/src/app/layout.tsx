import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toast";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "VelaHire - AI Career Co-Pilot",
  description:
    "Automate your job search with AI-powered resume optimization, intelligent job matching, and automated applications. Your career co-pilot for landing dream jobs faster.",
  keywords: [
    "AI job search",
    "resume optimization",
    "career co-pilot",
    "automated applications",
    "ATS optimization",
  ],
  openGraph: {
    title: "VelaHire - AI Career Co-Pilot",
    description: "Land your dream job faster with AI-powered career automation",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.className} bg-background text-foreground`}>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
