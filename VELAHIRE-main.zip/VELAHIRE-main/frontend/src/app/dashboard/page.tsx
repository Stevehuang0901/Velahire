"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Send,
  MessageSquare,
  Calendar,
  Trophy,
  TrendingUp,
  Lightbulb,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const statsCards = [
  {
    title: "Total Applied",
    value: "142",
    change: "+12 this week",
    trend: "up" as const,
    icon: Send,
    color: "text-blue-600",
    bgColor: "bg-blue-100 dark:bg-blue-900/30",
  },
  {
    title: "Responses",
    value: "38",
    change: "+5 this week",
    trend: "up" as const,
    icon: MessageSquare,
    color: "text-emerald-600",
    bgColor: "bg-emerald-100 dark:bg-emerald-900/30",
  },
  {
    title: "Interviews",
    value: "12",
    change: "+3 this week",
    trend: "up" as const,
    icon: Calendar,
    color: "text-purple-600",
    bgColor: "bg-purple-100 dark:bg-purple-900/30",
  },
  {
    title: "Offers",
    value: "3",
    change: "+1 this week",
    trend: "up" as const,
    icon: Trophy,
    color: "text-amber-600",
    bgColor: "bg-amber-100 dark:bg-amber-900/30",
  },
];

const funnelData = [
  { stage: "Applied", count: 142 },
  { stage: "Screened", count: 68 },
  { stage: "Interview", count: 24 },
  { stage: "Offer", count: 3 },
];

const aiInsights = [
  {
    text: "Your resume is missing key DevOps keywords. Adding Docker and Kubernetes could increase matches by 35%.",
  },
  {
    text: "Response rate has improved 15% since you started using tailored cover letters.",
  },
  {
    text: "3 new high-match jobs (90%+) posted today in your target companies. Review them before they fill up.",
  },
  {
    text: "Companies in fintech are hiring 40% more this quarter. Consider expanding your job search to this sector.",
  },
];

const recentApplications = [
  {
    id: 1,
    title: "Senior Frontend Engineer",
    company: "TechCorp",
    status: "Interview",
    matchScore: 95,
    date: "Mar 12, 2026",
  },
  {
    id: 2,
    title: "Full Stack Developer",
    company: "StartupXYZ",
    status: "Applied",
    matchScore: 88,
    date: "Mar 11, 2026",
  },
  {
    id: 3,
    title: "React Developer",
    company: "DesignCo",
    status: "Screened",
    matchScore: 91,
    date: "Mar 10, 2026",
  },
  {
    id: 4,
    title: "Software Engineer",
    company: "BigTech Inc",
    status: "Rejected",
    matchScore: 78,
    date: "Mar 9, 2026",
  },
  {
    id: 5,
    title: "Frontend Architect",
    company: "CloudScale",
    status: "Offer",
    matchScore: 93,
    date: "Mar 8, 2026",
  },
];

const statusColors: Record<string, string> = {
  Applied: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  Screened:
    "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
  Interview:
    "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  Offer:
    "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300",
  Rejected: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

export default function DashboardPage() {
  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <div className="space-y-6">
      {/* Greeting */}
      <div>
        <h1 className="text-2xl font-bold">Welcome back, John</h1>
        <p className="text-muted-foreground">{today}</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statsCards.map((stat) => (
          <Card key={stat.title}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-3xl font-bold">{stat.value}</p>
                </div>
                <div
                  className={`h-12 w-12 rounded-lg ${stat.bgColor} flex items-center justify-center`}
                >
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
              <div className="mt-3 flex items-center gap-1 text-xs">
                {stat.trend === "up" ? (
                  <ArrowUpRight className="h-3 w-3 text-emerald-600" />
                ) : (
                  <ArrowDownRight className="h-3 w-3 text-red-600" />
                )}
                <span
                  className={
                    stat.trend === "up" ? "text-emerald-600" : "text-red-600"
                  }
                >
                  {stat.change}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Two column layout */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Application Funnel */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Application Funnel
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={funnelData}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis dataKey="stage" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip />
                  <Bar
                    dataKey="count"
                    fill="hsl(221.2, 83.2%, 53.3%)"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* AI Insights */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-amber-500" />
              AI Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {aiInsights.map((insight, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 p-3 rounded-lg bg-muted/50"
                >
                  <div className="mt-0.5">
                    <Lightbulb className="h-4 w-4 text-amber-500" />
                  </div>
                  <p className="text-sm text-muted-foreground">{insight.text}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Applications */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Applications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left text-sm text-muted-foreground">
                  <th className="pb-3 font-medium">Job Title</th>
                  <th className="pb-3 font-medium">Company</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium">Match Score</th>
                  <th className="pb-3 font-medium">Date Applied</th>
                </tr>
              </thead>
              <tbody>
                {recentApplications.map((app) => (
                  <tr
                    key={app.id}
                    className="border-b last:border-0 hover:bg-muted/50 transition-colors"
                  >
                    <td className="py-3 font-medium">{app.title}</td>
                    <td className="py-3 text-muted-foreground">{app.company}</td>
                    <td className="py-3">
                      <span
                        className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                          statusColors[app.status] || ""
                        }`}
                      >
                        {app.status}
                      </span>
                    </td>
                    <td className="py-3">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-16 rounded-full bg-muted overflow-hidden">
                          <div
                            className="h-full rounded-full bg-primary"
                            style={{ width: `${app.matchScore}%` }}
                          />
                        </div>
                        <span className="text-sm font-medium">
                          {app.matchScore}%
                        </span>
                      </div>
                    </td>
                    <td className="py-3 text-sm text-muted-foreground">
                      {app.date}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
