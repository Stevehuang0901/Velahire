"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  RefreshCw,
  Search,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Building2,
  DollarSign,
} from "lucide-react";

const mockJobs = [
  {
    id: "1",
    title: "Senior Frontend Engineer",
    company: "TechCorp",
    location: "San Francisco, CA",
    remote: true,
    salary: "$150k - $200k",
    matchScore: 95,
    skills: ["React", "TypeScript", "Next.js", "TailwindCSS"],
    postedDays: 1,
  },
  {
    id: "2",
    title: "Full Stack Developer",
    company: "StartupXYZ",
    location: "New York, NY",
    remote: true,
    salary: "$120k - $160k",
    matchScore: 88,
    skills: ["Node.js", "React", "PostgreSQL", "AWS"],
    postedDays: 2,
  },
  {
    id: "3",
    title: "React Developer",
    company: "DesignCo",
    location: "Austin, TX",
    remote: false,
    salary: "$110k - $140k",
    matchScore: 91,
    skills: ["React", "CSS", "Figma", "Testing"],
    postedDays: 1,
  },
  {
    id: "4",
    title: "Software Engineer",
    company: "BigTech Inc",
    location: "Seattle, WA",
    remote: true,
    salary: "$160k - $220k",
    matchScore: 78,
    skills: ["Java", "React", "Microservices", "Docker"],
    postedDays: 3,
  },
  {
    id: "5",
    title: "Frontend Architect",
    company: "CloudScale",
    location: "Remote",
    remote: true,
    salary: "$170k - $230k",
    matchScore: 93,
    skills: ["React", "Architecture", "GraphQL", "Performance"],
    postedDays: 1,
  },
  {
    id: "6",
    title: "UI Engineer",
    company: "FinanceApp",
    location: "Chicago, IL",
    remote: false,
    salary: "$130k - $170k",
    matchScore: 85,
    skills: ["React", "D3.js", "TypeScript", "Storybook"],
    postedDays: 4,
  },
];

export default function JobsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [locationQuery, setLocationQuery] = useState("");
  const [remoteOnly, setRemoteOnly] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const filteredJobs = mockJobs.filter((job) => {
    const matchesSearch =
      !searchQuery ||
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLocation =
      !locationQuery ||
      job.location.toLowerCase().includes(locationQuery.toLowerCase());
    const matchesRemote = !remoteOnly || job.remote;
    return matchesSearch && matchesLocation && matchesRemote;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Job Matches</h1>
          <p className="text-muted-foreground">
            {filteredJobs.length} jobs matched to your profile
          </p>
        </div>
        <Button variant="outline" className="gap-2">
          <RefreshCw className="h-4 w-4" />
          Refresh
        </Button>
      </div>

      {/* Filter Bar */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4 items-center">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search jobs or companies..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="relative flex-1 min-w-[200px]">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Location..."
                className="pl-9"
                value={locationQuery}
                onChange={(e) => setLocationQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setRemoteOnly(!remoteOnly)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  remoteOnly ? "bg-primary" : "bg-muted"
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    remoteOnly ? "translate-x-6" : "translate-x-1"
                  }`}
                />
              </button>
              <span className="text-sm">Remote only</span>
            </div>
            <select className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm">
              <option value="">Salary Range</option>
              <option value="100-150">$100k - $150k</option>
              <option value="150-200">$150k - $200k</option>
              <option value="200+">$200k+</option>
            </select>
            <select className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm">
              <option value="">Company Size</option>
              <option value="startup">Startup (1-50)</option>
              <option value="mid">Mid-size (51-500)</option>
              <option value="large">Large (500+)</option>
              <option value="enterprise">Enterprise (5000+)</option>
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Job Cards Grid */}
      <div className="grid md:grid-cols-2 gap-4">
        {filteredJobs.map((job) => (
          <Card key={job.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                {/* Company avatar */}
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary font-bold text-lg shrink-0">
                  {job.company.charAt(0)}
                </div>

                <div className="flex-1 min-w-0 space-y-3">
                  {/* Title and match score */}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-semibold text-base">{job.title}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mt-0.5">
                        <Building2 className="h-3.5 w-3.5" />
                        <span>{job.company}</span>
                      </div>
                    </div>

                    {/* Match score circle */}
                    <div className="relative h-14 w-14 shrink-0">
                      <svg
                        className="h-14 w-14 -rotate-90"
                        viewBox="0 0 56 56"
                      >
                        <circle
                          cx="28"
                          cy="28"
                          r="24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="4"
                          className="text-muted"
                        />
                        <circle
                          cx="28"
                          cy="28"
                          r="24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="4"
                          strokeDasharray={`${
                            (job.matchScore / 100) * 150.8
                          } 150.8`}
                          className={
                            job.matchScore >= 90
                              ? "text-emerald-500"
                              : job.matchScore >= 80
                              ? "text-blue-500"
                              : "text-amber-500"
                          }
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-xs font-bold">
                          {job.matchScore}%
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Location and salary */}
                  <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5" />
                      {job.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <DollarSign className="h-3.5 w-3.5" />
                      {job.salary}
                    </span>
                    {job.remote && (
                      <Badge variant="secondary" className="text-xs">
                        Remote
                      </Badge>
                    )}
                  </div>

                  {/* Skills */}
                  <div className="flex flex-wrap gap-1.5">
                    {job.skills.map((skill) => (
                      <Badge
                        key={skill}
                        variant="outline"
                        className="text-xs"
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 pt-1">
                    <Link href={`/dashboard/jobs/${job.id}`}>
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </Link>
                    <Button variant="default" size="sm">
                      Quick Apply
                    </Button>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {job.postedDays}d ago
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-center gap-2">
        <Button
          variant="outline"
          size="sm"
          disabled={currentPage === 1}
          onClick={() => setCurrentPage(currentPage - 1)}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        {[1, 2, 3].map((page) => (
          <Button
            key={page}
            variant={currentPage === page ? "default" : "outline"}
            size="sm"
            onClick={() => setCurrentPage(page)}
          >
            {page}
          </Button>
        ))}
        <Button
          variant="outline"
          size="sm"
          onClick={() => setCurrentPage(currentPage + 1)}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
