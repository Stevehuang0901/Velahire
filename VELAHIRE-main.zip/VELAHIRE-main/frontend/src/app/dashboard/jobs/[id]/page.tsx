"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowLeft,
  MapPin,
  Building2,
  DollarSign,
  Clock,
  Briefcase,
  CheckCircle,
  XCircle,
  FileText,
  Mail,
  MessageSquare,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";

const jobData = {
  title: "Senior Frontend Engineer",
  company: "TechCorp",
  location: "San Francisco, CA",
  type: "Full-time",
  remote: true,
  salary: "$150,000 - $200,000",
  posted: "March 12, 2026",
  matchScore: 95,
  description: `We are looking for a Senior Frontend Engineer to join our growing team. You will be responsible for building and maintaining our web applications using modern JavaScript frameworks. This role involves working closely with designers, backend engineers, and product managers to deliver exceptional user experiences.

The ideal candidate has deep experience with React and TypeScript, a strong understanding of web performance optimization, and a passion for building accessible, responsive user interfaces.`,
  requirements: [
    "5+ years of experience with React and TypeScript",
    "Strong understanding of modern CSS (TailwindCSS, CSS-in-JS)",
    "Experience with Next.js or similar server-side rendering frameworks",
    "Proficiency with state management solutions (Redux, Zustand, Jotai)",
    "Experience with testing frameworks (Jest, Playwright, Cypress)",
    "Strong understanding of web accessibility (WCAG 2.1)",
    "Excellent communication and collaboration skills",
  ],
  responsibilities: [
    "Design and implement complex frontend features and components",
    "Lead code reviews and mentor junior developers",
    "Collaborate with UX/UI designers to implement pixel-perfect interfaces",
    "Optimize application performance and improve Core Web Vitals",
    "Contribute to frontend architecture decisions and technical roadmap",
    "Write comprehensive unit and integration tests",
    "Participate in agile ceremonies and contribute to sprint planning",
  ],
  matchedSkills: ["React", "TypeScript", "Next.js", "TailwindCSS", "Testing"],
  missingSkills: ["Redux", "Cypress"],
  keywordMatch: 87,
};

const tailoredResume = `# John Doe - Senior Frontend Engineer

## Summary
Senior Frontend Engineer with 6+ years of experience building scalable web applications with React, TypeScript, and Next.js. Proven track record of improving performance metrics and mentoring development teams.

## Key Achievements
- Led migration of legacy jQuery application to React/TypeScript, reducing bundle size by 45%
- Improved Core Web Vitals scores by 60% through performance optimization
- Mentored 4 junior developers, all of whom were promoted within 18 months

## Technical Skills
React, TypeScript, Next.js, TailwindCSS, Node.js, GraphQL, Jest, Playwright, AWS, Docker`;

const coverLetter = `Dear Hiring Manager,

I am writing to express my strong interest in the Senior Frontend Engineer position at TechCorp. With over 6 years of experience building production-grade React applications and a deep passion for creating exceptional user experiences, I believe I would be an excellent fit for your team.

In my current role, I have led the development of a complex SaaS platform serving 50,000+ users, where I implemented performance optimizations that improved page load times by 60%. My experience with TypeScript, Next.js, and modern CSS frameworks aligns perfectly with your tech stack requirements.

I am particularly excited about TechCorp's mission to democratize technology access, and I would love the opportunity to contribute to your continued growth.

Best regards,
John Doe`;

const backgroundStatement = `I bring 6+ years of specialized frontend engineering experience, with particular depth in React ecosystem technologies. My career trajectory has focused on building scalable, performant web applications for SaaS companies. Key highlights include leading a major application rewrite that reduced load times by 60%, establishing testing practices that achieved 90% code coverage, and mentoring a team of 4 junior engineers. I hold a B.S. in Computer Science from UC Berkeley and have contributed to several open-source projects in the React ecosystem.`;

export default function JobDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const [mode, setMode] = useState<"copilot" | "autopilot">("copilot");

  return (
    <div className="space-y-6">
      {/* Back button */}
      <Link
        href="/dashboard/jobs"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Jobs
      </Link>

      {/* Job Header */}
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 text-primary font-bold text-xl">
              {jobData.company.charAt(0)}
            </div>
            <div>
              <h1 className="text-2xl font-bold">{jobData.title}</h1>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Building2 className="h-4 w-4" />
                <span>{jobData.company}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <MapPin className="h-4 w-4" />
              {jobData.location}
            </span>
            <Badge variant="secondary">{jobData.type}</Badge>
            {jobData.remote && <Badge variant="outline">Remote</Badge>}
            <span className="flex items-center gap-1">
              <DollarSign className="h-4 w-4" />
              {jobData.salary}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              Posted {jobData.posted}
            </span>
          </div>
        </div>
      </div>

      {/* Two columns */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left column (2/3) */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Job Description</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none text-muted-foreground whitespace-pre-line">
                {jobData.description}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Requirements</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {jobData.requirements.map((req, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />
                    <span className="text-muted-foreground">{req}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Responsibilities</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {jobData.responsibilities.map((resp, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <Briefcase className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <span className="text-muted-foreground">{resp}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Right column (1/3) - Match Analysis */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Match Analysis</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Circular score */}
              <div className="flex justify-center">
                <div className="relative h-28 w-28">
                  <svg
                    className="h-28 w-28 -rotate-90"
                    viewBox="0 0 112 112"
                  >
                    <circle
                      cx="56"
                      cy="56"
                      r="48"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="8"
                      className="text-muted"
                    />
                    <circle
                      cx="56"
                      cy="56"
                      r="48"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="8"
                      strokeDasharray={`${
                        (jobData.matchScore / 100) * 301.6
                      } 301.6`}
                      className="text-emerald-500"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-2xl font-bold">
                      {jobData.matchScore}%
                    </span>
                    <span className="text-xs text-muted-foreground">Match</span>
                  </div>
                </div>
              </div>

              {/* Matched Skills */}
              <div>
                <h4 className="text-sm font-medium mb-2">Matched Skills</h4>
                <div className="flex flex-wrap gap-1.5">
                  {jobData.matchedSkills.map((skill) => (
                    <Badge key={skill} variant="success" className="text-xs">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Missing Skills */}
              <div>
                <h4 className="text-sm font-medium mb-2">Missing Skills</h4>
                <div className="flex flex-wrap gap-1.5">
                  {jobData.missingSkills.map((skill) => (
                    <Badge
                      key={skill}
                      variant="destructive"
                      className="text-xs"
                    >
                      <XCircle className="h-3 w-3 mr-1" />
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Keyword Match */}
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="font-medium">Keyword Match</span>
                  <span className="text-muted-foreground">
                    {jobData.keywordMatch}%
                  </span>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full rounded-full bg-primary transition-all"
                    style={{ width: `${jobData.keywordMatch}%` }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Tabs for AI content */}
      <Tabs defaultValue="resume" className="w-full">
        <TabsList className="w-full justify-start">
          <TabsTrigger value="resume" className="gap-2">
            <FileText className="h-4 w-4" />
            Tailored Resume
          </TabsTrigger>
          <TabsTrigger value="cover" className="gap-2">
            <Mail className="h-4 w-4" />
            Cover Letter
          </TabsTrigger>
          <TabsTrigger value="background" className="gap-2">
            <MessageSquare className="h-4 w-4" />
            Background Statement
          </TabsTrigger>
        </TabsList>

        <TabsContent value="resume">
          <Card>
            <CardContent className="p-6">
              <pre className="whitespace-pre-wrap text-sm text-muted-foreground font-sans leading-relaxed">
                {tailoredResume}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cover">
          <Card>
            <CardContent className="p-6">
              <pre className="whitespace-pre-wrap text-sm text-muted-foreground font-sans leading-relaxed">
                {coverLetter}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="background">
          <Card>
            <CardContent className="p-6">
              <pre className="whitespace-pre-wrap text-sm text-muted-foreground font-sans leading-relaxed">
                {backgroundStatement}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Bottom action bar */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium">Application Mode:</span>
              <button
                onClick={() =>
                  setMode(mode === "copilot" ? "autopilot" : "copilot")
                }
                className="flex items-center gap-2"
              >
                {mode === "copilot" ? (
                  <ToggleLeft className="h-8 w-8 text-primary" />
                ) : (
                  <ToggleRight className="h-8 w-8 text-emerald-500" />
                )}
                <span className="text-sm font-medium">
                  {mode === "copilot" ? "Co-pilot" : "Autopilot"}
                </span>
              </button>
              <span className="text-xs text-muted-foreground">
                {mode === "copilot"
                  ? "Review and confirm each step"
                  : "AI handles the entire process"}
              </span>
            </div>
            <Button variant="gradient" size="lg">
              Apply Now
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
