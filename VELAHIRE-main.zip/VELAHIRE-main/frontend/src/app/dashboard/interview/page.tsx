"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Calendar,
  Building2,
  ChevronDown,
  ChevronUp,
  Play,
  BookOpen,
  Newspaper,
  Users,
  Lightbulb,
  Clock,
  Star,
} from "lucide-react";

const upcomingInterviews = [
  {
    id: 1,
    company: "TechCorp",
    role: "Senior Frontend Engineer",
    date: "March 18, 2026",
    time: "2:00 PM PST",
    type: "Technical",
  },
  {
    id: 2,
    company: "CloudScale",
    role: "Frontend Architect",
    date: "March 20, 2026",
    time: "10:00 AM PST",
    type: "Behavioral",
  },
];

const companyResearch = {
  overview:
    "TechCorp is a leading technology company specializing in cloud-based enterprise solutions. Founded in 2015, they have grown to 2,000+ employees across 5 offices globally. They recently raised $200M in Series D funding.",
  culture:
    "Known for a collaborative and innovation-driven culture. They practice agile development with 2-week sprints. Strong emphasis on work-life balance with flexible hours and remote-first policies. Regular hackathons and learning days.",
  recentNews: [
    "TechCorp acquires AI startup DataMind for $50M (Feb 2026)",
    "Launches new enterprise analytics platform (Jan 2026)",
    "Named in Forbes Best Workplaces 2025",
    "Expands engineering team by 40% in Q4 2025",
  ],
};

const commonQuestions = [
  {
    question: "Tell me about yourself and your experience with React.",
    answer:
      "I have 6+ years of experience building production React applications. In my current role at [Company], I lead the frontend team building a SaaS platform serving 50K+ users. I've driven key initiatives including a migration from class components to hooks/functional components, implementing a comprehensive testing strategy achieving 90% coverage, and optimizing performance that improved Core Web Vitals by 60%.",
  },
  {
    question:
      "Describe a challenging technical problem you solved recently.",
    answer:
      "We had a performance bottleneck where our dashboard was taking 8+ seconds to load. I implemented a combination of code splitting, virtual scrolling for large data sets, and optimized our API calls with React Query for caching. This reduced load times to under 2 seconds and improved our LCP score by 75%.",
  },
  {
    question:
      "How do you approach testing in frontend applications?",
    answer:
      "I advocate for a testing pyramid approach: unit tests with Jest for utility functions and hooks, component tests with React Testing Library for user interactions, and E2E tests with Playwright for critical user flows. I also implement visual regression testing with Chromatic for our component library.",
  },
  {
    question: "How do you handle state management in large applications?",
    answer:
      "I evaluate state management needs based on the specific use case. For server state, I use React Query/TanStack Query for caching and synchronization. For global client state, I prefer Zustand for its simplicity. For complex local state, I use useReducer. I avoid over-engineering state management and keep state as close to where it's used as possible.",
  },
  {
    question: "Tell me about a time you mentored a junior developer.",
    answer:
      "I mentored a junior developer who was struggling with React performance concepts. I created a structured learning plan with weekly pairing sessions, starting from rendering fundamentals to advanced patterns like memo, useMemo, and useCallback. Within 6 months, they were independently building performant features and were promoted to mid-level.",
  },
  {
    question: "How do you ensure web accessibility in your applications?",
    answer:
      "I integrate accessibility from the start: semantic HTML, proper ARIA attributes, keyboard navigation, and color contrast compliance. I use eslint-plugin-jsx-a11y for automated checks, axe DevTools for manual testing, and screen reader testing with VoiceOver/NVDA. We aim for WCAG 2.1 AA compliance.",
  },
  {
    question: "Describe your experience with CI/CD pipelines.",
    answer:
      "I've set up CI/CD pipelines using GitHub Actions and GitLab CI. Our pipeline includes linting, type checking, unit/integration tests, E2E tests, Lighthouse performance audits, and automated deployment to staging/production. I also implemented preview deployments for each PR.",
  },
  {
    question: "How do you stay current with frontend technologies?",
    answer:
      "I follow key thought leaders on Twitter/X, read the React and Next.js blogs, participate in local meetups, and contribute to open source. I also maintain a personal blog where I write about new patterns and techniques. I regularly evaluate new tools but only adopt them when they solve real problems.",
  },
  {
    question: "What is your approach to code reviews?",
    answer:
      "I focus on readability, maintainability, and correctness. I check for proper error handling, accessibility considerations, performance implications, and test coverage. I provide constructive feedback with specific suggestions and links to documentation. I also use code reviews as teaching opportunities.",
  },
  {
    question: "Where do you see yourself in 5 years?",
    answer:
      "I aspire to grow into a Staff/Principal Engineer role where I can have broader technical impact across the organization. I want to continue deepening my expertise in frontend architecture while also expanding into system design and technical leadership. I'm passionate about building engineering culture and mentoring.",
  },
];

const starExamples = [
  {
    title: "Led Performance Optimization",
    situation:
      "Dashboard loading times exceeded 8 seconds, causing user churn.",
    task: "Reduce page load time to under 2 seconds while maintaining feature parity.",
    action:
      "Implemented code splitting, virtual scrolling, API caching with React Query, and optimized bundle size with tree-shaking analysis.",
    result:
      "Reduced load time to 1.8 seconds (78% improvement). User engagement increased by 45% and bounce rate decreased by 60%.",
  },
  {
    title: "Mentored Junior Team",
    situation:
      "Team of 4 junior developers struggling with React best practices and code quality.",
    task: "Elevate team skills and establish coding standards.",
    action:
      "Created structured learning plans, weekly pairing sessions, code review guidelines, and internal documentation.",
    result:
      "All 4 developers were promoted within 18 months. Team velocity increased by 35% and bug rate decreased by 50%.",
  },
  {
    title: "Major Migration Project",
    situation:
      "Legacy jQuery application becoming unmaintainable with growing feature requirements.",
    task: "Migrate to React/TypeScript while maintaining business continuity.",
    action:
      "Designed incremental migration strategy using micro-frontends. Led planning, executed parallel development, and established testing infrastructure.",
    result:
      "Completed migration in 6 months with zero downtime. Bundle size reduced by 45%. Developer productivity doubled.",
  },
];

export default function InterviewPage() {
  const [expandedQuestions, setExpandedQuestions] = useState<Set<number>>(
    new Set()
  );
  const [selectedRole, setSelectedRole] = useState("frontend");

  const toggleQuestion = (index: number) => {
    const next = new Set(expandedQuestions);
    if (next.has(index)) {
      next.delete(index);
    } else {
      next.add(index);
    }
    setExpandedQuestions(next);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Interview Preparation</h1>
        <p className="text-muted-foreground">
          Prepare for your upcoming interviews with AI-powered coaching
        </p>
      </div>

      {/* Upcoming Interviews */}
      <div className="grid md:grid-cols-2 gap-4">
        {upcomingInterviews.map((interview) => (
          <Card key={interview.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Building2 className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{interview.company}</h3>
                      <p className="text-sm text-muted-foreground">
                        {interview.role}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" />
                      {interview.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {interview.time}
                    </span>
                  </div>
                  <Badge variant="secondary">{interview.type}</Badge>
                </div>
                <Button variant="default" size="sm">
                  Prepare
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Company Research */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" />
            Company Research - TechCorp
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h4 className="font-medium mb-2 flex items-center gap-2">
              <Building2 className="h-4 w-4 text-muted-foreground" />
              Overview
            </h4>
            <p className="text-sm text-muted-foreground">
              {companyResearch.overview}
            </p>
          </div>

          <div>
            <h4 className="font-medium mb-2 flex items-center gap-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              Culture
            </h4>
            <p className="text-sm text-muted-foreground">
              {companyResearch.culture}
            </p>
          </div>

          <div>
            <h4 className="font-medium mb-2 flex items-center gap-2">
              <Newspaper className="h-4 w-4 text-muted-foreground" />
              Recent News
            </h4>
            <ul className="space-y-2">
              {companyResearch.recentNews.map((news, i) => (
                <li
                  key={i}
                  className="flex items-start gap-2 text-sm text-muted-foreground"
                >
                  <span className="text-primary mt-1">&#8226;</span>
                  {news}
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Common Questions Accordion */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-amber-500" />
            Common Interview Questions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {commonQuestions.map((q, index) => (
              <div key={index} className="border rounded-lg">
                <button
                  onClick={() => toggleQuestion(index)}
                  className="flex w-full items-center justify-between p-4 text-left"
                >
                  <span className="font-medium text-sm pr-4">
                    {index + 1}. {q.question}
                  </span>
                  {expandedQuestions.has(index) ? (
                    <ChevronUp className="h-4 w-4 shrink-0 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
                  )}
                </button>
                {expandedQuestions.has(index) && (
                  <div className="px-4 pb-4">
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-xs font-medium text-primary mb-2">
                        AI-Suggested Answer:
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {q.answer}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Mock Interview Launcher */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Play className="h-5 w-5 text-primary" />
                Mock Interview
              </h3>
              <p className="text-sm text-muted-foreground">
                Practice with our AI interviewer. Get real-time feedback on your
                responses.
              </p>
              <div className="flex items-center gap-3">
                <label className="text-sm font-medium">Role:</label>
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                >
                  <option value="frontend">Frontend Engineer</option>
                  <option value="fullstack">Full Stack Developer</option>
                  <option value="backend">Backend Engineer</option>
                  <option value="architect">Software Architect</option>
                </select>
              </div>
            </div>
            <Button variant="gradient" size="lg" className="gap-2">
              <Play className="h-5 w-5" />
              Start Mock Interview
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* STAR Examples */}
      <div>
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Star className="h-5 w-5 text-amber-500" />
          STAR Method Examples
        </h2>
        <div className="grid md:grid-cols-3 gap-4">
          {starExamples.map((example, index) => (
            <Card key={index}>
              <CardContent className="p-6 space-y-4">
                <h3 className="font-semibold">{example.title}</h3>

                <div className="space-y-3">
                  <div>
                    <p className="text-xs font-semibold text-blue-600 uppercase tracking-wide">
                      Situation
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      {example.situation}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-purple-600 uppercase tracking-wide">
                      Task
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      {example.task}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-amber-600 uppercase tracking-wide">
                      Action
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      {example.action}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-emerald-600 uppercase tracking-wide">
                      Result
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      {example.result}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
