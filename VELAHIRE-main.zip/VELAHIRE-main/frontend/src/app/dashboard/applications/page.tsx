"use client";

import React, { useState } from "react";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Search,
  ExternalLink,
  MoreHorizontal,
  Send,
  Eye,
  MessageSquare,
  CheckCircle2,
  XCircle,
  Clock,
} from "lucide-react";

const mockApplications = [
  {
    id: "1",
    jobTitle: "Senior Frontend Engineer",
    company: "Stripe",
    status: "interview" as const,
    appliedAt: "2024-03-10",
    mode: "copilot" as const,
    nextStep: "Technical interview on March 15",
  },
  {
    id: "2",
    jobTitle: "Full Stack Developer",
    company: "Vercel",
    status: "screening" as const,
    appliedAt: "2024-03-09",
    mode: "autopilot" as const,
    nextStep: "Waiting for recruiter response",
  },
  {
    id: "3",
    jobTitle: "React Developer",
    company: "Netflix",
    status: "applied" as const,
    appliedAt: "2024-03-08",
    mode: "copilot" as const,
    nextStep: "Application under review",
  },
  {
    id: "4",
    jobTitle: "Software Engineer II",
    company: "Google",
    status: "offer" as const,
    appliedAt: "2024-03-01",
    mode: "copilot" as const,
    nextStep: "Review offer details",
  },
  {
    id: "5",
    jobTitle: "Platform Engineer",
    company: "Datadog",
    status: "rejected" as const,
    appliedAt: "2024-03-03",
    mode: "autopilot" as const,
    nextStep: "Position filled",
  },
  {
    id: "6",
    jobTitle: "Frontend Tech Lead",
    company: "Shopify",
    status: "screening" as const,
    appliedAt: "2024-03-07",
    mode: "copilot" as const,
    nextStep: "Resume review in progress",
  },
  {
    id: "7",
    jobTitle: "UI Engineer",
    company: "Figma",
    status: "applied" as const,
    appliedAt: "2024-03-06",
    mode: "autopilot" as const,
    nextStep: "Application submitted",
  },
  {
    id: "8",
    jobTitle: "Staff Engineer",
    company: "Airbnb",
    status: "interview" as const,
    appliedAt: "2024-02-28",
    mode: "copilot" as const,
    nextStep: "Final round on March 14",
  },
];

const statusConfig: Record<
  string,
  {
    label: string;
    variant:
      | "default"
      | "secondary"
      | "destructive"
      | "outline"
      | "success"
      | "warning";
    icon: React.ElementType;
  }
> = {
  applied: { label: "Applied", variant: "secondary", icon: Send },
  screening: { label: "Screening", variant: "warning", icon: Eye },
  interview: { label: "Interview", variant: "default", icon: MessageSquare },
  offer: { label: "Offer", variant: "success", icon: CheckCircle2 },
  rejected: { label: "Rejected", variant: "destructive", icon: XCircle },
};

const statusFilters = [
  "all",
  "applied",
  "screening",
  "interview",
  "offer",
  "rejected",
];

export default function ApplicationsPage() {
  const [activeFilter, setActiveFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = mockApplications.filter((app) => {
    if (activeFilter !== "all" && app.status !== activeFilter) return false;
    if (
      searchQuery &&
      !app.jobTitle.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !app.company.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const statusCounts = mockApplications.reduce(
    (acc, app) => {
      acc[app.status] = (acc[app.status] || 0) + 1;
      return acc;
    },
    {} as Record<string, number>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Applications</h1>
        <p className="text-muted-foreground">
          Track and manage all your job applications
        </p>
      </div>

      {/* Status Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {Object.entries(statusConfig).map(([key, config]) => {
          const Icon = config.icon;
          return (
            <Card
              key={key}
              className={`cursor-pointer transition-all hover:shadow-md ${
                activeFilter === key ? "ring-2 ring-primary" : ""
              }`}
              onClick={() =>
                setActiveFilter(activeFilter === key ? "all" : key)
              }
            >
              <CardContent className="p-4 flex items-center gap-3">
                <Icon className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-2xl font-bold">
                    {statusCounts[key] || 0}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {config.label}
                  </p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search applications..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {statusFilters.map((filter) => (
            <Button
              key={filter}
              variant={activeFilter === filter ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveFilter(filter)}
              className="capitalize"
            >
              {filter === "all"
                ? "All"
                : statusConfig[filter]?.label || filter}
              {filter !== "all" && statusCounts[filter]
                ? ` (${statusCounts[filter]})`
                : ""}
            </Button>
          ))}
        </div>
      </div>

      {/* Applications Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left text-sm text-muted-foreground">
                  <th className="p-4 font-medium">Position</th>
                  <th className="p-4 font-medium">Company</th>
                  <th className="p-4 font-medium">Status</th>
                  <th className="p-4 font-medium">Mode</th>
                  <th className="p-4 font-medium">Applied</th>
                  <th className="p-4 font-medium">Next Step</th>
                  <th className="p-4 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((app) => {
                  const status = statusConfig[app.status];
                  return (
                    <tr
                      key={app.id}
                      className="border-b last:border-0 hover:bg-muted/50 transition-colors"
                    >
                      <td className="p-4">
                        <p className="font-medium">{app.jobTitle}</p>
                      </td>
                      <td className="p-4 text-muted-foreground">
                        {app.company}
                      </td>
                      <td className="p-4">
                        <Badge variant={status.variant}>{status.label}</Badge>
                      </td>
                      <td className="p-4">
                        <Badge variant="outline" className="capitalize">
                          {app.mode}
                        </Badge>
                      </td>
                      <td className="p-4 text-sm text-muted-foreground">
                        {new Date(app.appliedAt).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                        })}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {app.nextStep}
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && (
            <div className="text-center py-12">
              <Send className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold">No applications found</h3>
              <p className="text-muted-foreground">
                {searchQuery
                  ? "Try a different search query"
                  : "Start applying to jobs to see them here"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
