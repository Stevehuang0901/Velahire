"use client";

import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Upload,
  FileText,
  Star,
  Edit3,
  Trash2,
  Lightbulb,
  ArrowRight,
  CheckCircle,
} from "lucide-react";

const resumeVersions = [
  {
    id: 1,
    name: "General Resume v3",
    date: "Mar 12, 2026",
    atsScore: 92,
    isPrimary: true,
  },
  {
    id: 2,
    name: "Frontend Engineer - TechCorp",
    date: "Mar 11, 2026",
    atsScore: 95,
    isPrimary: false,
  },
  {
    id: 3,
    name: "Full Stack - Startup",
    date: "Mar 9, 2026",
    atsScore: 87,
    isPrimary: false,
  },
  {
    id: 4,
    name: "General Resume v2",
    date: "Mar 5, 2026",
    atsScore: 78,
    isPrimary: false,
  },
];

const atsBreakdown = {
  overall: 92,
  categories: [
    { name: "Formatting", score: 95, color: "bg-emerald-500" },
    { name: "Keywords", score: 88, color: "bg-blue-500" },
    { name: "Quantification", score: 90, color: "bg-purple-500" },
    { name: "Layout", score: 94, color: "bg-amber-500" },
  ],
};

const suggestions = [
  "Add more quantifiable achievements to your work experience section",
  "Include Docker and Kubernetes keywords to match 35% more DevOps roles",
  "Your summary could be more targeted - consider tailoring it per application",
  "Add a Projects section to showcase your open-source contributions",
  "Consider adding certifications such as AWS or Google Cloud",
];

const careerPaths = [
  {
    title: "Frontend Architect",
    match: 92,
    timeline: "1-2 years",
    skills: ["System Design", "Performance", "Team Leadership"],
  },
  {
    title: "Engineering Manager",
    match: 78,
    timeline: "2-3 years",
    skills: ["People Management", "Strategy", "Hiring"],
  },
  {
    title: "Staff Engineer",
    match: 85,
    timeline: "2-4 years",
    skills: ["Cross-team Impact", "Architecture", "Mentoring"],
  },
];

export default function ResumePage() {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    // TODO: Handle file upload
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Resume Management</h1>
        <p className="text-muted-foreground">
          Upload, manage, and optimize your resumes
        </p>
      </div>

      {/* Upload Zone */}
      <Card>
        <CardContent className="p-6">
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors cursor-pointer ${
              isDragging
                ? "border-primary bg-primary/5"
                : "border-muted-foreground/25 hover:border-primary/50"
            }`}
          >
            <Upload
              className={`h-12 w-12 mx-auto mb-4 ${
                isDragging ? "text-primary" : "text-muted-foreground"
              }`}
            />
            <h3 className="text-lg font-semibold mb-1">
              Drag & drop your resume or click to browse
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              Accepted formats: PDF, DOCX, TXT (Max 10MB)
            </p>
            <Button variant="outline">Browse Files</Button>
          </div>
        </CardContent>
      </Card>

      {/* Two columns */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Resume Versions */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Resume Versions</h2>
          {resumeVersions.map((resume) => (
            <Card key={resume.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <FileText className="h-10 w-10 text-primary mt-0.5" />
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{resume.name}</h3>
                        {resume.isPrimary && (
                          <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {resume.date}
                      </p>
                      <div className="mt-2">
                        <Badge
                          variant={
                            resume.atsScore >= 90
                              ? "success"
                              : resume.atsScore >= 80
                              ? "secondary"
                              : "warning"
                          }
                        >
                          ATS Score: {resume.atsScore}
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    {!resume.isPrimary && (
                      <Button variant="ghost" size="sm" title="Set as primary">
                        <Star className="h-4 w-4" />
                      </Button>
                    )}
                    <Button variant="ghost" size="sm">
                      <Edit3 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* ATS Score Breakdown */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">ATS Score Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Overall score circle */}
              <div className="flex justify-center">
                <div className="relative h-32 w-32">
                  <svg
                    className="h-32 w-32 -rotate-90"
                    viewBox="0 0 128 128"
                  >
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="8"
                      className="text-muted"
                    />
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="8"
                      strokeDasharray={`${(atsBreakdown.overall / 100) * 351.9} 351.9`}
                      className="text-emerald-500"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-3xl font-bold">
                      {atsBreakdown.overall}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      Overall
                    </span>
                  </div>
                </div>
              </div>

              {/* Category bars */}
              <div className="space-y-4">
                {atsBreakdown.categories.map((cat) => (
                  <div key={cat.name} className="space-y-1.5">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">{cat.name}</span>
                      <span className="text-muted-foreground">
                        {cat.score}/100
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-muted overflow-hidden">
                      <div
                        className={`h-full rounded-full ${cat.color} transition-all`}
                        style={{ width: `${cat.score}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Suggestions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Suggestions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {suggestions.map((suggestion, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-2 text-sm"
                  >
                    <Lightbulb className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
                    <span className="text-muted-foreground">{suggestion}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Career Path Section */}
      <div>
        <h2 className="text-lg font-semibold mb-4">Suggested Career Paths</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {careerPaths.map((path) => (
            <Card
              key={path.title}
              className="hover:shadow-md transition-shadow"
            >
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{path.title}</h3>
                  <Badge variant="secondary">{path.match}% match</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Timeline: {path.timeline}
                </p>
                <div className="space-y-2">
                  <p className="text-xs font-medium text-muted-foreground">
                    Skills to develop:
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {path.skills.map((skill) => (
                      <Badge key={skill} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
                <Button variant="ghost" size="sm" className="w-full gap-1">
                  Explore Path
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
