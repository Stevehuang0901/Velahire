"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  User,
  Mail,
  Camera,
  Link2,
  CheckCircle,
  XCircle,
  Zap,
  Shield,
  Bell,
  Download,
  Trash2,
  AlertTriangle,
  Clock,
  Sliders,
} from "lucide-react";

export default function SettingsPage() {
  const [name, setName] = useState("John Doe");
  const [email, setEmail] = useState("john@example.com");
  const [dailyLimit, setDailyLimit] = useState(10);
  const [applyMode, setApplyMode] = useState<"copilot" | "autopilot">(
    "copilot"
  );
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const [notifications, setNotifications] = useState({
    newMatches: true,
    applicationUpdates: true,
    interviewInvites: true,
    weeklyReport: false,
  });

  const connectedAccounts = [
    {
      name: "Gmail",
      icon: Mail,
      connected: true,
      email: "john@gmail.com",
    },
    {
      name: "Outlook",
      icon: Mail,
      connected: false,
      email: null,
    },
    {
      name: "LinkedIn",
      icon: Link2,
      connected: true,
      email: "linkedin.com/in/johndoe",
    },
  ];

  const toggleNotification = (key: keyof typeof notifications) => {
    setNotifications((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-muted-foreground">
          Manage your account and preferences
        </p>
      </div>

      {/* Profile Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <User className="h-5 w-5" />
            Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Avatar */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="h-20 w-20 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-2xl font-bold">
                JD
              </div>
              <button className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full bg-card border shadow-sm flex items-center justify-center hover:bg-muted transition-colors">
                <Camera className="h-4 w-4" />
              </button>
            </div>
            <div>
              <p className="font-medium">Profile Photo</p>
              <p className="text-sm text-muted-foreground">
                JPG, PNG or GIF. Max 5MB.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Full Name</label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Email Address</label>
              <Input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                type="email"
              />
            </div>
          </div>

          <Button variant="default">Save Changes</Button>
        </CardContent>
      </Card>

      {/* Connected Accounts */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Link2 className="h-5 w-5" />
            Connected Accounts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {connectedAccounts.map((account) => (
              <div
                key={account.name}
                className="flex items-center justify-between p-4 rounded-lg border"
              >
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                    <account.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="font-medium">{account.name}</p>
                    {account.connected && (
                      <p className="text-xs text-muted-foreground">
                        {account.email}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {account.connected ? (
                    <>
                      <Badge variant="success" className="gap-1">
                        <CheckCircle className="h-3 w-3" />
                        Connected
                      </Badge>
                      <Button variant="outline" size="sm">
                        Disconnect
                      </Button>
                    </>
                  ) : (
                    <>
                      <Badge variant="secondary" className="gap-1">
                        <XCircle className="h-3 w-3" />
                        Not Connected
                      </Badge>
                      <Button variant="default" size="sm">
                        Connect
                      </Button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Auto-Apply Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Sliders className="h-5 w-5" />
            Auto-Apply Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Mode selector */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Application Mode</label>
            <div className="flex gap-3">
              <button
                onClick={() => setApplyMode("copilot")}
                className={`flex-1 p-4 rounded-lg border-2 text-left transition-colors ${
                  applyMode === "copilot"
                    ? "border-primary bg-primary/5"
                    : "border-muted hover:border-muted-foreground/20"
                }`}
              >
                <p className="font-medium">Co-pilot</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Review and approve each application before submission
                </p>
              </button>
              <button
                onClick={() => setApplyMode("autopilot")}
                className={`flex-1 p-4 rounded-lg border-2 text-left transition-colors ${
                  applyMode === "autopilot"
                    ? "border-primary bg-primary/5"
                    : "border-muted hover:border-muted-foreground/20"
                }`}
              >
                <p className="font-medium">Autopilot</p>
                <p className="text-xs text-muted-foreground mt-1">
                  AI automatically applies to matching jobs on your behalf
                </p>
              </button>
            </div>
          </div>

          {/* Daily limit slider */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">
                Daily Application Limit
              </label>
              <span className="text-sm font-bold text-primary">
                {dailyLimit} / day
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="50"
              value={dailyLimit}
              onChange={(e) => setDailyLimit(Number(e.target.value))}
              className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>1</span>
              <span>25</span>
              <span>50</span>
            </div>
          </div>

          {/* Schedule */}
          <div className="space-y-2">
            <label className="text-sm font-medium">
              Preferred Schedule
            </label>
            <div className="flex items-center gap-3">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <select className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm flex-1">
                <option>Weekdays 9 AM - 5 PM</option>
                <option>Weekdays 6 AM - 12 PM</option>
                <option>Every day, all hours</option>
                <option>Custom schedule</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Notifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              {
                key: "newMatches" as const,
                label: "New Job Matches",
                description: "Get notified when new jobs match your profile",
              },
              {
                key: "applicationUpdates" as const,
                label: "Application Updates",
                description: "Status changes on your submitted applications",
              },
              {
                key: "interviewInvites" as const,
                label: "Interview Invites",
                description:
                  "Notifications when you receive interview invitations",
              },
              {
                key: "weeklyReport" as const,
                label: "Weekly Report",
                description:
                  "Weekly summary of your job search activity and insights",
              },
            ].map((item) => (
              <div
                key={item.key}
                className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div>
                  <p className="font-medium text-sm">{item.label}</p>
                  <p className="text-xs text-muted-foreground">
                    {item.description}
                  </p>
                </div>
                <button
                  onClick={() => toggleNotification(item.key)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    notifications[item.key] ? "bg-primary" : "bg-muted"
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      notifications[item.key]
                        ? "translate-x-6"
                        : "translate-x-1"
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Subscription */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Subscription
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 rounded-lg border bg-muted/30">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg gradient-primary flex items-center justify-center">
                <Zap className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="font-semibold">Pro Plan</p>
                <p className="text-sm text-muted-foreground">
                  $29/month - Renews March 28, 2026
                </p>
              </div>
            </div>
            <Button variant="gradient">Upgrade to Premium</Button>
          </div>
        </CardContent>
      </Card>

      {/* Privacy & Data */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Privacy & Data
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg border">
            <div>
              <p className="font-medium">Export Your Data</p>
              <p className="text-sm text-muted-foreground">
                Download all your data including resumes, applications, and
                settings
              </p>
            </div>
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Export Data
            </Button>
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg border border-destructive/20">
            <div>
              <p className="font-medium text-destructive">Delete Account</p>
              <p className="text-sm text-muted-foreground">
                Permanently delete your account and all associated data
              </p>
            </div>
            {!showDeleteConfirm ? (
              <Button
                variant="destructive"
                className="gap-2"
                onClick={() => setShowDeleteConfirm(true)}
              >
                <Trash2 className="h-4 w-4" />
                Delete Account
              </Button>
            ) : (
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 text-xs text-destructive mr-2">
                  <AlertTriangle className="h-3.5 w-3.5" />
                  Are you sure?
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowDeleteConfirm(false)}
                >
                  Cancel
                </Button>
                <Button variant="destructive" size="sm">
                  Confirm Delete
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
