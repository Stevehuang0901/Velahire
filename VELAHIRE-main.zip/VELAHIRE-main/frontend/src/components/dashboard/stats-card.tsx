"use client";
import { type LucideIcon, TrendingUp, TrendingDown } from "lucide-react";

const colorMap: Record<string, { bg: string; icon: string }> = {
  blue: { bg: "bg-blue-50", icon: "text-blue-600" },
  green: { bg: "bg-green-50", icon: "text-green-600" },
  purple: { bg: "bg-purple-50", icon: "text-purple-600" },
  amber: { bg: "bg-amber-50", icon: "text-amber-600" },
};

interface StatsCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  trend: number;
  color?: string;
}

export function StatsCard({ title, value, icon: Icon, trend, color = "blue" }: StatsCardProps) {
  const colors = colorMap[color] || colorMap.blue;
  const isPositive = trend >= 0;

  return (
    <div className="bg-white rounded-xl border p-5">
      <div className="flex items-center justify-between mb-3">
        <div className={`w-10 h-10 rounded-lg ${colors.bg} flex items-center justify-center`}>
          <Icon className={`h-5 w-5 ${colors.icon}`} />
        </div>
        <div className={`flex items-center gap-1 text-xs font-medium ${isPositive ? "text-green-600" : "text-red-600"}`}>
          {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
          {Math.abs(trend)}%
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
      <p className="text-sm text-gray-500 mt-1">{title}</p>
    </div>
  );
}
