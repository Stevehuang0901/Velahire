const statusColors: Record<string, string> = {
  applied: "bg-blue-100 text-blue-700",
  interview: "bg-purple-100 text-purple-700",
  offer: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
  screening: "bg-yellow-100 text-yellow-700",
};

const data = [
  { title: "Senior Backend Engineer", company: "TechCorp", status: "interview", score: 92, date: "Mar 10" },
  { title: "Full Stack Developer", company: "StartupAI", status: "applied", score: 87, date: "Mar 9" },
  { title: "ML Engineer", company: "DataFlow", status: "screening", score: 78, date: "Mar 8" },
  { title: "DevOps Engineer", company: "CloudScale", status: "offer", score: 84, date: "Mar 7" },
  { title: "Product Manager", company: "InnovateCo", status: "rejected", score: 71, date: "Mar 5" },
];

export function RecentApplications() {
  return (
    <div className="bg-white rounded-xl border overflow-hidden">
      <div className="p-4 border-b"><h3 className="font-semibold text-gray-900">Recent Applications</h3></div>
      <table className="w-full">
        <thead className="bg-gray-50"><tr>
          <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">Job</th>
          <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">Company</th>
          <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">Status</th>
          <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">Match</th>
          <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase">Date</th>
        </tr></thead>
        <tbody className="divide-y">
          {data.map((app, i) => (
            <tr key={i} className="hover:bg-gray-50">
              <td className="px-4 py-3 text-sm font-medium text-gray-900">{app.title}</td>
              <td className="px-4 py-3 text-sm text-gray-600">{app.company}</td>
              <td className="px-4 py-3"><span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[app.status]}`}>{app.status}</span></td>
              <td className="px-4 py-3 text-sm font-medium text-gray-900">{app.score}%</td>
              <td className="px-4 py-3 text-sm text-gray-500">{app.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
