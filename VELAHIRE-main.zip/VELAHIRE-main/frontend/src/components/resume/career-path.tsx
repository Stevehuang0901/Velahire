import { ArrowRight } from "lucide-react";

interface CareerPathProps {
  currentRole: string;
  suggestedPaths: Array<{
    role: string;
    timeframe: string;
    skills: string[];
    probability: number;
  }>;
}

export function CareerPath({ currentRole, suggestedPaths }: CareerPathProps) {
  return (
    <div className="bg-white rounded-xl border p-6">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Career Path Suggestions</h2>
      <div className="flex flex-col lg:flex-row items-start gap-4">
        <div className="bg-blue-600 text-white px-4 py-3 rounded-lg font-medium text-center min-w-[180px]">
          <p className="text-xs text-blue-200">Current Role</p>
          <p className="font-semibold">{currentRole}</p>
        </div>

        <div className="flex flex-col gap-3 flex-1 w-full">
          {suggestedPaths.map((path, i) => (
            <div key={i} className="flex items-center gap-3 w-full">
              <ArrowRight className="h-5 w-5 text-gray-400 flex-shrink-0" />
              <div className="border rounded-lg p-3 flex-1 hover:shadow-sm transition">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-gray-900">{path.role}</h3>
                  <span className="text-xs text-gray-500">{path.timeframe}</span>
                </div>
                <div className="flex flex-wrap gap-1 mb-2">
                  {path.skills.map((s) => <span key={s} className="bg-purple-50 text-purple-700 px-2 py-0.5 rounded text-xs">{s}</span>)}
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-1.5 bg-gray-100 rounded-full flex-1 overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: `${path.probability}%` }} />
                  </div>
                  <span className="text-xs text-gray-500 font-medium">{path.probability}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
