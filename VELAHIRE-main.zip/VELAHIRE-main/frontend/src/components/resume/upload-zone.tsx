"use client";
import { useCallback, useState } from "react";
import { Upload, FileText, X } from "lucide-react";

interface UploadZoneProps {
  onUpload: (file: File) => void;
}

export function UploadZone({ onUpload }: UploadZoneProps) {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped) { setFile(dropped); onUpload(dropped); }
  }, [onUpload]);

  const handleSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) { setFile(selected); onUpload(selected); }
  }, [onUpload]);

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
      className={`border-2 border-dashed rounded-xl p-8 text-center transition ${isDragging ? "border-blue-500 bg-blue-50" : "border-gray-300 bg-white hover:border-blue-400"}`}
    >
      {file ? (
        <div className="flex items-center justify-center gap-3">
          <FileText className="h-8 w-8 text-blue-600" />
          <div className="text-left">
            <p className="font-medium text-gray-900">{file.name}</p>
            <p className="text-sm text-gray-500">{(file.size / 1024).toFixed(1)} KB</p>
          </div>
          <button onClick={() => setFile(null)} className="text-gray-400 hover:text-red-500"><X className="h-5 w-5" /></button>
        </div>
      ) : (
        <>
          <Upload className="h-10 w-10 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-700 font-medium">Drag & drop your resume here</p>
          <p className="text-sm text-gray-500 mt-1">or <label className="text-blue-600 cursor-pointer hover:underline">click to browse<input type="file" accept=".pdf,.docx,.doc,.txt" onChange={handleSelect} className="hidden" /></label></p>
          <p className="text-xs text-gray-400 mt-2">Supports PDF, DOCX, DOC, TXT (max 10MB)</p>
        </>
      )}
    </div>
  );
}
