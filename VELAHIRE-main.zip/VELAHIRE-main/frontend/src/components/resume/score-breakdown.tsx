import { Lightbulb } from "lucide-react";

interface ScoreBreakdownProps {
  overallScore: number;
  formatting: number;
  keywords: number;
  quantification: number;
  layout: number;
  suggestions: string[];
}

export function ScoreBreakdown({ overallScore, formatting, keywords, quantification, layout, suggestions }: ScoreBreakdownProps) {
  const scoreColor = overallScore >= 8 ? "text-green-600 border-green-400" : overallScore >= 6 ? "text-amber-600 border-amber-400" : "text-red-600 border-red-400";

  const categories = [
    { name: "Formatting", score: formatting },
    { name: "Keywords", score: keywords },
    { name: "Quantification", score: quantification },
    { name: "Layout", score: layout },
  ];

  return (
    <div className="bg-white rounded-xl border p-6 space-y-6">
      <h2 className="text-lg font-semibold text-gray-900">ATS Score</h2>

      <div className="flex justify-center">
        <div className={`w-24 h-24 rounded-full border-4 flex items-center justify-center ${scoreColor}`}>
          <span className="text-2xl font-bold">{overallScore}</span>
          <span className="text-sm text-gray-500">/10</span>
        </div>
      </div>

      <div className="space-y-3">
        {categories.map((cat) => (
          <div key={cat.name}>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-600">{cat.name}</span>
              <span className="font-medium text-gray-900">{cat.score}/10</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div className={`h-full rounded-full ${cat.score >= 8 ? "bg-green-500" : cat.score >= 6 ? "bg-amber-500" : "bg-red-500"}`} style={{ width: `${cat.score * 10}%` }} />
            </div>
          </div>
        ))}
      </div>

      <div>
        <h3 className="text-sm font-medium text-gray-900 mb-2 flex items-center gap-1"><Lightbulb className="h-4 w-4 text-amber-500" /> Suggestions</h3>
        <ul className="space-y-2">
          {suggestions.map((s, i) => <li key={i} className="text-sm text-gray-600 bg-amber-50 rounded-lg p-2">{s}</li>)}
        </ul>
      </div>
    </div>
  );
}
