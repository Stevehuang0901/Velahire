"use client";

import React, { useState } from "react";
import { Bell, Search, ChevronDown, ChevronRight, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useStore } from "@/lib/store";
import { cn, getInitials } from "@/lib/utils";

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface NavbarProps {
  breadcrumbs?: BreadcrumbItem[];
  notificationCount?: number;
}

export function Navbar({ breadcrumbs = [], notificationCount = 3 }: NavbarProps) {
  const user = useStore((s) => s.user);
  const logout = useStore((s) => s.logout);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <header className="flex h-16 items-center justify-between border-b bg-card px-6">
      {/* Breadcrumb on left */}
      <nav className="flex items-center gap-1 text-sm text-muted-foreground">
        {breadcrumbs.length > 0 ? (
          breadcrumbs.map((crumb, index) => (
            <React.Fragment key={index}>
              {index > 0 && <ChevronRight className="h-4 w-4" />}
              <span
                className={cn(
                  index === breadcrumbs.length - 1
                    ? "font-medium text-foreground"
                    : "hover:text-foreground cursor-pointer"
                )}
              >
                {crumb.label}
              </span>
            </React.Fragment>
          ))
        ) : (
          <span className="font-medium text-foreground">Dashboard</span>
        )}
      </nav>

      {/* Search input in center */}
      <div className="flex-1 max-w-md mx-8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search jobs, companies, applications..."
            className="pl-10 bg-muted/50"
          />
        </div>
      </div>

      {/* Right side: notifications + user */}
      <div className="flex items-center gap-3">
        {/* Notification bell with badge count */}
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {notificationCount > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] text-white">
              {notificationCount > 9 ? "9+" : notificationCount}
            </span>
          )}
        </Button>

        {/* User avatar dropdown */}
        <div className="relative">
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-muted transition-colors"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-semibold">
              {user ? getInitials(user.name) : <User className="h-4 w-4" />}
            </div>
            <span className="hidden md:block text-sm font-medium">
              {user?.name || "Guest"}
            </span>
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          </button>

          {dropdownOpen && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setDropdownOpen(false)}
              />
              <div className="absolute right-0 top-full mt-1 z-50 w-48 rounded-md border bg-card shadow-lg">
                <div className="p-2">
                  <div className="px-3 py-2 border-b mb-1">
                    <p className="text-sm font-medium">{user?.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {user?.email}
                    </p>
                  </div>
                  <button
                    className="w-full text-left px-3 py-2 text-sm rounded hover:bg-muted transition-colors"
                    onClick={() => setDropdownOpen(false)}
                  >
                    Profile
                  </button>
                  <button
                    className="w-full text-left px-3 py-2 text-sm rounded hover:bg-muted transition-colors"
                    onClick={() => setDropdownOpen(false)}
                  >
                    Settings
                  </button>
                  <Separator />
                  <button
                    className="w-full text-left px-3 py-2 text-sm rounded text-destructive hover:bg-muted transition-colors"
                    onClick={() => {
                      logout();
                      setDropdownOpen(false);
                    }}
                  >
                    Log Out
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

function Separator() {
  return <div className="my-1 h-px bg-border" />;
}
