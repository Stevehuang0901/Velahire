import Link from "next/link";
import { MapPin, Wifi } from "lucide-react";

interface JobCardProps {
  job: {
    id: string;
    title: string;
    company: string;
    location: string;
    salary: string;
    matchScore: number;
    skills: string[];
    isRemote: boolean;
    postedDate: string;
  };
}

export function JobCard({ job }: JobCardProps) {
  const scoreColor = job.matchScore >= 85 ? "text-green-600 bg-green-50 border-green-200" : job.matchScore >= 70 ? "text-amber-600 bg-amber-50 border-amber-200" : "text-red-600 bg-red-50 border-red-200";

  return (
    <div className="bg-white rounded-xl border p-5 hover:shadow-md transition">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-sm">{job.company[0]}</div>
          <div>
            <h3 className="font-semibold text-gray-900">{job.title}</h3>
            <p className="text-sm text-gray-500">{job.company}</p>
          </div>
        </div>
        <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center text-sm font-bold ${scoreColor}`}>{job.matchScore}%</div>
      </div>

      <div className="flex flex-wrap items-center gap-3 text-sm text-gray-500 mb-3">
        <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {job.location}</span>
        <span>{job.salary}</span>
        {job.isRemote && <span className="flex items-center gap-1 text-green-600"><Wifi className="h-3.5 w-3.5" /> Remote</span>}
      </div>

      <div className="flex flex-wrap gap-1.5 mb-4">
        {job.skills.slice(0, 4).map((skill) => (
          <span key={skill} className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded text-xs font-medium">{skill}</span>
        ))}
      </div>

      <div className="flex gap-2">
        <Link href={`/dashboard/jobs/${job.id}`} className="flex-1 text-center border border-gray-300 text-gray-700 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 transition">View Details</Link>
        <button className="flex-1 bg-blue-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">Quick Apply</button>
      </div>

      <p className="text-xs text-gray-400 mt-2">{job.postedDate}</p>
    </div>
  );
}
