interface MatchAnalysisProps {
  score: number;
  matchedSkills: string[];
  missingSkills: string[];
  keywordMatch: number;
}

export function MatchAnalysis({ score, matchedSkills, missingSkills, keywordMatch }: MatchAnalysisProps) {
  const scoreColor = score >= 85 ? "text-green-600 border-green-400" : score >= 70 ? "text-amber-600 border-amber-400" : "text-red-600 border-red-400";

  return (
    <div className="bg-white rounded-xl border p-6">
      <h3 className="font-semibold text-gray-900 mb-4">Match Analysis</h3>
      <div className="flex justify-center mb-6">
        <div className={`w-24 h-24 rounded-full border-4 flex items-center justify-center ${scoreColor}`}>
          <span className="text-2xl font-bold">{score}%</span>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-2">Matched Skills</h4>
          <div className="flex flex-wrap gap-1.5">
            {matchedSkills.map((s) => <span key={s} className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-xs font-medium">{s}</span>)}
          </div>
        </div>
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-2">Missing Skills</h4>
          <div className="flex flex-wrap gap-1.5">
            {missingSkills.map((s) => <span key={s} className="bg-red-50 text-red-600 border border-red-200 px-2 py-0.5 rounded text-xs font-medium">{s}</span>)}
          </div>
        </div>
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-600">Keyword Match</span>
            <span className="font-medium text-gray-900">{keywordMatch}%</span>
          </div>
          <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full bg-blue-600 rounded-full" style={{ width: `${keywordMatch}%` }} />
          </div>
        </div>
      </div>
    </div>
  );
}
