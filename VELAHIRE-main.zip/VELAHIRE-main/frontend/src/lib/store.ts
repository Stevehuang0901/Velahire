import { create } from "zustand";
import { devtools, persist } from "zustand/middleware";

// Types
export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role: "job_seeker" | "employer" | "admin";
}

export interface Resume {
  id: string;
  filename: string;
  uploadedAt: string;
  score?: number;
  status: "processing" | "analyzed" | "error";
  url?: string;
}

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary?: string;
  matchScore?: number;
  skills: string[];
  isRemote: boolean;
  postedDate: string;
  description?: string;
  type?: string;
}

export interface JobFilters {
  search: string;
  location: string;
  remote: boolean | null;
  salaryMin: number | null;
  salaryMax: number | null;
  skills: string[];
  sortBy: "relevance" | "date" | "salary";
}

export interface Application {
  id: string;
  jobId: string;
  jobTitle: string;
  company: string;
  status: "applied" | "screening" | "interview" | "offer" | "rejected";
  matchScore: number;
  appliedDate: string;
  lastUpdated: string;
}

export interface ApplicationStats {
  total: number;
  applied: number;
  screening: number;
  interview: number;
  offer: number;
  rejected: number;
}

// Store slices
interface UserSlice {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (user: User, token: string) => void;
  logout: () => void;
  setUser: (user: User) => void;
}

interface ResumeSlice {
  resumes: Resume[];
  selectedResume: Resume | null;
  setResumes: (resumes: Resume[]) => void;
  addResume: (resume: Resume) => void;
  removeResume: (id: string) => void;
  setSelectedResume: (resume: Resume | null) => void;
}

interface JobSlice {
  jobs: Job[];
  filters: JobFilters;
  selectedJob: Job | null;
  setJobs: (jobs: Job[]) => void;
  setFilters: (filters: Partial<JobFilters>) => void;
  setSelectedJob: (job: Job | null) => void;
}

interface ApplicationSlice {
  applications: Application[];
  stats: ApplicationStats;
  setApplications: (applications: Application[]) => void;
  updateStatus: (id: string, status: Application["status"]) => void;
}

type StoreState = UserSlice & ResumeSlice & JobSlice & ApplicationSlice;

const defaultFilters: JobFilters = {
  search: "",
  location: "",
  remote: null,
  salaryMin: null,
  salaryMax: null,
  skills: [],
  sortBy: "relevance",
};

const defaultStats: ApplicationStats = {
  total: 0,
  applied: 0,
  screening: 0,
  interview: 0,
  offer: 0,
  rejected: 0,
};

function computeStats(applications: Application[]): ApplicationStats {
  return applications.reduce(
    (acc, app) => {
      acc.total += 1;
      acc[app.status] = (acc[app.status] || 0) + 1;
      return acc;
    },
    { ...defaultStats }
  );
}

export const useStore = create<StoreState>()(
  devtools(
    persist(
      (set) => ({
        // User slice
        user: null,
        token: null,
        isAuthenticated: false,
        login: (user: User, token: string) => {
          localStorage.setItem("token", token);
          set({ user, token, isAuthenticated: true });
        },
        logout: () => {
          localStorage.removeItem("token");
          localStorage.removeItem("user");
          set({ user: null, token: null, isAuthenticated: false });
        },
        setUser: (user: User) => set({ user }),

        // Resume slice
        resumes: [],
        selectedResume: null,
        setResumes: (resumes: Resume[]) => set({ resumes }),
        addResume: (resume: Resume) =>
          set((state) => ({ resumes: [...state.resumes, resume] })),
        removeResume: (id: string) =>
          set((state) => ({
            resumes: state.resumes.filter((r) => r.id !== id),
            selectedResume:
              state.selectedResume?.id === id ? null : state.selectedResume,
          })),
        setSelectedResume: (resume: Resume | null) =>
          set({ selectedResume: resume }),

        // Job slice
        jobs: [],
        filters: defaultFilters,
        selectedJob: null,
        setJobs: (jobs: Job[]) => set({ jobs }),
        setFilters: (filters: Partial<JobFilters>) =>
          set((state) => ({
            filters: { ...state.filters, ...filters },
          })),
        setSelectedJob: (job: Job | null) => set({ selectedJob: job }),

        // Application slice
        applications: [],
        stats: defaultStats,
        setApplications: (applications: Application[]) =>
          set({
            applications,
            stats: computeStats(applications),
          }),
        updateStatus: (id: string, status: Application["status"]) =>
          set((state) => {
            const updated = state.applications.map((app) =>
              app.id === id
                ? { ...app, status, lastUpdated: new Date().toISOString() }
                : app
            );
            return {
              applications: updated,
              stats: computeStats(updated),
            };
          }),
      }),
      {
        name: "velahire-store",
        partialize: (state) => ({
          user: state.user,
          token: state.token,
          isAuthenticated: state.isAuthenticated,
        }),
      }
    )
  )
);
