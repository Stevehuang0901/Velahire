import axios, { AxiosError, InternalAxiosRequestConfig } from "axios";

const api = axios.create({
  baseURL: "/api/v1",
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 30000,
});

// Request interceptor: attach auth token from localStorage
api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    if (typeof window !== "undefined") {
      const token = localStorage.getItem("token");
      if (token && config.headers) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error: AxiosError) => {
    return Promise.reject(error);
  }
);

// Response interceptor: handle errors, redirect on 401
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      if (typeof window !== "undefined") {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

// Auth endpoints
export const authAPI = {
  login: (email: string, password: string) =>
    api.post("/auth/login", { email, password }),
  register: (data: { name: string; email: string; password: string }) =>
    api.post("/auth/register", data),
  oauthLogin: (provider: string) => api.get(`/auth/${provider}`),
  getProfile: () => api.get("/auth/me"),
  updateProfile: (data: Record<string, unknown>) =>
    api.put("/auth/profile", data),
};

// Resume endpoints
export const resumeAPI = {
  upload: (file: File) => {
    const formData = new FormData();
    formData.append("file", file);
    return api.post("/resumes/upload", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  },
  list: () => api.get("/resumes"),
  getScore: (id: string) => api.get(`/resumes/${id}/score`),
  optimize: (id: string, jobId?: string) =>
    api.post(`/resumes/${id}/optimize`, { job_id: jobId }),
  delete: (id: string) => api.delete(`/resumes/${id}`),
  setPrimary: (id: string) => api.put(`/resumes/${id}/primary`),
};

// Jobs endpoints
export const jobsAPI = {
  search: (params: Record<string, unknown>) =>
    api.get("/jobs/search", { params }),
  getById: (id: string) => api.get(`/jobs/${id}`),
  getMatchAnalysis: (jobId: string, resumeId?: string) =>
    api.get(`/jobs/${jobId}/match`, { params: { resume_id: resumeId } }),
  generateContent: (jobId: string, type: string) =>
    api.post(`/jobs/${jobId}/generate`, { type }),
};

// Applications endpoints
export const applicationsAPI = {
  list: (params?: Record<string, unknown>) =>
    api.get("/applications", { params }),
  apply: (jobId: string, mode: "copilot" | "autopilot") =>
    api.post("/applications", { job_id: jobId, mode }),
  getById: (id: string) => api.get(`/applications/${id}`),
  updateStatus: (id: string, status: string) =>
    api.put(`/applications/${id}/status`, { status }),
  bulkAction: (ids: string[], action: string) =>
    api.post("/applications/bulk", { ids, action }),
};

// Analytics endpoints
export const analyticsAPI = {
  getDashboard: () => api.get("/analytics/dashboard"),
  getFunnel: () => api.get("/analytics/funnel"),
  getTimeline: () => api.get("/analytics/timeline"),
  getIndustryDistribution: () => api.get("/analytics/industries"),
  getInsights: () => api.get("/analytics/insights"),
};

// Interview endpoints
export const interviewAPI = {
  getUpcoming: () => api.get("/interviews/upcoming"),
  getQuestions: (jobId: string) => api.get(`/interviews/${jobId}/questions`),
  getCompanyResearch: (company: string) =>
    api.get(`/interviews/research/${company}`),
  startMock: (jobId: string) => api.post(`/interviews/${jobId}/mock`),
};

// Settings endpoints
export const settingsAPI = {
  getSettings: () => api.get("/settings"),
  updateSettings: (data: Record<string, unknown>) =>
    api.put("/settings", data),
  connectAccount: (provider: string) =>
    api.post(`/settings/connect/${provider}`),
  disconnectAccount: (provider: string) =>
    api.delete(`/settings/connect/${provider}`),
  exportData: () => api.get("/settings/export"),
  deleteAccount: () => api.delete("/settings/account"),
};

export default api;
